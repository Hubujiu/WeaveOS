// Minimal declaration for RED before implementing the real Redis observer.
export async function open() { return { storage: "isolated-postgresql-and-redis", async expireSession() {}, async close() {} }; }
