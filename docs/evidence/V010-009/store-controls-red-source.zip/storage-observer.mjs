// Initial no-behavior declaration for real native-expiration qualification.
export async function open() {
  return {
    async expireSession() {}, async setSessionPTTL() {}, async setSessionCreationAge() {},
    async setUserStatus() {}, async disconnectApplication() { return async () => {}; },
    async failNextRegistrationBeforeCommit() { return async () => {}; }, async close() {},
  };
}
