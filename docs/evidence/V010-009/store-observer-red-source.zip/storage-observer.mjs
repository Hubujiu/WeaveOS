// Initial no-behavior declaration for real native-expiration qualification.
export async function open() {
  return { async expireSession() {}, async close() {} };
}
