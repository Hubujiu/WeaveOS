import assert from 'node:assert/strict';
import { test } from 'node:test';
import { execFileSync } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { open } from './storage-observer.mjs';

test('storage observer expires an existing native Redis key, preserving its neighbor', async () => {
  const project = process.env.WEAVEOS_ACCEPTANCE_PROJECT;
  assert.match(project ?? '', /^weaveos-v010-007-\d+$/);
  const redis = (...args) => execFileSync('docker', ['exec', `${project}-redis-1`, 'redis-cli', '--raw', ...args], { encoding: 'utf8', stdio: 'pipe' }).trim();
  const raw = randomBytes(32), neighbor = `ems:auth:session:${project}:v1:qualification-neighbor`;
  const key = `ems:auth:session:${project}:v1:${createHash('sha256').update(raw).digest('hex')}`;
  redis('SET', key, 'qualification', 'PX', '60000');
  redis('SET', neighbor, 'neighbor', 'PX', '60000');
  const observer = await open({ baseURL: process.env.WEAVEOS_API_URL });
  try {
    assert.ok(Number(redis('PTTL', key)) > 0);
    await observer.expireSession(`__Host-session=${raw.toString('base64url')}`);
    assert.equal(Number(redis('PTTL', key)), -2, 'target must actually expire in Redis');
    assert.equal(redis('GET', neighbor), 'neighbor');
  } finally { redis('DEL', key, neighbor); await observer.close(); }
});
