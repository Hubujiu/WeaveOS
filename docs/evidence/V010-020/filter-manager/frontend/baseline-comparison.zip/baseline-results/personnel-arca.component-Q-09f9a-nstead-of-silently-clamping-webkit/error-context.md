# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personnel-arca.component.spec.ts >> Q36 shrinking full result blocks pagination until explicit refresh instead of silently clamping
- Location: apps/web/src/personnel-arca.component.spec.ts:138:1

# Error details

```
Test timeout of 20000ms exceeded.
```

```
Error: locator.click: Test timeout of 20000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '下一页', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - strong [ref=e7]: 管理后台
    - generic [ref=e8]:
      - button "草稿箱" [ref=e9] [cursor=pointer]
      - button "保存" [disabled] [ref=e10]
      - button "退出" [ref=e11] [cursor=pointer]
  - complementary [ref=e12]:
    - generic [ref=e13]: 管理功能
    - button "人员管理" [ref=e14] [cursor=pointer]
    - paragraph [ref=e16]: 成员 · 部门 · 身份 · 权限
  - main [ref=e17]:
    - generic [ref=e18]:
      - heading "人员管理" [level=1] [ref=e19]
      - paragraph [ref=e20]: 统一管理成员、部门、身份与应用访问。
    - tablist "人员管理视图" [ref=e21]:
      - generic [ref=e22]:
        - tab "成员与部门" [selected] [ref=e23] [cursor=pointer]
        - tab "身份" [ref=e24] [cursor=pointer]
        - tab "权限模板" [ref=e25] [cursor=pointer]
        - tab "操作记录" [ref=e26] [cursor=pointer]
    - button "刷新查询" [ref=e28] [cursor=pointer]
    - tabpanel "成员与部门" [ref=e29]:
      - generic [ref=e30]:
        - generic [ref=e31]:
          - heading "成员与部门" [level=2] [ref=e32]
          - paragraph [ref=e33]: 管理成员归属与身份，部门调整不改变访问权限
        - button "新建部门" [ref=e34] [cursor=pointer]
        - button "邀请成员" [ref=e35] [cursor=pointer]
      - generic [ref=e36]:
        - generic [ref=e37]:
          - heading "部门 0" [level=3] [ref=e38]:
            - text: 部门
            - generic [ref=e39]: "0"
          - button "全部成员 20" [ref=e40] [cursor=pointer]:
            - text: 全部成员
            - generic [ref=e41]: "20"
          - generic [ref=e42]:
            - button "重命名部门" [disabled] [ref=e43]
            - button "删除部门" [disabled] [ref=e44]
          - paragraph [ref=e45]: 部门只用于分组。移动成员不会自动改变身份或应用访问权限。
        - generic [ref=e46]:
          - generic [ref=e47]:
            - textbox "搜索成员" [ref=e49]
            - button "自定义筛选" [ref=e50] [cursor=pointer]
            - generic [ref=e51]: 20 位成员
            - combobox "筛选身份" [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: 全部身份
          - generic [ref=e58]:
            - generic [ref=e59]:
              - generic "成员表格滚动区域" [ref=e60]:
                - table "成员" [ref=e62]:
                  - rowgroup [ref=e63]:
                    - row [ref=e64]:
                      - columnheader [ref=e65]:
                        - checkbox "选择当前页成员" [ref=e68]
                      - columnheader "拖动以调整 account 列顺序 成员 Resize account column" [ref=e69]:
                        - generic [ref=e70]:
                          - button "拖动以调整 account 列顺序" [ref=e71]
                          - generic [ref=e74]: 成员
                        - button "Resize account column" [ref=e76]
                      - columnheader "拖动以调整 departments 列顺序 部门 Resize departments column" [ref=e77]:
                        - generic [ref=e78]:
                          - button "拖动以调整 departments 列顺序" [ref=e79]
                          - generic [ref=e82]: 部门
                        - button "Resize departments column" [ref=e84]
                      - columnheader "拖动以调整 identities 列顺序 身份 Resize identities column" [ref=e85]:
                        - generic [ref=e86]:
                          - button "拖动以调整 identities 列顺序" [ref=e87]
                          - generic [ref=e90]: 身份
                        - button "Resize identities column" [ref=e92]
                      - columnheader "拖动以调整 personnelManage 列顺序 人员管理 Resize personnelManage column" [ref=e93]:
                        - generic [ref=e94]:
                          - button "拖动以调整 personnelManage 列顺序" [ref=e95]
                          - generic [ref=e98]: 人员管理
                        - button "Resize personnelManage column" [ref=e100]
                      - columnheader "拖动以调整 actions 列顺序 操作 Resize actions column" [ref=e101]:
                        - generic [ref=e102]:
                          - button "拖动以调整 actions 列顺序" [ref=e103]
                          - generic [ref=e106]: 操作
                        - button "Resize actions column" [ref=e108]
                  - rowgroup [ref=e109]:
                    - row [ref=e110]:
                      - cell [ref=e111]:
                        - generic: "1"
                        - checkbox "选择成员：Zulu0" [ref=e114]
                      - cell "Zulu0 正常" [ref=e115]:
                        - generic "Zulu0" [ref=e116]:
                          - strong [ref=e117]: Zulu0
                          - generic [ref=e118]: 正常
                      - cell "未分组" [ref=e119]
                      - cell "未分配" [ref=e121]
                      - cell "未开启" [ref=e123]
                      - cell [ref=e125]:
                        - generic [ref=e126]:
                          - button "配置身份" [ref=e127]
                          - button "调整分组" [ref=e128]
                    - row [ref=e129]:
                      - cell [ref=e130]:
                        - generic: "2"
                        - checkbox "选择成员：Alpha1" [ref=e133]
                      - cell "Alpha1 正常" [ref=e134]:
                        - generic "Alpha1" [ref=e135]:
                          - strong [ref=e136]: Alpha1
                          - generic [ref=e137]: 正常
                      - cell "未分组" [ref=e138]
                      - cell "未分配" [ref=e140]
                      - cell "未开启" [ref=e142]
                      - cell [ref=e144]:
                        - generic [ref=e145]:
                          - button "配置身份" [ref=e146]
                          - button "调整分组" [ref=e147]
                    - row [ref=e148]:
                      - cell [ref=e149]:
                        - generic: "3"
                        - checkbox "选择成员：Bravo2" [ref=e152]
                      - cell "Bravo2 正常" [ref=e153]:
                        - generic "Bravo2" [ref=e154]:
                          - strong [ref=e155]: Bravo2
                          - generic [ref=e156]: 正常
                      - cell "未分组" [ref=e157]
                      - cell "未分配" [ref=e159]
                      - cell "未开启" [ref=e161]
                      - cell [ref=e163]:
                        - generic [ref=e164]:
                          - button "配置身份" [ref=e165]
                          - button "调整分组" [ref=e166]
                    - row [ref=e167]:
                      - cell [ref=e168]:
                        - generic: "4"
                        - checkbox "选择成员：Zulu3" [ref=e171]
                      - cell "Zulu3 正常" [ref=e172]:
                        - generic "Zulu3" [ref=e173]:
                          - strong [ref=e174]: Zulu3
                          - generic [ref=e175]: 正常
                      - cell "未分组" [ref=e176]
                      - cell "未分配" [ref=e178]
                      - cell "未开启" [ref=e180]
                      - cell [ref=e182]:
                        - generic [ref=e183]:
                          - button "配置身份" [ref=e184]
                          - button "调整分组" [ref=e185]
                    - row [ref=e186]:
                      - cell [ref=e187]:
                        - generic: "5"
                        - checkbox "选择成员：Alpha4" [ref=e190]
                      - cell "Alpha4 正常" [ref=e191]:
                        - generic "Alpha4" [ref=e192]:
                          - strong [ref=e193]: Alpha4
                          - generic [ref=e194]: 正常
                      - cell "未分组" [ref=e195]
                      - cell "未分配" [ref=e197]
                      - cell "未开启" [ref=e199]
                      - cell [ref=e201]:
                        - generic [ref=e202]:
                          - button "配置身份" [ref=e203]
                          - button "调整分组" [ref=e204]
                    - row [ref=e205]:
                      - cell [ref=e206]:
                        - generic: "6"
                        - checkbox "选择成员：Bravo5" [ref=e209]
                      - cell "Bravo5 正常" [ref=e210]:
                        - generic "Bravo5" [ref=e211]:
                          - strong [ref=e212]: Bravo5
                          - generic [ref=e213]: 正常
                      - cell "未分组" [ref=e214]
                      - cell "未分配" [ref=e216]
                      - cell "未开启" [ref=e218]
                      - cell [ref=e220]:
                        - generic [ref=e221]:
                          - button "配置身份" [ref=e222]
                          - button "调整分组" [ref=e223]
                    - row [ref=e224]:
                      - cell [ref=e225]:
                        - generic: "7"
                        - checkbox "选择成员：Zulu6" [ref=e228]
                      - cell "Zulu6 正常" [ref=e229]:
                        - generic "Zulu6" [ref=e230]:
                          - strong [ref=e231]: Zulu6
                          - generic [ref=e232]: 正常
                      - cell "未分组" [ref=e233]
                      - cell "未分配" [ref=e235]
                      - cell "未开启" [ref=e237]
                      - cell [ref=e239]:
                        - generic [ref=e240]:
                          - button "配置身份" [ref=e241]
                          - button "调整分组" [ref=e242]
                    - row [ref=e243]:
                      - cell [ref=e244]:
                        - generic: "8"
                        - checkbox "选择成员：Alpha7" [ref=e247]
                      - cell "Alpha7 正常" [ref=e248]:
                        - generic "Alpha7" [ref=e249]:
                          - strong [ref=e250]: Alpha7
                          - generic [ref=e251]: 正常
                      - cell "未分组" [ref=e252]
                      - cell "未分配" [ref=e254]
                      - cell "未开启" [ref=e256]
                      - cell [ref=e258]:
                        - generic [ref=e259]:
                          - button "配置身份" [ref=e260]
                          - button "调整分组" [ref=e261]
                    - row [ref=e262]:
                      - cell [ref=e263]:
                        - generic: "9"
                        - checkbox "选择成员：Bravo8" [ref=e266]
                      - cell "Bravo8 正常" [ref=e267]:
                        - generic "Bravo8" [ref=e268]:
                          - strong [ref=e269]: Bravo8
                          - generic [ref=e270]: 正常
                      - cell "未分组" [ref=e271]
                      - cell "未分配" [ref=e273]
                      - cell "未开启" [ref=e275]
                      - cell [ref=e277]:
                        - generic [ref=e278]:
                          - button "配置身份" [ref=e279]
                          - button "调整分组" [ref=e280]
                    - row [ref=e281]:
                      - cell [ref=e282]:
                        - generic: "10"
                        - checkbox "选择成员：Zulu9" [ref=e285]
                      - cell "Zulu9 正常" [ref=e286]:
                        - generic "Zulu9" [ref=e287]:
                          - strong [ref=e288]: Zulu9
                          - generic [ref=e289]: 正常
                      - cell "未分组" [ref=e290]
                      - cell "未分配" [ref=e292]
                      - cell "未开启" [ref=e294]
                      - cell [ref=e296]:
                        - generic [ref=e297]:
                          - button "配置身份" [ref=e298]
                          - button "调整分组" [ref=e299]
                    - row [ref=e300]:
                      - cell [ref=e301]:
                        - generic: "11"
                        - checkbox "选择成员：Alpha10" [ref=e304]
                      - cell "Alpha10 正常" [ref=e305]:
                        - generic "Alpha10" [ref=e306]:
                          - strong [ref=e307]: Alpha10
                          - generic [ref=e308]: 正常
                      - cell "未分组" [ref=e309]
                      - cell "未分配" [ref=e311]
                      - cell "未开启" [ref=e313]
                      - cell [ref=e315]:
                        - generic [ref=e316]:
                          - button "配置身份" [ref=e317]
                          - button "调整分组" [ref=e318]
                    - row [ref=e319]:
                      - cell [ref=e320]:
                        - generic: "12"
                        - checkbox "选择成员：Bravo11" [ref=e323]
                      - cell "Bravo11 正常" [ref=e324]:
                        - generic "Bravo11" [ref=e325]:
                          - strong [ref=e326]: Bravo11
                          - generic [ref=e327]: 正常
                      - cell "未分组" [ref=e328]
                      - cell "未分配" [ref=e330]
                      - cell "未开启" [ref=e332]
                      - cell [ref=e334]:
                        - generic [ref=e335]:
                          - button "配置身份" [ref=e336]
                          - button "调整分组" [ref=e337]
                    - row [ref=e338]:
                      - cell [ref=e339]:
                        - generic: "13"
                        - checkbox "选择成员：Zulu12" [ref=e342]
                      - cell "Zulu12 正常" [ref=e343]:
                        - generic "Zulu12" [ref=e344]:
                          - strong [ref=e345]: Zulu12
                          - generic [ref=e346]: 正常
                      - cell "未分组" [ref=e347]
                      - cell "未分配" [ref=e349]
                      - cell "未开启" [ref=e351]
                      - cell [ref=e353]:
                        - generic [ref=e354]:
                          - button "配置身份" [ref=e355]
                          - button "调整分组" [ref=e356]
                    - row [ref=e357]:
                      - cell [ref=e358]:
                        - generic: "14"
                        - checkbox "选择成员：Alpha13" [ref=e361]
                      - cell "Alpha13 正常" [ref=e362]:
                        - generic "Alpha13" [ref=e363]:
                          - strong [ref=e364]: Alpha13
                          - generic [ref=e365]: 正常
                      - cell "未分组" [ref=e366]
                      - cell "未分配" [ref=e368]
                      - cell "未开启" [ref=e370]
                      - cell [ref=e372]:
                        - generic [ref=e373]:
                          - button "配置身份" [ref=e374]
                          - button "调整分组" [ref=e375]
                    - row [ref=e376]:
                      - cell [ref=e377]:
                        - generic: "15"
                        - checkbox "选择成员：Bravo14" [ref=e380]
                      - cell "Bravo14 正常" [ref=e381]:
                        - generic "Bravo14" [ref=e382]:
                          - strong [ref=e383]: Bravo14
                          - generic [ref=e384]: 正常
                      - cell "未分组" [ref=e385]
                      - cell "未分配" [ref=e387]
                      - cell "未开启" [ref=e389]
                      - cell [ref=e391]:
                        - generic [ref=e392]:
                          - button "配置身份" [ref=e393]
                          - button "调整分组" [ref=e394]
                    - row [ref=e395]:
                      - cell [ref=e396]:
                        - generic: "16"
                        - checkbox "选择成员：Zulu15" [ref=e399]
                      - cell "Zulu15 正常" [ref=e400]:
                        - generic "Zulu15" [ref=e401]:
                          - strong [ref=e402]: Zulu15
                          - generic [ref=e403]: 正常
                      - cell "未分组" [ref=e404]
                      - cell "未分配" [ref=e406]
                      - cell "未开启" [ref=e408]
                      - cell [ref=e410]:
                        - generic [ref=e411]:
                          - button "配置身份" [ref=e412]
                          - button "调整分组" [ref=e413]
                    - row [ref=e414]:
                      - cell [ref=e415]:
                        - generic: "17"
                        - checkbox "选择成员：Alpha16" [ref=e418]
                      - cell "Alpha16 正常" [ref=e419]:
                        - generic "Alpha16" [ref=e420]:
                          - strong [ref=e421]: Alpha16
                          - generic [ref=e422]: 正常
                      - cell "未分组" [ref=e423]
                      - cell "未分配" [ref=e425]
                      - cell "未开启" [ref=e427]
                      - cell [ref=e429]:
                        - generic [ref=e430]:
                          - button "配置身份" [ref=e431]
                          - button "调整分组" [ref=e432]
                    - row [ref=e433]:
                      - cell [ref=e434]:
                        - generic: "18"
                        - checkbox "选择成员：Bravo17" [ref=e437]
                      - cell "Bravo17 正常" [ref=e438]:
                        - generic "Bravo17" [ref=e439]:
                          - strong [ref=e440]: Bravo17
                          - generic [ref=e441]: 正常
                      - cell "未分组" [ref=e442]
                      - cell "未分配" [ref=e444]
                      - cell "未开启" [ref=e446]
                      - cell [ref=e448]:
                        - generic [ref=e449]:
                          - button "配置身份" [ref=e450]
                          - button "调整分组" [ref=e451]
                    - row [ref=e452]:
                      - cell [ref=e453]:
                        - generic: "19"
                        - checkbox "选择成员：Zulu18" [ref=e456]
                      - cell "Zulu18 正常" [ref=e457]:
                        - generic "Zulu18" [ref=e458]:
                          - strong [ref=e459]: Zulu18
                          - generic [ref=e460]: 正常
                      - cell "未分组" [ref=e461]
                      - cell "未分配" [ref=e463]
                      - cell "未开启" [ref=e465]
                      - cell [ref=e467]:
                        - generic [ref=e468]:
                          - button "配置身份" [ref=e469]
                          - button "调整分组" [ref=e470]
                    - row [ref=e471]:
                      - cell [ref=e472]:
                        - generic: "20"
                        - checkbox "选择成员：Alpha19" [ref=e475]
                      - cell "Alpha19 正常" [ref=e476]:
                        - generic "Alpha19" [ref=e477]:
                          - strong [ref=e478]: Alpha19
                          - generic [ref=e479]: 正常
                      - cell "未分组" [ref=e480]
                      - cell "未分配" [ref=e482]
                      - cell "未开启" [ref=e484]
                      - cell [ref=e486]:
                        - generic [ref=e487]:
                          - button "配置身份" [ref=e488]
                          - button "调整分组" [ref=e489]
              - generic [ref=e491] [cursor=pointer]
            - generic [ref=e492]:
              - generic [ref=e493]:
                - generic [ref=e494]: 每页条数
                - generic [ref=e495]:
                  - combobox "每页条数" [ref=e496]:
                    - generic [ref=e497]: "20"
                  - listbox [aria-hidden]:
                    - generic:
                      - generic:
                        - listitem:
                          - option: "5"
                        - listitem:
                          - option: "10"
                        - listitem:
                          - option [selected]: "20"
                        - listitem:
                          - option: "25"
                        - listitem:
                          - option: "50"
                        - listitem:
                          - option: "100"
              - generic [ref=e501]: 1 - 20 / 共 20 项
```

# Test source

```ts
  49  |   const scroll = area.locator('.el-scrollbar__wrap'), blanks = area.locator('tr[data-empty-row]');
  50  |   await expect(blanks.first()).toBeAttached();
  51  |   await expect(scroll).toHaveCSS('max-height', 'none');
  52  |   const verify = async () => {
  53  |     const metrics = await area.evaluate(n => {
  54  |       const viewport = n.querySelector('.el-scrollbar__wrap')!, last = n.querySelector('tbody tr:last-child')!, footer = n.querySelector('.arca-pagination')!;
  55  |       return { bodyBottom: viewport.getBoundingClientRect().bottom, lastBottom: last.getBoundingClientRect().bottom, footerTop: footer.getBoundingClientRect().top, footerHeight: footer.getBoundingClientRect().height };
  56  |     });
  57  |     expect(Math.abs(metrics.lastBottom - metrics.bodyBottom)).toBeLessThanOrEqual(1);
  58  |     expect(Math.abs(metrics.footerTop - metrics.bodyBottom)).toBeLessThanOrEqual(1);
  59  |     expect(metrics.footerHeight).toBeCloseTo(33, 2);
  60  |     expect(await blanks.evaluateAll(nodes => nodes.every(n => n.getAttribute('aria-hidden') === 'true' && !n.querySelector('button,input,a,[tabindex]') && !n.textContent?.trim()))).toBe(true);
  61  |     await expect(area.getByRole('checkbox')).toHaveCount(tab === '成员与部门' ? count + 1 : 0);
  62  |   };
  63  |   await verify();
  64  |   if (!count) await expect(area).toContainText(tab === '成员与部门' ? '暂无成员' : '暂无操作记录');
  65  |   const before = await blanks.count(); await page.setViewportSize({ width: 1920, height: 800 });
  66  |   await expect.poll(() => blanks.count()).toBeLessThan(before); await verify();
  67  | });
  68  | 
  69  | test('Q35 full original pager and page size control are present', async ({ page }) => {
  70  |   await fixture(page, 1, 125);
  71  |   const area = page.locator('.member-table');
  72  |   const footer = area.locator('.arca-pagination, .table-footer');
  73  |   await expect.soft(footer).toHaveCSS('height', '33px');
  74  |   await expect.soft(area.getByRole('combobox', { name: '每页条数', exact: true })).toHaveCount(1);
  75  |   await expect.soft(area.getByRole('button', { name: 'Page 2', exact: true })).toHaveCount(1);
  76  | });
  77  | 
  78  | test('Q35 original resize and reorder handles are enabled', async ({ page }) => {
  79  |   await fixture(page);
  80  |   const area = page.locator('.member-table');
  81  |   await expect.soft(area.getByRole('button', { name: 'Resize departments column', exact: true })).toHaveCount(1);
  82  |   await expect.soft(area.getByRole('button', { name: '拖动以调整 departments 列顺序', exact: true })).toHaveCount(1);
  83  | });
  84  | 
  85  | test('Q35 official animated checkbox and full pager use real server page sizes without double slicing', async ({ page }) => {
  86  |   await page.setViewportSize({ width: 1920, height: 1080 }); await fixture(page, 20, 125);
  87  |   const table = page.locator('.member-table'), all = table.getByRole('checkbox', { name: '选择当前页成员', exact: true });
  88  |   await expect(all).toHaveJSProperty('tagName', 'BUTTON');
  89  |   await expect(all.locator('svg')).toHaveCount(0);
  90  |   await table.getByRole('checkbox', { name: '选择成员：Zulu0', exact: true }).check();
  91  |   await expect(all).toHaveAttribute('aria-checked', 'mixed');
  92  |   await expect(table.getByRole('checkbox', { name: '选择成员：Zulu0', exact: true }).locator('svg')).toHaveCSS('width', '12px');
  93  |   await expect(table.locator('.arca-pagination')).toHaveCSS('height', '33px');
  94  |   const size = table.getByRole('combobox', { name: '每页条数', exact: true });
  95  |   await expect(size).toHaveCSS('height', '24px'); await expect(size).toHaveCSS('width', '64px');
  96  |   await size.click(); await expect(page.getByRole('option')).toHaveText(['5', '10', '20', '25', '50', '100']);
  97  |   const request = page.waitForRequest(r => r.url().includes('personnel/members/search') && fixtureRequestURL(r).searchParams.get('pageSize') === '5');
  98  |   await page.getByRole('option', { name: '5', exact: true }).click(); expect(fixtureRequestURL(await request).searchParams.get('page')).toBe('1');
  99  |   await expect(table.locator('tbody tr[data-row-id]')).toHaveCount(5);
  100 |   await table.getByRole('button', { name: '下一页', exact: true }).click();
  101 |   await expect(table).toContainText('Bravo5'); await expect(table.locator('tbody tr[data-row-id]')).toHaveCount(5);
  102 |   await expect(table.getByRole('checkbox', { checked: true })).toHaveCount(0);
  103 |   await all.check(); await expect(table.getByRole('checkbox', { checked: true })).toHaveCount(6);
  104 |   await expect(table.locator('tr[data-empty-row] button')).toHaveCount(0);
  105 | });
  106 | 
  107 | test('Q36 typed member headers preserve received order, resize and reorder without business writes', async ({ page }) => {
  108 |   await page.setViewportSize({ width: 1920, height: 1080 }); await fixture(page, 3);
  109 |   const table = page.locator('.member-table'); let writes = 0;
  110 |   page.on('request', r => { if (r.url().includes('/api/') && r.method() !== 'GET' && !r.url().endsWith('/search')) writes++; });
  111 |   // Q36 approved PLAN §1 supersedes member text sorting.
  112 |   await expect(table.getByRole('button', {name:'筛选 成员',exact:true})).toHaveCount(0);
  113 |   await expect(table.locator('tbody tr[data-row-id] .member-name strong')).toHaveText(['Zulu0','Alpha1','Bravo2']);
  114 |   await expect(table.locator('th[aria-sort]')).toHaveCount(0);
  115 |   const resize = table.getByRole('button', { name: 'Resize departments column', exact: true }), box = (await resize.boundingBox())!;
  116 |   const department = table.getByRole('columnheader').filter({ hasText: '部门' }), oldWidth = (await department.boundingBox())!.width;
  117 |   await page.mouse.move(box.x + box.width / 2, box.y + 20); await page.mouse.down(); await page.mouse.move(box.x + box.width / 2 + 60, box.y + 20, { steps: 5 }); await page.mouse.up();
  118 |   expect((await department.boundingBox())!.width).toBeGreaterThan(oldWidth + 40);
  119 |   const grip = table.getByRole('button', { name: '拖动以调整 departments 列顺序', exact: true }), start = (await grip.boundingBox())!;
  120 |   const target = (await table.getByRole('columnheader').filter({ hasText: '身份' }).boundingBox())!;
  121 |   await page.mouse.move(start.x + 10, start.y + 20); await page.mouse.down(); await page.mouse.move(target.x + target.width - 8, start.y + 20, { steps: 8 }); await page.mouse.up();
  122 |   await expect(table.getByRole('columnheader')).toHaveText(['', '成员', '身份', '部门', '人员管理', '操作']);
  123 |   expect(writes).toBe(0);
  124 | });
  125 | 
  126 | test('Q35 page size retains arrow, Home and Enter keyboard operation', async ({ page }) => {
  127 |   await fixture(page, 20, 125);
  128 |   const trigger = page.getByRole('combobox', { name: '每页条数', exact: true });
  129 |   await trigger.focus(); await page.keyboard.press('ArrowUp');
  130 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  131 |   await expect(page.getByRole('option', { name: '20', exact: true })).toBeFocused();
  132 |   await page.keyboard.press('Home'); await expect(page.getByRole('option', { name: '5', exact: true })).toBeFocused();
  133 |   const request = page.waitForRequest(r => r.url().includes('personnel/members/search') && fixtureRequestURL(r).searchParams.get('pageSize') === '5');
  134 |   await page.keyboard.press('Enter'); await request;
  135 |   await expect(trigger).toHaveAttribute('aria-expanded', 'false'); await expect(trigger).toBeFocused();
  136 | });
  137 | 
  138 | test('Q36 shrinking full result blocks pagination until explicit refresh instead of silently clamping', async ({ page }) => {
  139 |   await page.setViewportSize({ width: 1920, height: 1080 });
  140 |   await fixture(page, 20, 21);
  141 |   let recoveryRequests = 0;
  142 |   await page.route('**/api/v1/personnel/members/search', async route => {
  143 |     const p = Number(fixtureRequestURL(route.request()).searchParams.get('page') || 1);
  144 |     if (p === 1) recoveryRequests++;
  145 |     // Q36 PLAN + query-drafts: 21 → 20 invalidates the old result context.
  146 |     if(route.request().postDataJSON().queryVersion)return route.fulfill({status:409,json:{code:'COMMON_QUERY_CHANGED',message:'changed',data:null,meta:null}});
  147 |     await route.fulfill({ json: q36FixtureEnvelope({ items: Array.from({ length: 20 }, (_, i) => row(i)), total: 20, page: p, pageSize: 20 },route.request()) });
  148 |   });
> 149 |   await page.getByRole('button', { name: '下一页', exact: true }).click();
      |                                                                ^ Error: locator.click: Test timeout of 20000ms exceeded.
  150 |   await expect(page.getByRole('alert')).toContainText('查询结果已变化');
  151 |   expect(recoveryRequests).toBe(0);
  152 |   await expect(page.getByLabel('跳至页',{exact:true})).toHaveValue('1');
  153 |   await page.getByRole('button',{name:'刷新查询',exact:true}).click();
  154 |   await expect.poll(() => recoveryRequests).toBe(1);
  155 |   await expect(page.locator('.member-table tbody tr[data-row-id]')).toHaveCount(20);
  156 |   await expect(page.locator('.member-table')).toContainText('Zulu0');
  157 | });
  158 | 
  159 | test('Q35 narrow viewport keeps the original pager controls fully reachable', async ({ page }) => {
  160 |   await page.setViewportSize({ width: 320, height: 844 }); await fixture(page, 1, 125);
  161 |   const area = page.locator('.member-table');
  162 |   for (const control of [area.getByRole('combobox', { name: '每页条数', exact: true }), area.getByRole('button', { name: '下一页', exact: true })]) {
  163 |     await control.scrollIntoViewIfNeeded();
  164 |     const bounds = (await area.boundingBox())!, box = (await control.boundingBox())!;
  165 |     expect(box.x).toBeGreaterThanOrEqual(bounds.x);
  166 |     expect(box.x + box.width).toBeLessThanOrEqual(bounds.x + bounds.width);
  167 |   }
  168 |   await area.getByRole('combobox', { name: '每页条数', exact: true }).click();
  169 |   await page.getByRole('option', { name: '5', exact: true }).click();
  170 |   await expect(area.getByRole('combobox', { name: '每页条数', exact: true })).toHaveText('5');
  171 | });
  172 | 
  173 | test('Q35 source font uses Geist with the existing Chinese fallback inside its scope', async ({ page }) => {
  174 |   await fixture(page);
  175 |   const family = await page.locator('.member-table table').evaluate(n => getComputedStyle(n).fontFamily);
  176 |   expect(family).toContain('Geist Variable'); expect(family).toContain('Noto Sans SC');
  177 |   const outer = await page.locator('.personnel-page-heading').evaluate(n => getComputedStyle(n).fontFamily);
  178 |   expect(outer).toContain('Noto Sans SC'); expect(outer).not.toContain('Geist');
  179 | });
  180 | 
  181 | test('Q35 sorting menu stays open during its own scrolling and closes on table scrolling', async ({ page }) => {
  182 |   await page.setViewportSize({width:900,height:844});
  183 |   await fixture(page, 3);
  184 |   // Q36: the server time sort is the only eligible column.
  185 |   await page.getByRole('tab',{name:'操作记录',exact:true}).click();
  186 |   const table = page.locator('.activity-table');
  187 |   await expect(table.getByRole('table')).toHaveAttribute('aria-busy','false');
  188 |   await page.evaluate(()=>document.fonts.ready);
  189 |   const trigger = table.getByRole('button', { name: '排序 occurredAt', exact: true });
  190 |   await trigger.click();
  191 |   const menu = page.getByRole('menu');
  192 |   await expect(menu).toBeVisible();
  193 |   await menu.dispatchEvent('scroll');
  194 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  195 |   await menu.getByRole('menuitem', { name: '升序', exact: true }).click();
  196 |   await expect(table.getByRole('columnheader').filter({hasText:'时间'})).toHaveAttribute('aria-sort','ascending');
  197 |   await trigger.click();
  198 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  199 |   await table.locator('.el-scrollbar__wrap').evaluate(n=>{n.scrollLeft+=20;});
  200 |   await expect(trigger).toHaveAttribute('aria-expanded', 'false');
  201 | });
  202 | 
```