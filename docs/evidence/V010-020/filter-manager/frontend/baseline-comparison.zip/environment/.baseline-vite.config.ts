import original from './vite.config';
import {defineConfig} from 'vite';
export default defineConfig({...original,server:{...original.server,fs:{allow:['/tmp/weaveos-filter-handoff-baseline','/workspace/WeaveOS-worktrees/V010-020']}}});
