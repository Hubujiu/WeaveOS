# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personnel-arca-keyboard.component.spec.ts >> Q35 sort menu supports direction keys, visible focus and Escape return
- Location: apps/web/src/personnel-arca-keyboard.component.spec.ts:6:1

# Error details

```
Error: expect(locator).toHaveCSS(expected) failed

Locator:  getByRole('menuitem', { name: '升序', exact: true })
Expected: "solid"
Received: "none"
Timeout:  3000ms

Call log:
  - Expect "toHaveCSS" getByRole('menuitem', { name: '升序', exact: true }) with timeout 3000ms
  - waiting for getByRole('menuitem', { name: '升序', exact: true })
    10 × locator resolved to <button type="button" role="menuitem" aria-checked="false" class="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-sm outline-none transition-colors focus-visible:bg-muted focus-visible:text-foreground focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-ring focus-visible:-outline-offset-2 text-muted-foreground hover:bg-muted hover:text-foreground">…</button>
       - unexpected value "none"

```

```yaml
- menuitem "升序":
  - img
  - text: 升序
```

# Test source

```ts
  1  | import {fixtureRequestURL,q36FixtureEnvelope} from './personnel-query-fixtures';
  2  | import { expect, test } from '@playwright/test';
  3  | 
  4  | // Independent oracle: confirmed R3 §5.8 keyboard and visible focus support.
  5  | // This fixture isolates rendered UI; it does not claim real backend acceptance.
  6  | test('Q35 sort menu supports direction keys, visible focus and Escape return', async ({ page }) => {
  7  |   const user = { id: 'synthetic-keyboard-user', account: 'synthetic-keyboard' };
  8  |   await page.route('**/api/v1/**', async route => {
  9  |     const path = fixtureRequestURL(route.request()).pathname.replace('/api/v1/', '');
  10 |     const data = path === 'sessions/current' ? user : path === 'me/access'
  11 |       ? { user, bootstrapAdmin: true, personnelManage: true, identities: [], permissions: [], applications: [] }
  12 |       : { items: [], total: 0, page: 1, pageSize: 20 };
  13 |     await route.fulfill({ json: q36FixtureEnvelope(data,route.request()) });
  14 |   });
  15 |   await page.goto('/app/admin');
  16 |   // Q36 time column retains the original keyboard menu; text is unsortable.
  17 |   await page.getByRole('tab',{name:'操作记录',exact:true}).click();
  18 |   const trigger = page.getByRole('button', { name: '排序 occurredAt', exact: true });
  19 |   await trigger.focus(); await trigger.press('ArrowDown');
  20 |   const ascending = page.getByRole('menuitem', { name: '升序', exact: true });
  21 |   const descending = page.getByRole('menuitem', { name: '降序', exact: true });
  22 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  23 |   await expect(ascending).toBeFocused();
> 24 |   await expect(ascending).toHaveCSS('outline-style', 'solid');
     |                           ^ Error: expect(locator).toHaveCSS(expected) failed
  25 |   await expect(ascending).toHaveCSS('outline-width', '2px');
  26 |   await page.keyboard.press('ArrowDown'); await expect(descending).toBeFocused();
  27 |   await page.keyboard.press('Home'); await expect(ascending).toBeFocused();
  28 |   await page.keyboard.press('End'); await expect(descending).toBeFocused();
  29 |   await page.keyboard.press('Escape');
  30 |   await expect(trigger).toHaveAttribute('aria-expanded', 'false'); await expect(trigger).toBeFocused();
  31 |   await trigger.press('ArrowUp'); await expect(descending).toBeFocused();
  32 |   // The initial explicit descending sort is already selected. Choosing it again clears custom sorting.
  33 |   await page.keyboard.press('Enter');
  34 |   await expect(trigger).toHaveAttribute('aria-expanded', 'false'); await expect(trigger).toBeFocused();
  35 |   await expect(page.getByRole('columnheader').filter({ hasText: '时间' })).not.toHaveAttribute('aria-sort');
  36 |   await trigger.press('Enter'); await expect(ascending).toBeFocused();
  37 |   await page.keyboard.press('Escape'); await expect(trigger).toBeFocused();
  38 |   await trigger.press('Space'); await expect(ascending).toBeFocused();
  39 |   await page.keyboard.press('Escape'); await expect(trigger).toBeFocused();
  40 | });
  41 | 
  42 | test('Q35 original base foreground and smoothing are scoped to the table', async ({ page }) => {
  43 |   const user = { id: 'synthetic-font-user', account: 'synthetic-font' };
  44 |   await page.route('**/api/v1/**', async route => {
  45 |     const path = fixtureRequestURL(route.request()).pathname.replace('/api/v1/', '');
  46 |     const data = path === 'sessions/current' ? user : path === 'me/access'
  47 |       ? { user, bootstrapAdmin: true, personnelManage: true, identities: [], permissions: [], applications: [] }
  48 |       : { items: [], total: path === 'personnel/members' ? 125 : 0, page: 1, pageSize: 20 };
  49 |     await route.fulfill({ json: q36FixtureEnvelope(data,route.request()) });
  50 |   });
  51 |   await page.goto('/app/admin');
  52 |   const table = page.locator('.member-table .personnel-source-table');
  53 |   await expect(table).toHaveCSS('color', 'oklch(0.145 0 0)');
  54 |   await expect(page.getByRole('button', { name: 'Page 2', exact: true })).toHaveCSS('color', 'oklch(0.145 0 0)');
  55 |   if (await page.evaluate(() => CSS.supports('-webkit-font-smoothing', 'antialiased'))) {
  56 |     expect(await table.evaluate(n => getComputedStyle(n).getPropertyValue('-webkit-font-smoothing'))).toBe('antialiased');
  57 |   }
  58 |   await expect(page.locator('.personnel-page-heading')).toHaveCSS('color', 'rgb(16, 32, 68)');
  59 | });
  60 | 
```