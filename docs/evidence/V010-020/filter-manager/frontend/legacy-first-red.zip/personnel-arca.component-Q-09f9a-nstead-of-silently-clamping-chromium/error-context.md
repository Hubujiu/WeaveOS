# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personnel-arca.component.spec.ts >> Q36 shrinking full result blocks pagination until explicit refresh instead of silently clamping
- Location: apps/web/src/personnel-arca.component.spec.ts:138:1

# Error details

```
Test timeout of 20000ms exceeded.
```

```
Error: locator.click: Test timeout of 20000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '下一页', exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - strong [ref=e7]: 管理后台
      - generic [ref=e8]:
        - button "草稿箱" [ref=e9] [cursor=pointer]
        - button "保存" [disabled] [ref=e10]
        - button "退出" [ref=e11] [cursor=pointer]
    - complementary [ref=e12]:
      - generic [ref=e13]: 管理功能
      - button "人员管理" [ref=e14] [cursor=pointer]
      - paragraph [ref=e16]: 成员 · 部门 · 身份 · 权限
    - main [ref=e17]:
      - generic [ref=e18]:
        - heading "人员管理" [level=1] [ref=e19]
        - paragraph [ref=e20]: 统一管理成员、部门、身份与应用访问。
      - tablist "人员管理视图" [ref=e21]:
        - generic [ref=e22]:
          - tab "成员与部门" [selected] [ref=e23] [cursor=pointer]
          - tab "身份" [ref=e24] [cursor=pointer]
          - tab "权限模板" [ref=e25] [cursor=pointer]
          - tab "操作记录" [ref=e26] [cursor=pointer]
      - button "刷新查询" [ref=e28] [cursor=pointer]
      - tabpanel "成员与部门" [ref=e29]:
        - generic [ref=e30]:
          - generic [ref=e31]:
            - heading "成员与部门" [level=2] [ref=e32]
            - paragraph [ref=e33]: 管理成员归属与身份，部门调整不改变访问权限
          - button "新建部门" [ref=e34] [cursor=pointer]
          - button "邀请成员" [ref=e35] [cursor=pointer]
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "部门 0" [level=3] [ref=e38]:
              - text: 部门
              - generic [ref=e39]: "0"
            - button "全部成员 20" [ref=e40] [cursor=pointer]:
              - text: 全部成员
              - generic [ref=e41]: "20"
            - generic [ref=e42]:
              - button "重命名部门" [disabled] [ref=e43]
              - button "删除部门" [disabled] [ref=e44]
            - paragraph [ref=e45]: 部门只用于分组。移动成员不会自动改变身份或应用访问权限。
          - generic [ref=e46]:
            - generic [ref=e47]:
              - textbox "搜索成员" [ref=e49]
              - button "自定义筛选" [ref=e50] [cursor=pointer]
              - generic [ref=e51]: 20 位成员
              - combobox "筛选身份" [ref=e53] [cursor=pointer]:
                - generic [ref=e54]: 全部身份
            - generic [ref=e58]:
              - generic [ref=e59]:
                - generic "成员表格滚动区域" [ref=e60]:
                  - table "成员" [ref=e62]:
                    - rowgroup [ref=e70]:
                      - row [ref=e71]:
                        - columnheader [ref=e72]:
                          - checkbox "选择当前页成员" [ref=e75]
                        - columnheader "拖动以调整 account 列顺序 成员 Resize account column" [ref=e76]:
                          - generic [ref=e77]:
                            - button "拖动以调整 account 列顺序" [ref=e78]
                            - generic [ref=e81]: 成员
                          - button "Resize account column" [ref=e83]
                        - columnheader "拖动以调整 departments 列顺序 部门 Resize departments column" [ref=e84]:
                          - generic [ref=e85]:
                            - button "拖动以调整 departments 列顺序" [ref=e86]
                            - generic [ref=e89]: 部门
                          - button "Resize departments column" [ref=e91]
                        - columnheader "拖动以调整 identities 列顺序 身份 Resize identities column" [ref=e92]:
                          - generic [ref=e93]:
                            - button "拖动以调整 identities 列顺序" [ref=e94]
                            - generic [ref=e97]: 身份
                          - button "Resize identities column" [ref=e99]
                        - columnheader "拖动以调整 personnelManage 列顺序 人员管理 Resize personnelManage column" [ref=e100]:
                          - generic [ref=e101]:
                            - button "拖动以调整 personnelManage 列顺序" [ref=e102]
                            - generic [ref=e105]: 人员管理
                          - button "Resize personnelManage column" [ref=e107]
                        - columnheader "拖动以调整 actions 列顺序 操作 Resize actions column" [ref=e108]:
                          - generic [ref=e109]:
                            - button "拖动以调整 actions 列顺序" [ref=e110]
                            - generic [ref=e113]: 操作
                          - button "Resize actions column" [ref=e115]
                    - rowgroup [ref=e116]:
                      - row [ref=e117]:
                        - cell [ref=e118]:
                          - generic: "1"
                          - checkbox "选择成员：Zulu0" [ref=e121]
                        - cell "Zulu0 正常" [ref=e122]:
                          - generic "Zulu0" [ref=e123]:
                            - strong [ref=e124]: Zulu0
                            - generic [ref=e125]: 正常
                        - cell "未分组" [ref=e126]
                        - cell "未分配" [ref=e128]
                        - cell "未开启" [ref=e130]
                        - cell [ref=e132]:
                          - generic [ref=e133]:
                            - button "配置身份" [ref=e134]
                            - button "调整分组" [ref=e135]
                      - row [ref=e136]:
                        - cell [ref=e137]:
                          - generic: "2"
                          - checkbox "选择成员：Alpha1" [ref=e140]
                        - cell "Alpha1 正常" [ref=e141]:
                          - generic "Alpha1" [ref=e142]:
                            - strong [ref=e143]: Alpha1
                            - generic [ref=e144]: 正常
                        - cell "未分组" [ref=e145]
                        - cell "未分配" [ref=e147]
                        - cell "未开启" [ref=e149]
                        - cell [ref=e151]:
                          - generic [ref=e152]:
                            - button "配置身份" [ref=e153]
                            - button "调整分组" [ref=e154]
                      - row [ref=e155]:
                        - cell [ref=e156]:
                          - generic: "3"
                          - checkbox "选择成员：Bravo2" [ref=e159]
                        - cell "Bravo2 正常" [ref=e160]:
                          - generic "Bravo2" [ref=e161]:
                            - strong [ref=e162]: Bravo2
                            - generic [ref=e163]: 正常
                        - cell "未分组" [ref=e164]
                        - cell "未分配" [ref=e166]
                        - cell "未开启" [ref=e168]
                        - cell [ref=e170]:
                          - generic [ref=e171]:
                            - button "配置身份" [ref=e172]
                            - button "调整分组" [ref=e173]
                      - row [ref=e174]:
                        - cell [ref=e175]:
                          - generic: "4"
                          - checkbox "选择成员：Zulu3" [ref=e178]
                        - cell "Zulu3 正常" [ref=e179]:
                          - generic "Zulu3" [ref=e180]:
                            - strong [ref=e181]: Zulu3
                            - generic [ref=e182]: 正常
                        - cell "未分组" [ref=e183]
                        - cell "未分配" [ref=e185]
                        - cell "未开启" [ref=e187]
                        - cell [ref=e189]:
                          - generic [ref=e190]:
                            - button "配置身份" [ref=e191]
                            - button "调整分组" [ref=e192]
                      - row [ref=e193]:
                        - cell [ref=e194]:
                          - generic: "5"
                          - checkbox "选择成员：Alpha4" [ref=e197]
                        - cell "Alpha4 正常" [ref=e198]:
                          - generic "Alpha4" [ref=e199]:
                            - strong [ref=e200]: Alpha4
                            - generic [ref=e201]: 正常
                        - cell "未分组" [ref=e202]
                        - cell "未分配" [ref=e204]
                        - cell "未开启" [ref=e206]
                        - cell [ref=e208]:
                          - generic [ref=e209]:
                            - button "配置身份" [ref=e210]
                            - button "调整分组" [ref=e211]
                      - row [ref=e212]:
                        - cell [ref=e213]:
                          - generic: "6"
                          - checkbox "选择成员：Bravo5" [ref=e216]
                        - cell "Bravo5 正常" [ref=e217]:
                          - generic "Bravo5" [ref=e218]:
                            - strong [ref=e219]: Bravo5
                            - generic [ref=e220]: 正常
                        - cell "未分组" [ref=e221]
                        - cell "未分配" [ref=e223]
                        - cell "未开启" [ref=e225]
                        - cell [ref=e227]:
                          - generic [ref=e228]:
                            - button "配置身份" [ref=e229]
                            - button "调整分组" [ref=e230]
                      - row [ref=e231]:
                        - cell [ref=e232]:
                          - generic: "7"
                          - checkbox "选择成员：Zulu6" [ref=e235]
                        - cell "Zulu6 正常" [ref=e236]:
                          - generic "Zulu6" [ref=e237]:
                            - strong [ref=e238]: Zulu6
                            - generic [ref=e239]: 正常
                        - cell "未分组" [ref=e240]
                        - cell "未分配" [ref=e242]
                        - cell "未开启" [ref=e244]
                        - cell [ref=e246]:
                          - generic [ref=e247]:
                            - button "配置身份" [ref=e248]
                            - button "调整分组" [ref=e249]
                      - row [ref=e250]:
                        - cell [ref=e251]:
                          - generic: "8"
                          - checkbox "选择成员：Alpha7" [ref=e254]
                        - cell "Alpha7 正常" [ref=e255]:
                          - generic "Alpha7" [ref=e256]:
                            - strong [ref=e257]: Alpha7
                            - generic [ref=e258]: 正常
                        - cell "未分组" [ref=e259]
                        - cell "未分配" [ref=e261]
                        - cell "未开启" [ref=e263]
                        - cell [ref=e265]:
                          - generic [ref=e266]:
                            - button "配置身份" [ref=e267]
                            - button "调整分组" [ref=e268]
                      - row [ref=e269]:
                        - cell [ref=e270]:
                          - generic: "9"
                          - checkbox "选择成员：Bravo8" [ref=e273]
                        - cell "Bravo8 正常" [ref=e274]:
                          - generic "Bravo8" [ref=e275]:
                            - strong [ref=e276]: Bravo8
                            - generic [ref=e277]: 正常
                        - cell "未分组" [ref=e278]
                        - cell "未分配" [ref=e280]
                        - cell "未开启" [ref=e282]
                        - cell [ref=e284]:
                          - generic [ref=e285]:
                            - button "配置身份" [ref=e286]
                            - button "调整分组" [ref=e287]
                      - row [ref=e288]:
                        - cell [ref=e289]:
                          - generic: "10"
                          - checkbox "选择成员：Zulu9" [ref=e292]
                        - cell "Zulu9 正常" [ref=e293]:
                          - generic "Zulu9" [ref=e294]:
                            - strong [ref=e295]: Zulu9
                            - generic [ref=e296]: 正常
                        - cell "未分组" [ref=e297]
                        - cell "未分配" [ref=e299]
                        - cell "未开启" [ref=e301]
                        - cell [ref=e303]:
                          - generic [ref=e304]:
                            - button "配置身份" [ref=e305]
                            - button "调整分组" [ref=e306]
                      - row [ref=e307]:
                        - cell [ref=e308]:
                          - generic: "11"
                          - checkbox "选择成员：Alpha10" [ref=e311]
                        - cell "Alpha10 正常" [ref=e312]:
                          - generic "Alpha10" [ref=e313]:
                            - strong [ref=e314]: Alpha10
                            - generic [ref=e315]: 正常
                        - cell "未分组" [ref=e316]
                        - cell "未分配" [ref=e318]
                        - cell "未开启" [ref=e320]
                        - cell [ref=e322]:
                          - generic [ref=e323]:
                            - button "配置身份" [ref=e324]
                            - button "调整分组" [ref=e325]
                      - row [ref=e326]:
                        - cell [ref=e327]:
                          - generic: "12"
                          - checkbox "选择成员：Bravo11" [ref=e330]
                        - cell "Bravo11 正常" [ref=e331]:
                          - generic "Bravo11" [ref=e332]:
                            - strong [ref=e333]: Bravo11
                            - generic [ref=e334]: 正常
                        - cell "未分组" [ref=e335]
                        - cell "未分配" [ref=e337]
                        - cell "未开启" [ref=e339]
                        - cell [ref=e341]:
                          - generic [ref=e342]:
                            - button "配置身份" [ref=e343]
                            - button "调整分组" [ref=e344]
                      - row [ref=e345]:
                        - cell [ref=e346]:
                          - generic: "13"
                          - checkbox "选择成员：Zulu12" [ref=e349]
                        - cell "Zulu12 正常" [ref=e350]:
                          - generic "Zulu12" [ref=e351]:
                            - strong [ref=e352]: Zulu12
                            - generic [ref=e353]: 正常
                        - cell "未分组" [ref=e354]
                        - cell "未分配" [ref=e356]
                        - cell "未开启" [ref=e358]
                        - cell [ref=e360]:
                          - generic [ref=e361]:
                            - button "配置身份" [ref=e362]
                            - button "调整分组" [ref=e363]
                      - row [ref=e364]:
                        - cell [ref=e365]:
                          - generic: "14"
                          - checkbox "选择成员：Alpha13" [ref=e368]
                        - cell "Alpha13 正常" [ref=e369]:
                          - generic "Alpha13" [ref=e370]:
                            - strong [ref=e371]: Alpha13
                            - generic [ref=e372]: 正常
                        - cell "未分组" [ref=e373]
                        - cell "未分配" [ref=e375]
                        - cell "未开启" [ref=e377]
                        - cell [ref=e379]:
                          - generic [ref=e380]:
                            - button "配置身份" [ref=e381]
                            - button "调整分组" [ref=e382]
                      - row [ref=e383]:
                        - cell [ref=e384]:
                          - generic: "15"
                          - checkbox "选择成员：Bravo14" [ref=e387]
                        - cell "Bravo14 正常" [ref=e388]:
                          - generic "Bravo14" [ref=e389]:
                            - strong [ref=e390]: Bravo14
                            - generic [ref=e391]: 正常
                        - cell "未分组" [ref=e392]
                        - cell "未分配" [ref=e394]
                        - cell "未开启" [ref=e396]
                        - cell [ref=e398]:
                          - generic [ref=e399]:
                            - button "配置身份" [ref=e400]
                            - button "调整分组" [ref=e401]
                      - row [ref=e402]:
                        - cell [ref=e403]:
                          - generic: "16"
                          - checkbox "选择成员：Zulu15" [ref=e406]
                        - cell "Zulu15 正常" [ref=e407]:
                          - generic "Zulu15" [ref=e408]:
                            - strong [ref=e409]: Zulu15
                            - generic [ref=e410]: 正常
                        - cell "未分组" [ref=e411]
                        - cell "未分配" [ref=e413]
                        - cell "未开启" [ref=e415]
                        - cell [ref=e417]:
                          - generic [ref=e418]:
                            - button "配置身份" [ref=e419]
                            - button "调整分组" [ref=e420]
                      - row [ref=e421]:
                        - cell [ref=e422]:
                          - generic: "17"
                          - checkbox "选择成员：Alpha16" [ref=e425]
                        - cell "Alpha16 正常" [ref=e426]:
                          - generic "Alpha16" [ref=e427]:
                            - strong [ref=e428]: Alpha16
                            - generic [ref=e429]: 正常
                        - cell "未分组" [ref=e430]
                        - cell "未分配" [ref=e432]
                        - cell "未开启" [ref=e434]
                        - cell [ref=e436]:
                          - generic [ref=e437]:
                            - button "配置身份" [ref=e438]
                            - button "调整分组" [ref=e439]
                      - row [ref=e440]:
                        - cell [ref=e441]:
                          - generic: "18"
                          - checkbox "选择成员：Bravo17" [ref=e444]
                        - cell "Bravo17 正常" [ref=e445]:
                          - generic "Bravo17" [ref=e446]:
                            - strong [ref=e447]: Bravo17
                            - generic [ref=e448]: 正常
                        - cell "未分组" [ref=e449]
                        - cell "未分配" [ref=e451]
                        - cell "未开启" [ref=e453]
                        - cell [ref=e455]:
                          - generic [ref=e456]:
                            - button "配置身份" [ref=e457]
                            - button "调整分组" [ref=e458]
                      - row [ref=e459]:
                        - cell [ref=e460]:
                          - generic: "19"
                          - checkbox "选择成员：Zulu18" [ref=e463]
                        - cell "Zulu18 正常" [ref=e464]:
                          - generic "Zulu18" [ref=e465]:
                            - strong [ref=e466]: Zulu18
                            - generic [ref=e467]: 正常
                        - cell "未分组" [ref=e468]
                        - cell "未分配" [ref=e470]
                        - cell "未开启" [ref=e472]
                        - cell [ref=e474]:
                          - generic [ref=e475]:
                            - button "配置身份" [ref=e476]
                            - button "调整分组" [ref=e477]
                      - row [ref=e478]:
                        - cell [ref=e479]:
                          - generic: "20"
                          - checkbox "选择成员：Alpha19" [ref=e482]
                        - cell "Alpha19 正常" [ref=e483]:
                          - generic "Alpha19" [ref=e484]:
                            - strong [ref=e485]: Alpha19
                            - generic [ref=e486]: 正常
                        - cell "未分组" [ref=e487]
                        - cell "未分配" [ref=e489]
                        - cell "未开启" [ref=e491]
                        - cell [ref=e493]:
                          - generic [ref=e494]:
                            - button "配置身份" [ref=e495]
                            - button "调整分组" [ref=e496]
                - generic [ref=e498] [cursor=pointer]
              - generic [ref=e499]:
                - generic [ref=e500]:
                  - generic [ref=e501]: 每页条数
                  - generic [ref=e502]:
                    - combobox "每页条数" [ref=e503]:
                      - generic [ref=e504]: "20"
                    - listbox [aria-hidden]:
                      - generic:
                        - generic:
                          - listitem:
                            - option: "5"
                          - listitem:
                            - option: "10"
                          - listitem:
                            - option [selected]: "20"
                          - listitem:
                            - option: "25"
                          - listitem:
                            - option: "50"
                          - listitem:
                            - option: "100"
                - generic [ref=e508]: 1 - 20 / 共 20 项
  - generic:
    - dialog [aria-hidden]
```

# Test source

```ts
  49  |   const scroll = area.locator('.el-scrollbar__wrap'), blanks = area.locator('tr[data-empty-row]');
  50  |   await expect(blanks.first()).toBeAttached();
  51  |   await expect(scroll).toHaveCSS('max-height', 'none');
  52  |   const verify = async () => {
  53  |     const metrics = await area.evaluate(n => {
  54  |       const viewport = n.querySelector('.el-scrollbar__wrap')!, last = n.querySelector('tbody tr:last-child')!, footer = n.querySelector('.arca-pagination')!;
  55  |       return { bodyBottom: viewport.getBoundingClientRect().bottom, lastBottom: last.getBoundingClientRect().bottom, footerTop: footer.getBoundingClientRect().top, footerHeight: footer.getBoundingClientRect().height };
  56  |     });
  57  |     expect(Math.abs(metrics.lastBottom - metrics.bodyBottom)).toBeLessThanOrEqual(1);
  58  |     expect(Math.abs(metrics.footerTop - metrics.bodyBottom)).toBeLessThanOrEqual(1);
  59  |     expect(metrics.footerHeight).toBeCloseTo(33, 2);
  60  |     expect(await blanks.evaluateAll(nodes => nodes.every(n => n.getAttribute('aria-hidden') === 'true' && !n.querySelector('button,input,a,[tabindex]') && !n.textContent?.trim()))).toBe(true);
  61  |     await expect(area.getByRole('checkbox')).toHaveCount(tab === '成员与部门' ? count + 1 : 0);
  62  |   };
  63  |   await verify();
  64  |   if (!count) await expect(area).toContainText(tab === '成员与部门' ? '暂无成员' : '暂无操作记录');
  65  |   const before = await blanks.count(); await page.setViewportSize({ width: 1920, height: 800 });
  66  |   await expect.poll(() => blanks.count()).toBeLessThan(before); await verify();
  67  | });
  68  | 
  69  | test('Q35 full original pager and page size control are present', async ({ page }) => {
  70  |   await fixture(page, 1, 125);
  71  |   const area = page.locator('.member-table');
  72  |   const footer = area.locator('.arca-pagination, .table-footer');
  73  |   await expect.soft(footer).toHaveCSS('height', '33px');
  74  |   await expect.soft(area.getByRole('combobox', { name: '每页条数', exact: true })).toHaveCount(1);
  75  |   await expect.soft(area.getByRole('button', { name: 'Page 2', exact: true })).toHaveCount(1);
  76  | });
  77  | 
  78  | test('Q35 original resize and reorder handles are enabled', async ({ page }) => {
  79  |   await fixture(page);
  80  |   const area = page.locator('.member-table');
  81  |   await expect.soft(area.getByRole('button', { name: 'Resize departments column', exact: true })).toHaveCount(1);
  82  |   await expect.soft(area.getByRole('button', { name: '拖动以调整 departments 列顺序', exact: true })).toHaveCount(1);
  83  | });
  84  | 
  85  | test('Q35 official animated checkbox and full pager use real server page sizes without double slicing', async ({ page }) => {
  86  |   await page.setViewportSize({ width: 1920, height: 1080 }); await fixture(page, 20, 125);
  87  |   const table = page.locator('.member-table'), all = table.getByRole('checkbox', { name: '选择当前页成员', exact: true });
  88  |   await expect(all).toHaveJSProperty('tagName', 'BUTTON');
  89  |   await expect(all.locator('svg')).toHaveCount(0);
  90  |   await table.getByRole('checkbox', { name: '选择成员：Zulu0', exact: true }).check();
  91  |   await expect(all).toHaveAttribute('aria-checked', 'mixed');
  92  |   await expect(table.getByRole('checkbox', { name: '选择成员：Zulu0', exact: true }).locator('svg')).toHaveCSS('width', '12px');
  93  |   await expect(table.locator('.arca-pagination')).toHaveCSS('height', '33px');
  94  |   const size = table.getByRole('combobox', { name: '每页条数', exact: true });
  95  |   await expect(size).toHaveCSS('height', '24px'); await expect(size).toHaveCSS('width', '64px');
  96  |   await size.click(); await expect(page.getByRole('option')).toHaveText(['5', '10', '20', '25', '50', '100']);
  97  |   const request = page.waitForRequest(r => r.url().includes('personnel/members/search') && fixtureRequestURL(r).searchParams.get('pageSize') === '5');
  98  |   await page.getByRole('option', { name: '5', exact: true }).click(); expect(fixtureRequestURL(await request).searchParams.get('page')).toBe('1');
  99  |   await expect(table.locator('tbody tr[data-row-id]')).toHaveCount(5);
  100 |   await table.getByRole('button', { name: '下一页', exact: true }).click();
  101 |   await expect(table).toContainText('Bravo5'); await expect(table.locator('tbody tr[data-row-id]')).toHaveCount(5);
  102 |   await expect(table.getByRole('checkbox', { checked: true })).toHaveCount(0);
  103 |   await all.check(); await expect(table.getByRole('checkbox', { checked: true })).toHaveCount(6);
  104 |   await expect(table.locator('tr[data-empty-row] button')).toHaveCount(0);
  105 | });
  106 | 
  107 | test('Q36 typed member headers preserve received order, resize and reorder without business writes', async ({ page }) => {
  108 |   await page.setViewportSize({ width: 1920, height: 1080 }); await fixture(page, 3);
  109 |   const table = page.locator('.member-table'); let writes = 0;
  110 |   page.on('request', r => { if (r.url().includes('/api/') && r.method() !== 'GET' && !r.url().endsWith('/search')) writes++; });
  111 |   // Q36 approved PLAN §1 supersedes member text sorting.
  112 |   await expect(table.getByRole('button', {name:'筛选 成员',exact:true})).toHaveCount(0);
  113 |   await expect(table.locator('tbody tr[data-row-id] .member-name strong')).toHaveText(['Zulu0','Alpha1','Bravo2']);
  114 |   await expect(table.locator('th[aria-sort]')).toHaveCount(0);
  115 |   const resize = table.getByRole('button', { name: 'Resize departments column', exact: true }), box = (await resize.boundingBox())!;
  116 |   const department = table.getByRole('columnheader').filter({ hasText: '部门' }), oldWidth = (await department.boundingBox())!.width;
  117 |   await page.mouse.move(box.x + box.width / 2, box.y + 20); await page.mouse.down(); await page.mouse.move(box.x + box.width / 2 + 60, box.y + 20, { steps: 5 }); await page.mouse.up();
  118 |   expect((await department.boundingBox())!.width).toBeGreaterThan(oldWidth + 40);
  119 |   const grip = table.getByRole('button', { name: '拖动以调整 departments 列顺序', exact: true }), start = (await grip.boundingBox())!;
  120 |   const target = (await table.getByRole('columnheader').filter({ hasText: '身份' }).boundingBox())!;
  121 |   await page.mouse.move(start.x + 10, start.y + 20); await page.mouse.down(); await page.mouse.move(target.x + target.width - 8, start.y + 20, { steps: 8 }); await page.mouse.up();
  122 |   await expect(table.getByRole('columnheader')).toHaveText(['', '成员', '身份', '部门', '人员管理', '操作']);
  123 |   expect(writes).toBe(0);
  124 | });
  125 | 
  126 | test('Q35 page size retains arrow, Home and Enter keyboard operation', async ({ page }) => {
  127 |   await fixture(page, 20, 125);
  128 |   const trigger = page.getByRole('combobox', { name: '每页条数', exact: true });
  129 |   await trigger.focus(); await page.keyboard.press('ArrowUp');
  130 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  131 |   await expect(page.getByRole('option', { name: '20', exact: true })).toBeFocused();
  132 |   await page.keyboard.press('Home'); await expect(page.getByRole('option', { name: '5', exact: true })).toBeFocused();
  133 |   const request = page.waitForRequest(r => r.url().includes('personnel/members/search') && fixtureRequestURL(r).searchParams.get('pageSize') === '5');
  134 |   await page.keyboard.press('Enter'); await request;
  135 |   await expect(trigger).toHaveAttribute('aria-expanded', 'false'); await expect(trigger).toBeFocused();
  136 | });
  137 | 
  138 | test('Q36 shrinking full result blocks pagination until explicit refresh instead of silently clamping', async ({ page }) => {
  139 |   await page.setViewportSize({ width: 1920, height: 1080 });
  140 |   await fixture(page, 20, 21);
  141 |   let recoveryRequests = 0;
  142 |   await page.route('**/api/v1/personnel/members/search', async route => {
  143 |     const p = Number(fixtureRequestURL(route.request()).searchParams.get('page') || 1);
  144 |     if (p === 1) recoveryRequests++;
  145 |     // Q36 PLAN + query-drafts: 21 → 20 invalidates the old result context.
  146 |     if(route.request().postDataJSON().queryVersion)return route.fulfill({status:409,json:{code:'COMMON_QUERY_CHANGED',message:'changed',data:null,meta:null}});
  147 |     await route.fulfill({ json: q36FixtureEnvelope({ items: Array.from({ length: 20 }, (_, i) => row(i)), total: 20, page: p, pageSize: 20 },route.request()) });
  148 |   });
> 149 |   await page.getByRole('button', { name: '下一页', exact: true }).click();
      |                                                                ^ Error: locator.click: Test timeout of 20000ms exceeded.
  150 |   await expect(page.getByRole('alert')).toContainText('查询结果已变化');
  151 |   expect(recoveryRequests).toBe(0);
  152 |   await expect(page.getByLabel('跳至页',{exact:true})).toHaveValue('1');
  153 |   await page.getByRole('button',{name:'刷新查询',exact:true}).click();
  154 |   await expect.poll(() => recoveryRequests).toBe(1);
  155 |   await expect(page.locator('.member-table tbody tr[data-row-id]')).toHaveCount(20);
  156 |   await expect(page.locator('.member-table')).toContainText('Zulu0');
  157 | });
  158 | 
  159 | test('Q35 narrow viewport keeps the original pager controls fully reachable', async ({ page }) => {
  160 |   await page.setViewportSize({ width: 320, height: 844 }); await fixture(page, 1, 125);
  161 |   const area = page.locator('.member-table');
  162 |   for (const control of [area.getByRole('combobox', { name: '每页条数', exact: true }), area.getByRole('button', { name: '下一页', exact: true })]) {
  163 |     await control.scrollIntoViewIfNeeded();
  164 |     const bounds = (await area.boundingBox())!, box = (await control.boundingBox())!;
  165 |     expect(box.x).toBeGreaterThanOrEqual(bounds.x);
  166 |     expect(box.x + box.width).toBeLessThanOrEqual(bounds.x + bounds.width);
  167 |   }
  168 |   await area.getByRole('combobox', { name: '每页条数', exact: true }).click();
  169 |   await page.getByRole('option', { name: '5', exact: true }).click();
  170 |   await expect(area.getByRole('combobox', { name: '每页条数', exact: true })).toHaveText('5');
  171 | });
  172 | 
  173 | test('Q35 source font uses Geist with the existing Chinese fallback inside its scope', async ({ page }) => {
  174 |   await fixture(page);
  175 |   const family = await page.locator('.member-table table').evaluate(n => getComputedStyle(n).fontFamily);
  176 |   expect(family).toContain('Geist Variable'); expect(family).toContain('Noto Sans SC');
  177 |   const outer = await page.locator('.personnel-page-heading').evaluate(n => getComputedStyle(n).fontFamily);
  178 |   expect(outer).toContain('Noto Sans SC'); expect(outer).not.toContain('Geist');
  179 | });
  180 | 
  181 | test('Q35 sorting menu stays open during its own scrolling and closes on table scrolling', async ({ page }) => {
  182 |   await page.setViewportSize({width:900,height:844});
  183 |   await fixture(page, 3);
  184 |   // Q36: the server time sort is the only eligible column.
  185 |   await page.getByRole('tab',{name:'操作记录',exact:true}).click();
  186 |   const table = page.locator('.activity-table');
  187 |   await expect(table.getByRole('table')).toHaveAttribute('aria-busy','false');
  188 |   await page.evaluate(()=>document.fonts.ready);
  189 |   const trigger = table.getByRole('button', { name: '排序 occurredAt', exact: true });
  190 |   await trigger.click();
  191 |   const menu = page.getByRole('menu');
  192 |   await expect(menu).toBeVisible();
  193 |   await menu.dispatchEvent('scroll');
  194 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  195 |   await menu.getByRole('menuitem', { name: '升序', exact: true }).click();
  196 |   await expect(table.getByRole('columnheader').filter({hasText:'时间'})).toHaveAttribute('aria-sort','ascending');
  197 |   await trigger.click();
  198 |   await expect(trigger).toHaveAttribute('aria-expanded', 'true');
  199 |   await table.locator('.el-scrollbar__wrap').evaluate(n=>{n.scrollLeft+=20;});
  200 |   await expect(trigger).toHaveAttribute('aria-expanded', 'false');
  201 | });
  202 | 
```