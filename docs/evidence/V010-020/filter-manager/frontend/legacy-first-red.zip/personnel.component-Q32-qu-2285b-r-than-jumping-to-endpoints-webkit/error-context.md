# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personnel.component.spec.ts >> Q32 quick reversal preserves the current menu height rather than jumping to endpoints
- Location: apps/web/src/personnel.component.spec.ts:219:1

# Error details

```
Error: expect(received).toBeLessThan(expected)

Expected: < 74
Received:   74
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - strong [ref=e7]: 管理后台
      - generic [ref=e8]:
        - button "草稿箱" [ref=e9] [cursor=pointer]
        - button "保存" [disabled] [ref=e10]
        - button "退出" [ref=e11] [cursor=pointer]
    - complementary [ref=e12]:
      - generic [ref=e13]: 管理功能
      - button "人员管理" [ref=e14] [cursor=pointer]
      - paragraph [ref=e16]: 成员 · 部门 · 身份 · 权限
    - main [ref=e17]:
      - generic [ref=e18]:
        - heading "人员管理" [level=1] [ref=e19]
        - paragraph [ref=e20]: 统一管理成员、部门、身份与应用访问。
      - tablist "人员管理视图" [ref=e21]:
        - generic [ref=e22]:
          - tab "成员与部门" [selected] [ref=e23] [cursor=pointer]
          - tab "身份" [ref=e24] [cursor=pointer]
          - tab "权限模板" [ref=e25] [cursor=pointer]
          - tab "操作记录" [ref=e26] [cursor=pointer]
      - button "刷新查询" [ref=e28] [cursor=pointer]
      - tabpanel "成员与部门" [ref=e29]:
        - generic [ref=e30]:
          - generic [ref=e31]:
            - heading "成员与部门" [level=2] [ref=e32]
            - paragraph [ref=e33]: 管理成员归属与身份，部门调整不改变访问权限
          - button "新建部门" [ref=e34] [cursor=pointer]
          - button "邀请成员" [ref=e35] [cursor=pointer]
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "部门 1" [level=3] [ref=e38]:
              - text: 部门
              - generic [ref=e39]: "1"
            - button "全部成员 1" [ref=e40] [cursor=pointer]:
              - text: 全部成员
              - generic [ref=e41]: "1"
            - button "企业 0" [ref=e42] [cursor=pointer]:
              - text: 企业
              - generic [ref=e43]: "0"
            - generic [ref=e44]:
              - button "重命名部门" [disabled] [ref=e45]
              - button "删除部门" [disabled] [ref=e46]
            - paragraph [ref=e47]: 部门只用于分组。移动成员不会自动改变身份或应用访问权限。
          - generic [ref=e48]:
            - generic [ref=e49]:
              - textbox "搜索成员" [ref=e51]
              - button "自定义筛选" [ref=e52] [cursor=pointer]
              - generic [ref=e53]: 1 位成员
              - generic [ref=e54]:
                - combobox "筛选身份" [expanded] [active] [ref=e55] [cursor=pointer]:
                  - generic [ref=e56]: 全部身份
                - listbox "筛选身份" [ref=e59]:
                  - option "全部身份" [selected] [ref=e60] [cursor=pointer]
                  - option "企业管理员" [ref=e61] [cursor=pointer]
            - generic [ref=e63]:
              - generic [ref=e64]:
                - generic "成员表格滚动区域" [ref=e65]:
                  - table "成员" [ref=e67]:
                    - rowgroup [ref=e68]:
                      - row [ref=e69]:
                        - columnheader [ref=e70]:
                          - checkbox "选择当前页成员" [ref=e73]
                        - columnheader "拖动以调整 account 列顺序 成员 Resize account column" [ref=e74]:
                          - generic [ref=e75]:
                            - button "拖动以调整 account 列顺序" [ref=e76]
                            - generic [ref=e79]: 成员
                          - button "Resize account column" [ref=e81]
                        - columnheader "拖动以调整 departments 列顺序 部门 Resize departments column" [ref=e82]:
                          - generic [ref=e83]:
                            - button "拖动以调整 departments 列顺序" [ref=e84]
                            - generic [ref=e87]: 部门
                          - button "Resize departments column" [ref=e89]
                        - columnheader "拖动以调整 identities 列顺序 身份 Resize identities column" [ref=e90]:
                          - generic [ref=e91]:
                            - button "拖动以调整 identities 列顺序" [ref=e92]
                            - generic [ref=e95]: 身份
                          - button "Resize identities column" [ref=e97]
                        - columnheader "拖动以调整 personnelManage 列顺序 人员管理 Resize personnelManage column" [ref=e98]:
                          - generic [ref=e99]:
                            - button "拖动以调整 personnelManage 列顺序" [ref=e100]
                            - generic [ref=e103]: 人员管理
                          - button "Resize personnelManage column" [ref=e105]
                        - columnheader "拖动以调整 actions 列顺序 操作 Resize actions column" [ref=e106]:
                          - generic [ref=e107]:
                            - button "拖动以调整 actions 列顺序" [ref=e108]
                            - generic [ref=e111]: 操作
                          - button "Resize actions column" [ref=e113]
                    - rowgroup [ref=e114]:
                      - row [ref=e115]:
                        - cell [ref=e116]:
                          - generic: "1"
                          - checkbox "选择成员：synthetic-admin" [ref=e119]
                        - cell "synthetic-admin 正常" [ref=e120]:
                          - generic "synthetic-admin" [ref=e121]:
                            - strong [ref=e122]: synthetic-admin
                            - generic [ref=e123]: 正常
                        - cell "未分组" [ref=e124]
                        - cell "Bootstrap Admin" [ref=e126]
                        - cell "默认拥有" [ref=e128]
                        - cell [ref=e130]:
                          - generic [ref=e131]:
                            - button "配置身份" [ref=e132]
                            - button "调整分组" [ref=e133]
                      - row [aria-hidden] [ref=e134]:
                        - cell [ref=e135]
                        - cell [ref=e136]
                        - cell [ref=e137]
                        - cell [ref=e138]
                        - cell [ref=e139]
                        - cell [ref=e140]
                      - row [aria-hidden] [ref=e141]:
                        - cell [ref=e142]
                        - cell [ref=e143]
                        - cell [ref=e144]
                        - cell [ref=e145]
                        - cell [ref=e146]
                        - cell [ref=e147]
                      - row [aria-hidden] [ref=e148]:
                        - cell [ref=e149]
                        - cell [ref=e150]
                        - cell [ref=e151]
                        - cell [ref=e152]
                        - cell [ref=e153]
                        - cell [ref=e154]
                      - row [aria-hidden] [ref=e155]:
                        - cell [ref=e156]
                        - cell [ref=e157]
                        - cell [ref=e158]
                        - cell [ref=e159]
                        - cell [ref=e160]
                        - cell [ref=e161]
                      - row [aria-hidden] [ref=e162]:
                        - cell [ref=e163]
                        - cell [ref=e164]
                        - cell [ref=e165]
                        - cell [ref=e166]
                        - cell [ref=e167]
                        - cell [ref=e168]
                      - row [aria-hidden] [ref=e169]:
                        - cell [ref=e170]
                        - cell [ref=e171]
                        - cell [ref=e172]
                        - cell [ref=e173]
                        - cell [ref=e174]
                        - cell [ref=e175]
                      - row [aria-hidden] [ref=e176]:
                        - cell [ref=e177]
                        - cell [ref=e178]
                        - cell [ref=e179]
                        - cell [ref=e180]
                        - cell [ref=e181]
                        - cell [ref=e182]
                      - row [aria-hidden] [ref=e183]:
                        - cell [ref=e184]
                        - cell [ref=e185]
                        - cell [ref=e186]
                        - cell [ref=e187]
                        - cell [ref=e188]
                        - cell [ref=e189]
                      - row [aria-hidden] [ref=e190]:
                        - cell [ref=e191]
                        - cell [ref=e192]
                        - cell [ref=e193]
                        - cell [ref=e194]
                        - cell [ref=e195]
                        - cell [ref=e196]
                      - row [aria-hidden] [ref=e197]:
                        - cell [ref=e198]
                        - cell [ref=e199]
                        - cell [ref=e200]
                        - cell [ref=e201]
                        - cell [ref=e202]
                        - cell [ref=e203]
                - generic [ref=e205] [cursor=pointer]
              - generic [ref=e206]:
                - generic [ref=e207]:
                  - generic [ref=e208]: 每页条数
                  - generic [ref=e209]:
                    - combobox "每页条数" [ref=e210]:
                      - generic [ref=e211]: "20"
                    - listbox [aria-hidden]:
                      - generic:
                        - generic:
                          - listitem:
                            - option: "5"
                          - listitem:
                            - option: "10"
                          - listitem:
                            - option [selected]: "20"
                          - listitem:
                            - option: "25"
                          - listitem:
                            - option: "50"
                          - listitem:
                            - option: "100"
                - generic [ref=e215]: 1 - 1 / 共 1 项
  - generic:
    - dialog [aria-hidden]:
      - generic:
        - banner:
          - heading [level=2]: 管理自定义筛选
          - button
        - generic:
          - button: 新增筛选
          - paragraph: 暂无自定义筛选
```

# Test source

```ts
  134 |  const last=page.getByRole('tab',{name:'操作记录',exact:true});await expect(last).toHaveAttribute('aria-selected','true');
  135 |  const bar=(await tabs.boundingBox())!,button=(await last.boundingBox())!;expect(button.x).toBeGreaterThanOrEqual(bar.x);expect(button.x+button.width).toBeLessThanOrEqual(bar.x+bar.width+1);
  136 |  expect(await tabs.evaluate(n=>n.scrollHeight===n.clientHeight)).toBe(true);
  137 |  await first.focus();await first.press('Enter');const search=page.getByLabel('搜索成员',{exact:true});await search.scrollIntoViewIfNeeded();await search.fill('固定布局');await expect(search).toHaveValue('固定布局');
  138 |  expect(await page.locator('.personnel-content').evaluate(n=>n.scrollTop)).toBeGreaterThan(0);
  139 |  const table=page.locator('.table-scroll');await table.evaluate(n=>{n.scrollLeft=n.scrollWidth;});expect(await table.evaluate(n=>n.scrollLeft)).toBeGreaterThan(0);
  140 |  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  141 | });
  142 | 
  143 | // Q32 oracle: user-selected Arca Select Menu / default Pill, R3 section 5.6.
  144 | // These tests exercise the real page; only the network boundary uses synthetic data.
  145 | test('Q32 identity select has the separated rounded menu and preserves server filtering',async({page})=>{
  146 |  await page.setViewportSize({width:1920,height:1080});await admin(page);
  147 |  const combo=page.getByRole('combobox',{name:'筛选身份',exact:true});
  148 |  await expect.soft(combo).toHaveCSS('height','38px');await expect.soft(combo).toHaveCSS('border-radius','12px');
  149 |  expect.soft(await combo.evaluate(n=>n.tagName)).toBe('BUTTON');await combo.click();
  150 |  const menu=page.getByRole('listbox',{name:'筛选身份',exact:true});await expect(menu).toBeVisible();
  151 |  await expect(menu).toHaveCSS('border-radius','12px');await expect(page.getByRole('option',{name:'全部身份',exact:true})).toHaveCSS('height','32px');
  152 |  await expect.poll(async()=>{const a=(await combo.boundingBox())!,b=(await menu.boundingBox())!;return Math.round(b.y-a.y-a.height);}).toBe(8);
  153 |  const queries:string[]=[];await page.route('**/api/v1/personnel/members/search',r=>{queries.push(fixtureRequestURL(r.request()).search);return r.fulfill({status:200,json:q36FixtureEnvelope(list([member]),r.request())});});
  154 |  await page.getByRole('option',{name:'企业管理员',exact:true}).click();await expect(combo).toContainText('企业管理员');await expect(combo).toBeFocused();
  155 |  await expect.poll(()=>queries.some(q=>new URLSearchParams(q).get('identityId')===identity.id)).toBe(true);
  156 |  await combo.press('ArrowDown');await combo.press('Home');await combo.press('Enter');await expect(combo).toContainText('全部身份');
  157 |  await expect.poll(()=>queries.some(q=>!new URLSearchParams(q).has('identityId'))).toBe(true);
  158 | });
  159 | 
  160 | test('Q32 grouped selectors keep modal focus and Escape first dismisses the menu',async({page})=>{
  161 |  await admin(page);await page.getByRole('button',{name:'调整分组',exact:true}).click();
  162 |  const operation=page.getByRole('combobox',{name:'分组操作',exact:true});expect(await operation.evaluate(n=>n.tagName)).toBe('BUTTON');
  163 |  await operation.press('ArrowDown');await operation.press('End');await operation.press('Enter');await expect(operation).toContainText('移动');
  164 |  for(const label of ['来源部门','目标部门']){const combo=page.getByRole('combobox',{name:label,exact:true});expect(await combo.evaluate(n=>n.tagName)).toBe('BUTTON');await expect(combo).toHaveCSS('height','38px');}
  165 |  const target=page.getByRole('combobox',{name:'目标部门',exact:true});await target.click();await expect(page.getByRole('listbox',{name:'目标部门',exact:true})).toBeVisible();
  166 |  await target.press('Escape');await expect(target).toHaveAttribute('aria-expanded','false');await expect(page.getByRole('dialog',{name:'调整成员分组',exact:true})).toBeVisible();await expect(target).toBeFocused();
  167 |  await target.press('Escape');await expect(page.getByRole('dialog',{name:'有未保存的修改',exact:true})).toBeVisible();
  168 |  await page.getByRole('button',{name:'继续编辑',exact:true}).click();await expect(operation).toContainText('移动');
  169 | });
  170 | 
  171 | test('Q32 parent department chooser uses options without closing the native modal',async({page})=>{
  172 |  await admin(page);await page.getByRole('button',{name:'新建部门',exact:true}).click();
  173 |  const combo=page.getByRole('combobox',{name:'父部门',exact:true});expect(await combo.evaluate(n=>n.tagName)).toBe('BUTTON');
  174 |  await combo.click();await page.getByRole('option',{name:'企业',exact:true}).click();await expect(combo).toBeFocused();await expect(page.getByRole('dialog',{name:'新建部门',exact:true})).toBeVisible();
  175 |  let sent:unknown;await page.route('**/api/v1/personnel/departments',r=>{if(r.request().method()!=='POST')return r.fallback();sent=r.request().postDataJSON();return r.fulfill({status:201,json:q36FixtureEnvelope(department,r.request())});});
  176 |  await page.getByLabel('部门名称',{exact:true}).fill('设计组');await page.getByRole('button',{name:'确认创建',exact:true}).click();await expect.poll(()=>sent).toEqual({name:'设计组',parentId:department.id,queryVersion:'synthetic-q36-context'});
  177 | });
  178 | 
  179 | test('Q32 long action menu stays in the viewport and keyboard chooses the final real action',async({page})=>{
  180 |  await page.setViewportSize({width:390,height:600});await admin(page);await page.getByRole('tab',{name:'操作记录',exact:true}).click();
  181 |  const combo=page.getByRole('combobox',{name:'操作类型',exact:true});expect(await combo.evaluate(n=>n.tagName)).toBe('BUTTON');await combo.press('ArrowDown');
  182 |  const menu=page.getByRole('listbox',{name:'操作类型',exact:true});await expect(menu).toBeVisible();
  183 |  await expect.poll(async()=>{const b=(await menu.boundingBox())!;return b.y>=7&&b.y+b.height<=593;}).toBe(true);
  184 |  expect(await menu.evaluate(n=>n.scrollHeight>n.clientHeight)).toBe(true);
  185 |  const queries:string[]=[];await page.route('**/api/v1/personnel/events/search',r=>{queries.push(fixtureRequestURL(r.request()).search);return r.fulfill({status:200,json:q36FixtureEnvelope(list([]),r.request())});});
  186 |  await combo.press('End');await combo.press('Enter');await expect(combo).toContainText('邀请成员');await expect.poll(()=>queries.some(q=>new URLSearchParams(q).get('action')==='INVITATION_CREATED')).toBe(true);
  187 |  await combo.click();await page.getByRole('heading',{name:'人员管理',exact:true}).click();await expect(combo).toHaveAttribute('aria-expanded','false');
  188 | });
  189 | 
  190 | test('Q32 pill indicator slides between tabs only after unsaved changes are resolved',async({page})=>{
  191 |  await page.setViewportSize({width:1920,height:1080});await admin(page);
  192 |  const indicator=page.locator('.personnel-tab-indicator');await expect(indicator).toHaveCount(1);await expect(indicator).toHaveCSS('background-color','rgb(23, 23, 23)');await expect(indicator).toHaveCSS('height','32px');
  193 |  await expect(page.getByRole('tablist')).toHaveCSS('height','48px');for(const tab of await page.getByRole('tab').all())await expect(tab).toHaveCSS('height','32px');
  194 |  const initial=(await indicator.boundingBox())!.x;
  195 |  const positions=await page.evaluate(async()=>{const el=document.querySelector('.personnel-tab-indicator')!;const samples:number[]=[];const done=new Promise<number[]>(resolve=>{const start=performance.now();function sample(){samples.push(el.getBoundingClientRect().x);if(performance.now()-start<900)requestAnimationFrame(sample);else resolve(samples);}requestAnimationFrame(sample);});(document.querySelectorAll('[role=tab]')[1] as HTMLElement).click();return done;});
  196 |  await expect(page.getByRole('tab',{name:'身份',exact:true})).toHaveAttribute('aria-selected','true');const end=(await indicator.boundingBox())!.x;expect(end).toBeGreaterThan(initial);expect(positions.some(x=>x>initial+1&&x<end-1)).toBe(true);
  197 |  await page.getByRole('button',{name:'企业管理员',exact:true}).click();await page.getByLabel('说明',{exact:true}).fill('待保存修改');const before=(await indicator.boundingBox())!.x;
  198 |  await page.getByRole('tab',{name:'权限模板',exact:true}).click();await expect(page.getByRole('dialog',{name:'有未保存的修改',exact:true})).toBeVisible();await expect(page.getByRole('tab',{name:'身份',exact:true})).toHaveAttribute('aria-selected','true');expect((await indicator.boundingBox())!.x).toBeCloseTo(before,0);
  199 |  await page.getByRole('button',{name:'继续编辑',exact:true}).click();await expect(page.getByLabel('说明',{exact:true})).toHaveValue('待保存修改');
  200 | });
  201 | 
  202 | test('Q32 reduced motion removes displacement and option stagger and keeps compact tabs reachable',async({page})=>{
  203 |  await page.emulateMedia({reducedMotion:'reduce'});await page.setViewportSize({width:390,height:844});await admin(page);
  204 |  const first=page.getByRole('tab',{name:'成员与部门',exact:true});await first.focus();await first.press('End');await page.keyboard.press('Enter');await expect(page.getByRole('tab',{name:'操作记录',exact:true})).toHaveAttribute('aria-selected','true');
  205 |  const last=(await page.getByRole('tab',{name:'操作记录',exact:true}).boundingBox())!,bar=(await page.getByRole('tablist').boundingBox())!;expect(last.x).toBeGreaterThanOrEqual(bar.x);expect(last.x+last.width).toBeLessThanOrEqual(bar.x+bar.width+1);
  206 |  expect(await page.getByRole('tablist').evaluate(n=>n.scrollHeight===n.clientHeight)).toBe(true);
  207 |  const combo=page.getByRole('combobox',{name:'操作类型',exact:true});await combo.click();const menu=page.getByRole('listbox',{name:'操作类型',exact:true});await expect(menu).toBeVisible();await expect(menu).toHaveCSS('transform','none');
  208 |  await expect(page.getByRole('option').first()).toHaveCSS('filter','none');await expect(page.getByRole('option').first()).toHaveCSS('animation-name','none');
  209 |  await combo.press('Tab');await expect(combo).toHaveAttribute('aria-expanded','false');
  210 | });
  211 | 
  212 | // Q31: current Figma75:2 /106:112 /113:425 fixes top56, removes collapse,
  213 | test('Q32 large directories expose the final option promptly after End',async({page})=>{
  214 |  await fixture(page);const choices=Array.from({length:100},(_,index)=>({...identity,id:'00000000-0000-4000-8000-'+String(index+200).padStart(12,'0'),name:'身份-'+String(index).padStart(3,'0')}));
  215 |  await page.route('**/api/v1/personnel/identities?**',r=>r.fulfill({status:200,json:q36FixtureEnvelope({...list(choices),pageSize:100},r.request())}));await page.goto('/app/admin');
  216 |  const combo=page.getByRole('combobox',{name:'筛选身份',exact:true});await combo.press('ArrowDown');await combo.press('End');const last=page.getByRole('option',{name:'身份-099',exact:true});await expect(last).toHaveCSS('opacity','1',{timeout:1000});await combo.press('Enter');await expect(combo).toContainText('身份-099');
  217 | });
  218 | 
  219 | test('Q32 quick reversal preserves the current menu height rather than jumping to endpoints',async({page})=>{
  220 |  await admin(page);
  221 |  const button=page.getByRole('combobox',{name:'筛选身份',exact:true});await button.click();
  222 |  // Two independent fixture choices: 2*32px + 8px padding + 2px border = 74px.
  223 |  await page.waitForFunction(()=>{const h=document.querySelector('[role=listbox]')!.getBoundingClientRect().height;return h>14&&h<64;});
  224 |  async function clickedFrame(){
  225 |   const sample=page.evaluate(()=>new Promise<{before:number;after:number;trusted:boolean}>(resolve=>{
  226 |    document.querySelector('[role=combobox]')!.addEventListener('click',event=>{
  227 |     const menu=document.querySelector('[role=listbox]')!;const before=menu.getBoundingClientRect().height;
  228 |     requestAnimationFrame(()=>resolve({before,after:menu.getBoundingClientRect().height,trusted:event.isTrusted}));
  229 |    },{capture:true,once:true});
  230 |   }));
  231 |   await button.click();return sample;
  232 |  }
  233 |  const closing=await clickedFrame(),reopening=await clickedFrame();
> 234 |  expect(closing.trusted&&reopening.trusted).toBe(true);expect(closing.before).toBeGreaterThan(10);expect(closing.before).toBeLessThan(74);
      |                                                                                                                          ^ Error: expect(received).toBeLessThan(expected)
  235 |  expect(Math.abs(closing.after-closing.before)).toBeLessThan(16);expect(Math.abs(reopening.after-reopening.before)).toBeLessThan(16);await expect(button).toHaveAttribute('aria-expanded','true');
  236 | });
  237 | 
  238 | test('Q32 searching below the tabs preserves the narrow-screen content scroll position',async({page})=>{
  239 |  await page.setViewportSize({width:390,height:600});await admin(page);const input=page.getByLabel('搜索成员',{exact:true});await input.scrollIntoViewIfNeeded();
  240 |  const content=page.locator('.personnel-content');await input.focus();const before=await content.evaluate(n=>n.scrollTop);expect(before).toBeGreaterThan(80);
  241 |  await input.fill('连续输入');await expect(input).toHaveValue('连续输入');await expect.poll(()=>content.evaluate(n=>n.scrollTop)).toBe(before);
  242 | });
  243 | 
  244 | test('Q32 upward expansion and closing stay attached to the trigger edge on every frame',async({page})=>{
  245 |  await page.setViewportSize({width:390,height:320});await fixture(page);const choices=Array.from({length:20},(_,index)=>({...department,id:'00000000-0000-4000-8000-'+String(index+400).padStart(12,'0'),name:'部门-'+index}));
  246 |  await page.route('**/api/v1/personnel/departments',r=>r.fulfill({status:200,json:q36FixtureEnvelope({items:choices},r.request())}));await page.goto('/app/admin');await page.getByRole('button',{name:'新建部门',exact:true}).click();
  247 |  const button=page.getByRole('combobox',{name:'父部门',exact:true});
  248 |  const sample=()=>page.evaluate(async()=>{
  249 |   const button=document.querySelector<HTMLButtonElement>('[aria-label="父部门"]')!;
  250 |   const points:{gap:number;height:number;side:string|undefined}[]=[];const start=performance.now();while(performance.now()-start<300){await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));const menu=document.querySelector<HTMLElement>('.personnel-select-menu[role=listbox]')!;const b=menu.getBoundingClientRect();points.push({gap:button.getBoundingClientRect().top-b.bottom,height:b.height,side:menu.dataset.side});}return points;
  251 |  });
  252 |  await button.click();const opening=await sample();await button.click();const closing=await sample();const samples={opening,closing};
  253 |  expect(samples.opening.every(point=>point.side==='above')).toBe(true);
  254 |  for(const point of [...samples.opening,...samples.closing]){expect(point.gap).toBeGreaterThanOrEqual(-1);expect(point.gap).toBeLessThanOrEqual(12);}
  255 |  expect(samples.opening.some(point=>point.height>10&&point.height<samples.opening.at(-1)!.height-10),JSON.stringify(samples)).toBe(true);
  256 | });
  257 | 
  258 | test('Q32 upward menus animate the corners adjacent to their trigger',async({page})=>{
  259 |  await page.setViewportSize({width:390,height:320});await fixture(page);const choices=Array.from({length:20},(_,index)=>({...department,id:'00000000-0000-4000-8000-'+String(index+400).padStart(12,'0'),name:'部门-'+index}));
  260 |  await page.route('**/api/v1/personnel/departments',r=>r.fulfill({status:200,json:q36FixtureEnvelope({items:choices},r.request())}));await page.goto('/app/admin');await page.getByRole('button',{name:'新建部门',exact:true}).click();
  261 |  const corners=await page.evaluate(async()=>{document.querySelector<HTMLButtonElement>('[aria-label="父部门"]')!.click();await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));const menu=document.querySelector<HTMLElement>('.personnel-select-menu[role=listbox]')!;const s=getComputedStyle(menu);return {side:menu.dataset.side,top:s.borderTopLeftRadius,bottom:s.borderBottomLeftRadius};});
  262 |  expect(corners.side).toBe('above');
  263 |  expect(parseFloat(corners.top)).toBe(12);expect(parseFloat(corners.bottom)).toBeLessThan(12);
  264 | });
  265 | 
  266 | // and moves both sidebar menus to y116; supersedes Q29/Q30 old top/menu geometry. Network fixtures isolate the real rendered components.
  267 | test('Q31 Home navigation stays 56px with no collapse control and retains account actions',async({page})=>{
  268 |  await page.setViewportSize({width:1920,height:1080});await fixture(page);await page.goto('/app');
  269 |  await expect.soft(page.locator('.home-header')).toHaveCSS('height','56px');
  270 |  for(const selector of ['.home-icon-button','.account-button']){const box=(await page.locator(selector).boundingBox())!;expect.soft(box.y).toBeGreaterThanOrEqual(0);expect.soft(box.y+box.height).toBeLessThanOrEqual(56);}
  271 |  await page.getByRole('button',{name:'账号',exact:true}).click();expect.soft((await page.locator('.account-menu').boundingBox())!.y).toBe(66);
  272 |  await expect.soft(page.getByRole('button',{name:/收起顶栏|展开顶栏/})).toHaveCount(0);await expect(page.locator('.account-menu')).toBeVisible();await expect(page.locator('.home-header')).toHaveCSS('height','56px');
  273 | });
  274 | 
  275 | test('Q33 admin uses fixed 56px top and 176px sidebar geometry across resize',async({page})=>{
  276 |  await page.setViewportSize({width:1920,height:1080});await page.emulateMedia({reducedMotion:'reduce'});await admin(page);
  277 |  for(const width of [1920,1440,390]){
  278 |   await page.setViewportSize({width,height:1080});
  279 |   await expect(page.getByRole('button',{name:/收起顶栏|展开顶栏|收起侧栏|展开侧栏/})).toHaveCount(0);await expect(page.getByRole('button',{name:'退出',exact:true})).toBeVisible();
  280 |   if(width>900)await expect(page.getByText('管理后台',{exact:true})).toBeVisible();
  281 |   await expect(page.locator('.admin-sidebar')).toHaveCSS('width','176px');await expect(page.locator('.admin-header')).toHaveCSS('height','56px');
  282 |   const content=(await page.locator('.personnel-content').boundingBox())!;expect({x:content.x,y:content.y,width:content.width,height:content.height}).toEqual({x:176,y:56,width:width-176,height:1024});
  283 |   const menu=(await page.locator('.personnel-nav').boundingBox())!;expect({x:menu.x,y:menu.y,width:menu.width,height:menu.height}).toEqual({x:16,y:116,width:144,height:48});
  284 |   const icon=(await page.locator('.personnel-nav-icon').boundingBox())!;expect({x:icon.x,y:icon.y,width:icon.width,height:icon.height}).toEqual({x:26,y:130,width:20,height:20});
  285 |  }
  286 | });
  287 | 
  288 | // Q33 supersedes the historical folding oracle. The visible L material still
  289 | // fills the viewport; navigation geometry remains fixed during resize/hover.
  290 | test('Q31 tabs have no vertical overflow and compact layouts retain keyboard access to the last tab',async({page})=>{
  291 |  await page.setViewportSize({width:1920,height:1080});await admin(page);
  292 |  const tabs=page.getByRole('tablist');await expect.soft(tabs).toHaveCSS('height','48px');await expect.soft(tabs).toHaveCSS('overflow-y','hidden');
  293 |  const desktop=await tabs.evaluate(n=>({height:n.clientHeight,scrollHeight:n.scrollHeight,buttons:[...n.querySelectorAll('button')].map(b=>b.getBoundingClientRect().height)}));
  294 |  // Q32 replaces the old 47px underline buttons with the confirmed 32px Pill.
  295 |  expect.soft(desktop.scrollHeight).toBe(desktop.height);expect.soft(desktop.buttons).toEqual([32,32,32,32]);
  296 |  expect.soft(await tabs.evaluate(n=>{n.scrollTop=10;return n.scrollTop;})).toBe(0);
  297 |  await page.setViewportSize({width:390,height:844});await page.goto('/app/admin');await expect(page.getByRole('tab',{name:'成员与部门',exact:true})).toBeVisible();
  298 |  const last=page.getByRole('tab',{name:'操作记录',exact:true});await last.focus();await last.press('Enter');await expect(last).toHaveAttribute('aria-selected','true');
  299 |  const bounds=(await tabs.boundingBox())!,button=(await last.boundingBox())!;expect(button.x).toBeGreaterThanOrEqual(bounds.x);expect(button.x+button.width).toBeLessThanOrEqual(bounds.x+bounds.width+1);
  300 |  expect(await tabs.evaluate(n=>n.scrollLeft)).toBeGreaterThan(0);expect(await tabs.evaluate(n=>n.scrollTop)).toBe(0);
  301 | });
  302 | 
  303 | test('Q31 real member overflow remains scrollable while the tab strip has no vertical scrollbar',async({page})=>{
  304 |  await page.setViewportSize({width:1440,height:600});await fixture(page);
  305 |  const members=Array.from({length:20},(_,i)=>({...member,id:'00000000-0000-4000-8000-'+String(i+100).padStart(12,'0'),account:'synthetic-row-'+String(i).padStart(2,'0')}));
  306 |  await page.route('**/api/v1/personnel/members/search',r=>r.fulfill({status:200,json:q36FixtureEnvelope(list(members),r.request())}));await page.goto('/app/admin');
  307 |  const last=page.getByRole('row').filter({hasText:'synthetic-row-19'});
  308 |  const table=page.locator('.table-scroll');expect(await table.evaluate(n=>n.scrollHeight>n.clientHeight)).toBe(true);
  309 |  await table.evaluate(n=>{n.scrollTop=n.scrollHeight;});expect(await table.evaluate(n=>n.scrollTop)).toBeGreaterThan(0);await expect(last).toHaveCount(1);
  310 |  const box=(await table.boundingBox())!,row=(await last.boundingBox())!;expect(row.y).toBeGreaterThanOrEqual(box.y);expect(row.y+row.height).toBeLessThanOrEqual(box.y+box.height+1);
  311 |  await page.setViewportSize({width:390,height:844});await table.evaluate(n=>{n.scrollLeft=n.scrollWidth;});expect(await table.evaluate(n=>n.scrollLeft)).toBeGreaterThan(0);
  312 | });
  313 | 
  314 | async function materialAlpha(page:Page) {
  315 |  return page.locator('.admin-material').evaluate(async(node)=>{
  316 |   const box=node.getBoundingClientRect();const canvas=document.createElement('canvas');canvas.width=innerWidth;canvas.height=innerHeight;
  317 |   const context=canvas.getContext('2d')!;let source:HTMLImageElement;
  318 |   if(node instanceof HTMLImageElement)source=node;else{source=new Image();source.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(new XMLSerializer().serializeToString(node));await source.decode();}
  319 |   context.drawImage(source,box.x,box.y,box.width,box.height);
  320 |   return [[innerWidth-12,12],[12,innerHeight-12]].map(([x,y])=>context.getImageData(x,y,1,1).data[3]);
  321 |  });
  322 | }
  323 | for(const viewport of [{width:2504,height:1355},{width:1440,height:900},{width:390,height:844}])test('Q33 material fills viewport '+viewport.width+'x'+viewport.height+' with a fixed sidebar and after resize',async({page})=>{
  324 |  await page.setViewportSize(viewport);await admin(page);await page.emulateMedia({reducedMotion:'reduce'});
  325 |  // 0.76 fill plus the original translucent shadow; require real coverage.
  326 |  await expect.poll(async()=> (await materialAlpha(page)).every(a=>a>=190&&a<=200)).toBe(true);
  327 |  await expect(page.locator('.admin-sidebar')).toHaveCSS('width','176px');
  328 |  if(viewport.width===2504)await page.screenshot({path:test.info().outputPath('large-fixed-'+test.info().project.name+'.png')});
  329 |  await page.setViewportSize({width:viewport.width+173,height:viewport.height+129});await expect.poll(async()=> (await materialAlpha(page)).every(a=>a>=190&&a<=200)).toBe(true);
  330 |  await expect(page.locator('.admin-sidebar')).toHaveCSS('width','176px');
  331 | });
  332 | 
  333 | test('Q33 hover retains fixed navigation width and icon centerline on every frame',async({page})=>{
  334 |  await page.setViewportSize({width:1920,height:1080});await admin(page);await page.locator('.personnel-nav').hover();
```