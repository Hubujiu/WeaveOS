# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personnel.component.spec.ts >> Q34 Arca table geometry and readable rows on 操作记录
- Location: apps/web/src/personnel.component.spec.ts:27:89

# Error details

```
Error: expect(received).toBeCloseTo(expected, precision)

Expected: 40.5
Received: 40

Expected precision:    1
Expected difference: < 0.05
Received difference:   0.5
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - strong [ref=e7]: 管理后台
      - generic [ref=e8]:
        - button "草稿箱" [ref=e9] [cursor=pointer]
        - button "保存" [disabled] [ref=e10]
        - button "退出" [ref=e11] [cursor=pointer]
    - complementary [ref=e12]:
      - generic [ref=e13]: 管理功能
      - button "人员管理" [ref=e14] [cursor=pointer]
      - paragraph [ref=e16]: 成员 · 部门 · 身份 · 权限
    - main [ref=e17]:
      - generic [ref=e18]:
        - heading "人员管理" [level=1] [ref=e19]
        - paragraph [ref=e20]: 统一管理成员、部门、身份与应用访问。
      - tablist "人员管理视图" [ref=e21]:
        - generic [ref=e22]:
          - tab "成员与部门" [ref=e23] [cursor=pointer]
          - tab "身份" [ref=e24] [cursor=pointer]
          - tab "权限模板" [ref=e25] [cursor=pointer]
          - tab "操作记录" [active] [selected] [ref=e26] [cursor=pointer]
      - button "刷新查询" [ref=e28] [cursor=pointer]
      - tabpanel "操作记录" [ref=e29]:
        - generic [ref=e30]:
          - generic [ref=e31]:
            - heading "操作记录" [level=2] [ref=e32]
            - paragraph [ref=e33]: 查看成员、部门与权限配置的变更记录
          - combobox "操作类型" [ref=e35] [cursor=pointer]:
            - generic [ref=e36]: 全部操作
        - generic [ref=e39]:
          - generic [ref=e40]:
            - textbox "搜索操作记录" [ref=e42]:
              - /placeholder: 搜索成员或操作对象
            - button "自定义筛选" [ref=e43] [cursor=pointer]
            - paragraph [ref=e44]: 记录仅包含配置变更，不展示密码或邀请码明文。
            - group [ref=e45]:
              - generic "最近 7 天" [ref=e46] [cursor=pointer]
          - generic [ref=e48]:
            - generic "操作记录表格滚动区域" [ref=e50]:
              - table "操作记录" [ref=e52]:
                - rowgroup [ref=e53]:
                  - row [ref=e54]:
                    - columnheader "拖动以调整 occurredAt 列顺序 时间 排序 occurredAt Resize occurredAt column" [ref=e55]:
                      - generic [ref=e56]:
                        - button "拖动以调整 occurredAt 列顺序" [ref=e57]
                        - generic [ref=e60]:
                          - generic [ref=e61]: 时间
                          - button "排序 occurredAt" [ref=e62]
                      - button "Resize occurredAt column" [ref=e65]
                    - columnheader "拖动以调整 actorAccount 列顺序 操作者 Resize actorAccount column" [ref=e66]:
                      - generic [ref=e67]:
                        - button "拖动以调整 actorAccount 列顺序" [ref=e68]
                        - generic [ref=e71]: 操作者
                      - button "Resize actorAccount column" [ref=e73]
                    - columnheader "拖动以调整 action 列顺序 操作 Resize action column" [ref=e74]:
                      - generic [ref=e75]:
                        - button "拖动以调整 action 列顺序" [ref=e76]
                        - generic [ref=e79]: 操作
                      - button "Resize action column" [ref=e81]
                    - columnheader "拖动以调整 object 列顺序 对象 Resize object column" [ref=e82]:
                      - generic [ref=e83]:
                        - button "拖动以调整 object 列顺序" [ref=e84]
                        - generic [ref=e87]: 对象
                      - button "Resize object column" [ref=e89]
                    - columnheader "拖动以调整 detail 列顺序 变更内容 Resize detail column" [ref=e90]:
                      - generic [ref=e91]:
                        - button "拖动以调整 detail 列顺序" [ref=e92]
                        - generic [ref=e95]: 变更内容
                      - button "Resize detail column" [ref=e97]
                    - columnheader "拖动以调整 outcome 列顺序 结果 Resize outcome column" [ref=e98]:
                      - generic [ref=e99]:
                        - button "拖动以调整 outcome 列顺序" [ref=e100]
                        - generic [ref=e103]: 结果
                      - button "Resize outcome column" [ref=e105]
                - rowgroup [ref=e106]:
                  - row [ref=e107]:
                    - cell "2026/10/1 02:00:00" [ref=e108]
                    - cell "synthetic-admin" [ref=e110]
                    - cell "修改身份" [ref=e112]
                    - cell "企业管理员" [ref=e114]
                    - cell "名称：旧身份 → 企业管理员" [ref=e116]
                    - cell "已完成" [ref=e118]
                  - row [aria-hidden] [ref=e120]:
                    - cell [ref=e121]
                    - cell [ref=e122]
                    - cell [ref=e123]
                    - cell [ref=e124]
                    - cell [ref=e125]
                    - cell [ref=e126]
                  - row [aria-hidden] [ref=e127]:
                    - cell [ref=e128]
                    - cell [ref=e129]
                    - cell [ref=e130]
                    - cell [ref=e131]
                    - cell [ref=e132]
                    - cell [ref=e133]
                  - row [aria-hidden] [ref=e134]:
                    - cell [ref=e135]
                    - cell [ref=e136]
                    - cell [ref=e137]
                    - cell [ref=e138]
                    - cell [ref=e139]
                    - cell [ref=e140]
                  - row [aria-hidden] [ref=e141]:
                    - cell [ref=e142]
                    - cell [ref=e143]
                    - cell [ref=e144]
                    - cell [ref=e145]
                    - cell [ref=e146]
                    - cell [ref=e147]
                  - row [aria-hidden] [ref=e148]:
                    - cell [ref=e149]
                    - cell [ref=e150]
                    - cell [ref=e151]
                    - cell [ref=e152]
                    - cell [ref=e153]
                    - cell [ref=e154]
                  - row [aria-hidden] [ref=e155]:
                    - cell [ref=e156]
                    - cell [ref=e157]
                    - cell [ref=e158]
                    - cell [ref=e159]
                    - cell [ref=e160]
                    - cell [ref=e161]
                  - row [aria-hidden] [ref=e162]:
                    - cell [ref=e163]
                    - cell [ref=e164]
                    - cell [ref=e165]
                    - cell [ref=e166]
                    - cell [ref=e167]
                    - cell [ref=e168]
                  - row [aria-hidden] [ref=e169]:
                    - cell [ref=e170]
                    - cell [ref=e171]
                    - cell [ref=e172]
                    - cell [ref=e173]
                    - cell [ref=e174]
                    - cell [ref=e175]
                  - row [aria-hidden] [ref=e176]:
                    - cell [ref=e177]
                    - cell [ref=e178]
                    - cell [ref=e179]
                    - cell [ref=e180]
                    - cell [ref=e181]
                    - cell [ref=e182]
                  - row [aria-hidden] [ref=e183]:
                    - cell [ref=e184]
                    - cell [ref=e185]
                    - cell [ref=e186]
                    - cell [ref=e187]
                    - cell [ref=e188]
                    - cell [ref=e189]
                  - row [aria-hidden] [ref=e190]:
                    - cell [ref=e191]
                    - cell [ref=e192]
                    - cell [ref=e193]
                    - cell [ref=e194]
                    - cell [ref=e195]
                    - cell [ref=e196]
                  - row [aria-hidden] [ref=e197]:
                    - cell [ref=e198]
                    - cell [ref=e199]
                    - cell [ref=e200]
                    - cell [ref=e201]
                    - cell [ref=e202]
                    - cell [ref=e203]
            - generic [ref=e204]:
              - generic [ref=e205]:
                - generic [ref=e206]: 每页条数
                - generic [ref=e207]:
                  - combobox "每页条数" [ref=e208]:
                    - generic [ref=e209]: "20"
                  - listbox [aria-hidden]:
                    - generic:
                      - generic:
                        - listitem:
                          - option: "5"
                        - listitem:
                          - option: "10"
                        - listitem:
                          - option [selected]: "20"
                        - listitem:
                          - option: "25"
                        - listitem:
                          - option: "50"
                        - listitem:
                          - option: "100"
              - generic [ref=e213]: 1 - 1 / 共 1 项
  - generic:
    - dialog [aria-hidden]:
      - generic:
        - banner:
          - heading [level=2]: 管理自定义筛选
          - button
        - generic:
          - button: 新增筛选
          - paragraph: 暂无自定义筛选
  - generic:
    - menu [aria-hidden]:
      - generic:
        - generic:
          - generic:
            - menuitem: 升序
          - generic:
            - menuitem: 降序
```

# Test source

```ts
  1   | import {fixtureRequestURL,q36FixtureEnvelope} from './personnel-query-fixtures';
  2   | import { test, expect, type Page } from '@playwright/test';
  3   | import { readFileSync } from 'node:fs';
  4   | 
  5   | // Independent oracle: personnel PRD R3 UI AC01–07, Q25 DTOs, Figma Home/Admin.
  6   | const user = {id:'00000000-0000-4000-8000-000000000001',account:'synthetic-admin'};
  7   | const identity = {id:'00000000-0000-4000-8000-000000000002',name:'企业管理员',description:'共享身份',version:1,templateIds:['00000000-0000-4000-8000-000000000003'],permissionCodes:[],affectedMembers:2,affectedIdentities:0};
  8   | const template = {id:'00000000-0000-4000-8000-000000000003',name:'企业管理',description:'共享模板',version:1,permissionCodes:['personnel.manage'],affectedMembers:2,affectedIdentities:1};
  9   | const department = {id:'00000000-0000-4000-8000-000000000004',name:'企业',parentId:null,isRoot:true,version:1,memberCount:0,childrenCount:0};
  10  | const catalog=[{code:'personnel.manage',name:'人员管理',category:'system',appId:null,enabled:true}];
  11  | const member={...user,status:'active',bootstrapAdmin:true,version:0,departmentIds:[],identityIds:[],departments:[],identities:[],permissions:catalog};
  12  | function list(items: unknown[]) {return {items,total:items.length,page:1,pageSize:20};}
  13  | async function fixture(page:Page,manage=true) {
  14  |  await page.route('**/api/v1/**',async route=>{
  15  |   const path=fixtureRequestURL(route.request()).pathname.replace('/api/v1/','');
  16  |   const data=path==='sessions/current'?user:path==='sessions'?user:path==='me/access'?{user,bootstrapAdmin:manage,personnelManage:manage,identities:[],permissions:manage?catalog:[],applications:[]}:
  17  |    path==='personnel/departments'?{items:[department]}:path==='personnel/permissions'?{items:catalog}:
  18  |    path==='personnel/identities'?list([identity]):path==='personnel/templates'?list([template]):path==='personnel/members'?list([member]):path==='personnel/members/'+user.id?member:path==='personnel/events'?list([]):{};
  19  |   await route.fulfill({status:route.request().method()==='DELETE'?204:200,contentType:'application/json',body:route.request().method()==='DELETE'?'':JSON.stringify(q36FixtureEnvelope(data,route.request()))});
  20  |  });
  21  | }
  22  | async function admin(page:Page){await fixture(page);await page.goto('/app/admin');await expect(page.getByRole('tab',{name:'成员与部门',exact:true})).toBeVisible();}
  23  | async function chooseOption(page:Page,label:string,option:string){await page.getByRole('combobox',{name:label,exact:true}).click();await page.getByRole('option',{name:option,exact:true}).click();}
  24  | 
  25  | // Q35 supersedes identity/max360/native selection under synced R3 5.8; fixed
  26  | // Arca c0319d8 official default. Network fixtures exercise the real page controls.
  27  | for(const [tab,root] of [['成员与部门','.member-table'],['操作记录','.activity-table']] as const)test('Q34 Arca table geometry and readable rows on '+tab,async({page})=>{
  28  |  await page.setViewportSize({width:1920,height:1080});await fixture(page);
  29  |  await page.route('**/api/v1/personnel/events/search',r=>r.fulfill({json:q36FixtureEnvelope(list([{id:user.id,occurredAt:'2026-10-01T02:00:00Z',actorAccount:user.account,action:'IDENTITY_UPDATED',objectType:'identity',objectId:identity.id,summary:{before:{name:'旧身份'},after:{name:identity.name}},outcome:'success'}]),r.request())}));
  30  |  await page.goto('/app/admin');if(tab!=='成员与部门')await page.getByRole('tab',{name:tab,exact:true}).click();
  31  |  const area=page.locator(root),table=area.getByRole('table');await expect(table).toHaveCount(1);
  32  |  await expect.soft(area).toHaveCSS('border-radius','14px');await expect.soft(area).toHaveCSS('border-top-width','1px');
  33  |  const header=table.locator('th').nth(tab==='成员与部门'?1:0),cell=table.locator('tbody tr[data-row-id] td').last();
  34  |  // Official c0319d8 measured header is 40.5px due to collapsed grid border;
  35  |  // nominal rowHeight stays 40. See q35 upstream official-default-computed.txt.
> 36  |  expect.soft((await header.boundingBox())!.height).toBeCloseTo(40.5,1);
      |                                                    ^ Error: expect(received).toBeCloseTo(expected, precision)
  37  |  expect.soft((await table.locator('tbody tr').first().boundingBox())!.height).toBeCloseTo(40,0);
  38  |  await expect.soft(header).toHaveCSS('font-size','14px');await expect.soft(header).toHaveCSS('line-height','20px');await expect.soft(header).toHaveCSS('font-weight','500');
  39  |  await expect.soft(header).toHaveCSS('text-align','center');
  40  |  await expect.soft(cell).toHaveCSS('line-height','20px');await expect.soft(table).toHaveCSS('table-layout','fixed');
  41  |  await expect(area.locator('.table-scroll')).toHaveCSS('max-height','none');
  42  |  await expect(table.locator('th[aria-sort]')).toHaveCount(tab==='成员与部门'?0:1);
  43  |  await page.screenshot({path:test.info().outputPath('q35-'+(tab==='成员与部门'?'members':'activity')+'.png'),fullPage:true});
  44  | });
  45  | 
  46  | test('Q34 page selection exposes mixed state without writing and shows selected rows',async({page})=>{
  47  |  await fixture(page);const another={...member,id:'00000000-0000-4000-8000-000000000099',account:'synthetic-second'};
  48  |  await page.route('**/api/v1/personnel/members/search',r=>r.fulfill({json:q36FixtureEnvelope(list([member,another]),r.request())}));await page.goto('/app/admin');
  49  |  let writes=0;page.on('request',r=>{if(r.url().includes('/api/v1/')&&!['GET','HEAD'].includes(r.method())&&!r.url().endsWith('/search'))writes++;});
  50  |  await page.getByLabel('选择成员：'+user.account,{exact:true}).check();
  51  |  const all=page.getByLabel('选择当前页成员',{exact:true});await expect.soft(all).toHaveAttribute('aria-checked','mixed');
  52  |  const row=page.getByRole('row').filter({hasText:user.account});await expect.soft(row).toHaveAttribute('aria-selected','true');
  53  |  await all.check();await expect(page.getByLabel('选择成员：synthetic-second',{exact:true})).toBeChecked();await all.uncheck();await expect(page.getByLabel('选择成员：'+user.account,{exact:true})).not.toBeChecked();expect(writes).toBe(0);
  54  | });
  55  | 
  56  | test('Q35 identity cards preserve edit entry, shared fields and unsaved switch protection',async({page})=>{
  57  |  await fixture(page);const another={...identity,id:'00000000-0000-4000-8000-000000000098',name:'财务身份',description:'独立示例说明'};
  58  |  await page.route('**/api/v1/personnel/identities?**',r=>r.fulfill({json:q36FixtureEnvelope(list([identity,another]),r.request())}));await page.goto('/app/admin');await page.getByRole('tab',{name:'身份',exact:true}).click();
  59  |  const table=page.locator('.definition-list');await expect(table.getByRole('table')).toHaveCount(0);await expect(table.locator('.definition-item')).toHaveCount(2);
  60  |  await table.getByRole('button',{name:identity.name,exact:true}).focus();await page.keyboard.press('Enter');await page.getByLabel('说明',{exact:true}).fill('未保存说明');
  61  |  await table.getByRole('button',{name:another.name,exact:true}).click();await expect(page.getByRole('dialog',{name:'有未保存的修改',exact:true})).toBeVisible();await page.getByRole('button',{name:'继续编辑',exact:true}).click();
  62  |  await expect(page.getByLabel('说明',{exact:true})).toHaveValue('未保存说明');await expect(table.getByRole('button',{name:identity.name,exact:true})).toHaveClass(/selected/);
  63  |  await expect(table.getByRole('button',{name:another.name,exact:true})).toContainText(another.description);
  64  |  await page.screenshot({path:test.info().outputPath('q34-identity-editor.png'),fullPage:true});
  65  | });
  66  | 
  67  | for(const width of [1920,320])test('Q34 dense table keeps sticky header and both scroll axes at '+width,async({page})=>{
  68  |  await page.setViewportSize({width,height:844});await fixture(page);
  69  |  const rows=Array.from({length:20},(_,i)=>({...member,id:'row-'+i,account:'synthetic-row-'+i}));
  70  |  await page.route('**/api/v1/personnel/members/search',r=>r.fulfill({json:q36FixtureEnvelope(list(rows),r.request())}));await page.goto('/app/admin');
  71  |  const scroll=page.locator('.member-table .table-scroll');await scroll.scrollIntoViewIfNeeded();expect(await scroll.evaluate(n=>n.scrollHeight>n.clientHeight)).toBe(true);
  72  |  const th=scroll.locator('th').first(),start=(await th.boundingBox())!.y;await scroll.evaluate(n=>{n.scrollTop=200;});expect((await th.boundingBox())!.y).toBeCloseTo(start,0);await expect(th).toHaveCSS('position','sticky');
  73  |  if(width===320){
  74  |   await scroll.evaluate(n=>{n.scrollTop=0;n.scrollLeft=n.scrollWidth;});expect(await scroll.evaluate(n=>n.scrollLeft)).toBeGreaterThan(0);
  75  |   for(const name of ['配置身份','调整分组']){const action=page.getByRole('button',{name,exact:true}).first();await action.scrollIntoViewIfNeeded();await expect(action).toBeInViewport();expect(await scroll.evaluate(n=>n.scrollLeft)).toBeGreaterThan(0);}
  76  |  }
  77  |  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  78  |  await page.screenshot({path:test.info().outputPath('q34-scroll-'+width+'.png'),fullPage:true});
  79  | });
  80  | 
  81  | test('Q35 identity empty list and reduced motion preserve accessible states',async({page})=>{
  82  |  await page.emulateMedia({reducedMotion:'reduce'});await fixture(page);await page.route('**/api/v1/personnel/identities?**',r=>r.fulfill({json:q36FixtureEnvelope(list([]),r.request())}));await page.goto('/app/admin');await page.getByRole('tab',{name:'身份',exact:true}).click();
  83  |  const table=page.locator('.definition-list');await expect(table.getByRole('table')).toHaveCount(0);await expect(table).toContainText('暂无身份');
  84  |  await page.getByRole('tab',{name:'成员与部门',exact:true}).click();await expect(page.locator('.member-table tbody tr').first()).toHaveCSS('transition-duration','0s');
  85  | });
  86  | 
  87  | test('Q34 keyboard focus ring stays visible inside truncated table cells',async({page})=>{
  88  |  await admin(page);
  89  |  await page.keyboard.press('Tab');const name=page.locator('.member-table').getByRole('button',{name:'配置身份',exact:true});await name.focus();await expect(name).toBeFocused();
  90  |  const ring=await name.evaluate(n=>{const b=n.getBoundingClientRect(),clip=n.parentElement!.getBoundingClientRect(),style=getComputedStyle(n),outset=parseFloat(style.outlineOffset)+parseFloat(style.outlineWidth);return {style:style.outlineStyle,width:parseFloat(style.outlineWidth),left:b.left-outset,right:b.right+outset,top:b.top-outset,bottom:b.bottom+outset,clip:{left:clip.left,right:clip.right,top:clip.top,bottom:clip.bottom}};});
  91  |  expect(ring.style).not.toBe('none');expect(ring.width).toBeGreaterThan(0);
  92  |  expect.soft(ring.left).toBeGreaterThanOrEqual(ring.clip.left);expect.soft(ring.right).toBeLessThanOrEqual(ring.clip.right);expect.soft(ring.top).toBeGreaterThanOrEqual(ring.clip.top);expect.soft(ring.bottom).toBeLessThanOrEqual(ring.clip.bottom);
  93  |  await page.screenshot({path:test.info().outputPath('q34-focus.png'),fullPage:true});
  94  | });
  95  | 
  96  | test('Q34 reverse keyboard navigation keeps row actions below the sticky header',async({page})=>{
  97  |  await page.setViewportSize({width:1920,height:844});await fixture(page);const rows=Array.from({length:20},(_,i)=>({...member,id:'keyboard-'+i,account:'synthetic-keyboard-'+i}));
  98  |  await page.route('**/api/v1/personnel/members/search',r=>r.fulfill({json:q36FixtureEnvelope(list(rows),r.request())}));await page.goto('/app/admin');
  99  |  const actions=page.getByRole('button',{name:'配置身份',exact:true});await actions.last().focus();await page.keyboard.press('Tab');
  100 |  const bottom=(await page.locator('.member-table th').first().boundingBox())!.y+40;
  101 |  for(let i=0;i<15;i++){await page.keyboard.press('Shift+Tab');const focused=page.locator('.personnel-data-table :focus');await expect(focused).toHaveCount(1);expect((await focused.boundingBox())!.y).toBeGreaterThanOrEqual(bottom);}
  102 | });
  103 | 
  104 | // Q33 oracle: user removal + synced R3 5.3–5.5 and Figma Admin 108:151.
  105 | // Fixed 176px sidebar on every viewport; no collapse entry or hidden navigation.
  106 | for(const width of [2504,1920,900,390,320])test('Q33 sidebar stays expanded with no collapse control at '+width,async({page})=>{
  107 |  await page.setViewportSize({width,height:844});await admin(page);
  108 |  await expect.soft(page.getByRole('button',{name:/收起侧栏|展开侧栏/})).toHaveCount(0);
  109 |  await expect.soft(page.locator('.admin-sidebar')).toHaveCSS('width','176px');
  110 |  await expect.soft(page.locator('.admin-header')).toHaveCSS('height','56px');
  111 |  await expect.soft(page.locator('.personnel-nav-label')).toBeVisible();await expect.soft(page.locator('.personnel-nav-label')).toHaveCSS('opacity','1');
  112 |  await expect.soft(page.locator('.sidebar-caption').first()).toBeVisible();
  113 |  const menu=(await page.getByRole('button',{name:'人员管理',exact:true}).boundingBox())!;
  114 |  expect.soft({x:menu.x,y:menu.y,width:menu.width,height:menu.height}).toEqual({x:16,y:116,width:144,height:48});
  115 |  expect.soft(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  116 | });
  117 | 
  118 | test('Q33 crossing responsive breakpoints preserves navigation, dirty input and explicit leave protection',async({page})=>{
  119 |  await page.setViewportSize({width:1920,height:1080});await admin(page);await page.getByRole('tab',{name:'身份',exact:true}).click();await page.getByRole('button',{name:'企业管理员',exact:true}).click();await page.getByLabel('身份名称',{exact:true}).fill('固定侧栏保留草稿');
  120 |  let writes=0;page.on('request',r=>{if(r.url().includes('/api/v1/')&&!['GET','HEAD'].includes(r.method())&&!r.url().endsWith('/search'))writes++;});
  121 |  for(const width of [390,320,900,1920]){
  122 |   await page.setViewportSize({width,height:844});await expect.soft(page.locator('.admin-sidebar')).toHaveCSS('width','176px');
  123 |   await expect(page.getByLabel('身份名称',{exact:true})).toHaveValue('固定侧栏保留草稿');await expect(page.getByRole('tab',{name:'身份',exact:true})).toHaveAttribute('aria-selected','true');
  124 |   await expect(page.getByRole('button',{name:'保存',exact:true})).toBeVisible();await expect(page.getByRole('button',{name:'退出',exact:true})).toBeVisible();
  125 |  }
  126 |  expect(writes).toBe(0);await page.getByRole('button',{name:'退出',exact:true}).click();await expect(page.getByRole('dialog',{name:'有未保存的修改',exact:true})).toBeVisible();
  127 |  await page.getByRole('button',{name:'继续编辑',exact:true}).click();await expect(page.getByLabel('身份名称',{exact:true})).toHaveValue('固定侧栏保留草稿');expect(writes).toBe(0);
  128 | });
  129 | 
  130 | for(const width of [390,320])test('Q33 fixed sidebar retains narrow keyboard tabs and real content scrolling at '+width,async({page})=>{
  131 |  await page.emulateMedia({reducedMotion:'reduce'});await page.setViewportSize({width,height:600});await admin(page);
  132 |  await expect.soft(page.locator('.admin-sidebar')).toHaveCSS('width','176px');
  133 |  const tabs=page.getByRole('tablist'),first=page.getByRole('tab',{name:'成员与部门',exact:true});await first.focus();await first.press('End');await page.keyboard.press('Enter');
  134 |  const last=page.getByRole('tab',{name:'操作记录',exact:true});await expect(last).toHaveAttribute('aria-selected','true');
  135 |  const bar=(await tabs.boundingBox())!,button=(await last.boundingBox())!;expect(button.x).toBeGreaterThanOrEqual(bar.x);expect(button.x+button.width).toBeLessThanOrEqual(bar.x+bar.width+1);
  136 |  expect(await tabs.evaluate(n=>n.scrollHeight===n.clientHeight)).toBe(true);
```