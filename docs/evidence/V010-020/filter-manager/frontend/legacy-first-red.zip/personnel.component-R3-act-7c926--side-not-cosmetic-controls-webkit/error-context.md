# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personnel.component.spec.ts >> R3 activity search and action filter are server-side, not cosmetic controls
- Location: apps/web/src/personnel.component.spec.ts:438:1

# Error details

```
Error: browserContext.close: ENOSPC: no space left on device, write
```