# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: filter-manager.component.spec.ts >> narrow typed condition retains a readable field name beside NULL controls
- Location: apps/web/src/filter-manager.component.spec.ts:125:1

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 92
Received:    42
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - generic [ref=e7]:
        - button "草稿箱" [ref=e8] [cursor=pointer]
        - button "保存" [disabled] [ref=e9]
        - button "退出" [ref=e10] [cursor=pointer]
    - complementary [ref=e11]:
      - generic [ref=e12]: 管理功能
      - button "人员管理" [ref=e13] [cursor=pointer]
      - paragraph [ref=e15]: 成员 · 部门 · 身份 · 权限
    - main [ref=e16]:
      - generic [ref=e17]:
        - heading "人员管理" [level=1] [ref=e18]
        - paragraph [ref=e19]: 统一管理成员、部门、身份与应用访问。
      - tablist "人员管理视图" [ref=e20]:
        - generic [ref=e21]:
          - tab "成员与部门" [ref=e22] [cursor=pointer]
          - tab "身份" [ref=e23] [cursor=pointer]
          - tab "权限模板" [ref=e24] [cursor=pointer]
          - tab "操作记录" [selected] [ref=e25] [cursor=pointer]
      - button "刷新查询" [ref=e27] [cursor=pointer]
      - tabpanel "操作记录" [ref=e28]:
        - generic [ref=e29]:
          - generic [ref=e30]:
            - heading "操作记录" [level=2] [ref=e31]
            - paragraph [ref=e32]: 查看成员、部门与权限配置的变更记录
          - combobox "操作类型" [ref=e34] [cursor=pointer]:
            - generic [ref=e35]: 全部操作
        - generic [ref=e38]:
          - generic [ref=e39]:
            - textbox "搜索操作记录" [ref=e41]:
              - /placeholder: 搜索成员或操作对象
            - button "自定义筛选" [expanded] [ref=e43] [cursor=pointer]
            - dialog [ref=e46]:
              - generic [ref=e47]:
                - banner [ref=e48]:
                  - heading "新增自定义筛选" [level=2] [ref=e49]
                  - button "关闭筛选管理" [ref=e50] [cursor=pointer]
                - generic [ref=e53]:
                  - generic [ref=e54]:
                    - text: 自定义筛选名称 *
                    - textbox "自定义筛选名称" [ref=e55]:
                      - /placeholder: 请输入自定义筛选名称
                  - heading "配置筛选条件" [level=3] [ref=e56]
                  - group "且条件组 1" [ref=e58]:
                    - generic [ref=e59]: 且条件
                    - generic [ref=e60]:
                      - combobox "条件 1.1 字段" [ref=e61]:
                        - option "请选择字段"
                        - option "操作者账号" [selected]
                        - option "对象"
                        - option "详情"
                        - option "操作"
                        - option "结果"
                        - option "发生时间"
                      - combobox "条件 1.1 比较" [ref=e62]:
                        - option "等于" [selected]
                        - option "不等于"
                      - combobox "条件 1.1 值类型" [ref=e63]:
                        - option "值"
                        - option "空值" [selected]
                      - generic [ref=e64]: 空值（NULL）
                      - button "删除条件 1.1" [ref=e65] [cursor=pointer]
                    - button "组 1 且条件" [ref=e68] [cursor=pointer]: 且条件
                  - button "或条件" [active] [ref=e71] [cursor=pointer]
                  - heading "设置显隐字段" [level=3] [ref=e74]
                  - generic [ref=e75]:
                    - region "隐藏字段" [ref=e76]:
                      - heading "隐藏字段" [level=4] [ref=e77]
                      - textbox "隐藏字段搜索" [ref=e78]:
                        - /placeholder: 输入关键词进行搜索
                      - paragraph [ref=e80]: 暂无字段
                    - region "显示字段" [ref=e81]:
                      - heading "显示字段" [level=4] [ref=e82]
                      - textbox "显示字段搜索" [ref=e83]:
                        - /placeholder: 输入关键词进行搜索
                      - generic [ref=e84]:
                        - generic [ref=e85]:
                          - generic [ref=e86]: 时间
                          - button "隐藏时间" [ref=e87] [cursor=pointer]
                        - generic [ref=e90]:
                          - generic [ref=e91]: 操作者
                          - button "隐藏操作者" [ref=e92] [cursor=pointer]
                        - generic [ref=e95]:
                          - generic [ref=e96]: 操作
                          - button "隐藏操作" [ref=e97] [cursor=pointer]
                        - generic [ref=e100]:
                          - generic [ref=e101]: 对象
                          - button "隐藏对象" [ref=e102] [cursor=pointer]
                        - generic [ref=e105]:
                          - generic [ref=e106]: 详情
                          - button "隐藏详情" [ref=e107] [cursor=pointer]
                        - generic [ref=e110]:
                          - generic [ref=e111]: 结果
                          - button "隐藏结果" [ref=e112] [cursor=pointer]
                  - paragraph [ref=e115]: 隐藏字段仍参与筛选与排序。至少保留一个业务字段；选择、序号和操作列始终显示。
                - contentinfo [ref=e116]:
                  - generic [ref=e117]: 1 / 20 条件
                  - button "取消" [ref=e118] [cursor=pointer]
                  - button "确定" [ref=e119] [cursor=pointer]
            - paragraph [ref=e121]: 记录仅包含配置变更，不展示密码或邀请码明文。
            - group [ref=e122]:
              - generic "最近 7 天" [ref=e123] [cursor=pointer]
          - generic [ref=e125]:
            - generic [ref=e126]:
              - generic "操作记录表格滚动区域" [ref=e127]:
                - table "操作记录" [ref=e129]:
                  - rowgroup [ref=e137]:
                    - row [ref=e138]:
                      - columnheader "拖动以调整 occurredAt 列顺序 时间 排序 occurredAt Resize occurredAt column" [ref=e139]:
                        - generic [ref=e140]:
                          - button "拖动以调整 occurredAt 列顺序" [ref=e141]
                          - generic [ref=e144]:
                            - generic [ref=e145]: 时间
                            - button "排序 occurredAt" [ref=e146]
                        - button "Resize occurredAt column" [ref=e149]
                      - columnheader "拖动以调整 actorAccount 列顺序 操作者 Resize actorAccount column" [ref=e150]:
                        - generic [ref=e151]:
                          - button "拖动以调整 actorAccount 列顺序" [ref=e152]
                          - generic [ref=e155]: 操作者
                        - button "Resize actorAccount column" [ref=e157]
                      - columnheader "拖动以调整 action 列顺序 操作 Resize action column" [ref=e158]:
                        - generic [ref=e159]:
                          - button "拖动以调整 action 列顺序" [ref=e160]
                          - generic [ref=e163]: 操作
                        - button "Resize action column" [ref=e165]
                      - columnheader "拖动以调整 object 列顺序 对象 Resize object column" [ref=e166]:
                        - generic [ref=e167]:
                          - button "拖动以调整 object 列顺序" [ref=e168]
                          - generic [ref=e171]: 对象
                        - button "Resize object column" [ref=e173]
                      - columnheader "拖动以调整 detail 列顺序 变更内容 Resize detail column" [ref=e174]:
                        - generic [ref=e175]:
                          - button "拖动以调整 detail 列顺序" [ref=e176]
                          - generic [ref=e179]: 变更内容
                        - button "Resize detail column" [ref=e181]
                      - columnheader "拖动以调整 outcome 列顺序 结果 Resize outcome column" [ref=e182]:
                        - generic [ref=e183]:
                          - button "拖动以调整 outcome 列顺序" [ref=e184]
                          - generic [ref=e187]: 结果
                        - button "Resize outcome column" [ref=e189]
                  - rowgroup [ref=e190]:
                    - row [aria-hidden] [ref=e191]:
                      - cell [ref=e192]
                      - cell [ref=e193]
                      - cell [ref=e194]
                      - cell [ref=e195]
                      - cell [ref=e196]
                      - cell [ref=e197]
                    - row [aria-hidden] [ref=e198]:
                      - cell [ref=e199]
                      - cell [ref=e200]
                      - cell [ref=e201]
                      - cell [ref=e202]
                      - cell [ref=e203]
                      - cell [ref=e204]
                    - row [aria-hidden] [ref=e205]:
                      - cell [ref=e206]
                      - cell [ref=e207]
                      - cell [ref=e208]
                      - cell [ref=e209]
                      - cell [ref=e210]
                      - cell [ref=e211]
                    - row [aria-hidden] [ref=e212]:
                      - cell [ref=e213]
                      - cell [ref=e214]
                      - cell [ref=e215]
                      - cell [ref=e216]
                      - cell [ref=e217]
                      - cell [ref=e218]
                    - row [aria-hidden] [ref=e219]:
                      - cell [ref=e220]
                      - cell [ref=e221]
                      - cell [ref=e222]
                      - cell [ref=e223]
                      - cell [ref=e224]
                      - cell [ref=e225]
                    - row [aria-hidden] [ref=e226]:
                      - cell [ref=e227]
                      - cell [ref=e228]
                      - cell [ref=e229]
                      - cell [ref=e230]
                      - cell [ref=e231]
                      - cell [ref=e232]
                    - row [aria-hidden] [ref=e233]:
                      - cell [ref=e234]
                      - cell [ref=e235]
                      - cell [ref=e236]
                      - cell [ref=e237]
                      - cell [ref=e238]
                      - cell [ref=e239]
                    - row [aria-hidden] [ref=e240]:
                      - cell [ref=e241]
                      - cell [ref=e242]
                      - cell [ref=e243]
                      - cell [ref=e244]
                      - cell [ref=e245]
                      - cell [ref=e246]
                    - row [aria-hidden] [ref=e247]:
                      - cell [ref=e248]
                      - cell [ref=e249]
                      - cell [ref=e250]
                      - cell [ref=e251]
                      - cell [ref=e252]
                      - cell [ref=e253]
                    - row [aria-hidden] [ref=e254]:
                      - cell [ref=e255]
                      - cell [ref=e256]
                      - cell [ref=e257]
                      - cell [ref=e258]
                      - cell [ref=e259]
                      - cell [ref=e260]
                    - row [aria-hidden] [ref=e261]:
                      - cell [ref=e262]
                      - cell [ref=e263]
                      - cell [ref=e264]
                      - cell [ref=e265]
                      - cell [ref=e266]
                      - cell [ref=e267]
                    - row [aria-hidden] [ref=e268]:
                      - cell [ref=e269]
                      - cell [ref=e270]
                      - cell [ref=e271]
                      - cell [ref=e272]
                      - cell [ref=e273]
                      - cell [ref=e274]
                    - row [aria-hidden] [ref=e275]:
                      - cell [ref=e276]
                      - cell [ref=e277]
                      - cell [ref=e278]
                      - cell [ref=e279]
                      - cell [ref=e280]
                      - cell [ref=e281]
              - generic [ref=e283] [cursor=pointer]
              - status: 暂无操作记录
            - generic [ref=e284]:
              - generic [ref=e285]:
                - generic [ref=e286]: 每页条数
                - generic [ref=e287]:
                  - combobox "每页条数" [ref=e288]:
                    - generic [ref=e289]: "20"
                  - listbox [aria-hidden]:
                    - generic:
                      - generic:
                        - listitem:
                          - option: "5"
                        - listitem:
                          - option: "10"
                        - listitem:
                          - option [selected]: "20"
                        - listitem:
                          - option: "25"
                        - listitem:
                          - option: "50"
                        - listitem:
                          - option: "100"
              - generic [ref=e293]:
                - generic [ref=e294]: 1 - 20 / 共 40 项
                - navigation "Pagination" [ref=e295]:
                  - button "上一页" [disabled]
                  - button "Page 1" [ref=e296]: "1"
                  - button "Page 2" [ref=e297]: "2"
                  - button "下一页" [ref=e298]
                  - generic [ref=e299]:
                    - generic [ref=e300]:
                      - text: 跳至页
                      - spinbutton "跳至页" [ref=e301]: "1"
                    - button "跳转到指定页" [ref=e302]
  - generic:
    - menu [aria-hidden]:
      - generic:
        - generic:
          - generic:
            - menuitem: 升序
          - generic:
            - menuitem: 降序
```

# Test source

```ts
  27  |    const input=req.postDataJSON();state.queries.push(input);
  28  |    if(state.queryError&&input.filter)return route.fulfill({status:409,json:{code:state.queryError,message:'conflict',data:null,meta:null}});
  29  |    return route.fulfill({json:envelope({items:path.includes('members')?[member]:[],total:40,page:input.page,pageSize:input.pageSize,queryVersion:'cloud-context',sort:null,...(path.includes('events')?{range:{from:'2026-09-24T00:00:00Z',to:'2026-10-02T00:00:00Z'}}:{})})});
  30  |   }
  31  |   const data=path==='sessions/current'?user:path==='me/access'?{user,bootstrapAdmin:true,personnelManage:true,identities:[],permissions:[],applications:[]}:
  32  |    path==='personnel/departments'||path==='personnel/permissions'||path==='personnel/drafts'?{items:[]}:
  33  |    path==='personnel/identities'||path==='personnel/templates'?{items:[],total:0,page:1,pageSize:20}:{};
  34  |   return route.fulfill({json:envelope(data)});
  35  |  });
  36  |  await page.goto('/app/admin');await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');return state;
  37  | }
  38  | async function manager(page:Page){await page.getByRole('button',{name:/^自定义筛选/}).click();const dialog=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await expect(dialog).toBeVisible();return dialog;}
  39  | async function editor(page:Page,panel:Locator){await panel.getByRole('button',{name:'新增筛选',exact:true}).click();const dialog=page.getByRole('dialog',{name:'新增自定义筛选',exact:true});await expect(dialog).toBeVisible();return dialog;}
  40  | async function addRow(dialog:Locator,value='preset-admin'){await dialog.getByRole('button',{name:'或条件',exact:true}).click();await dialog.getByLabel('条件 1.1 值',{exact:true}).fill(value);}
  41  | 
  42  | test('approved empty manager opens at viewport center with explicit new action',async({page})=>{
  43  |  await fixture(page);const panel=await manager(page);await expect(panel.getByRole('button',{name:'新增筛选',exact:true})).toBeVisible();await expect(panel.getByLabel('自定义筛选名称')).toHaveCount(0);
  44  |  const box=(await panel.boundingBox())!;expect(Math.abs(box.x+box.width/2-720)).toBeLessThan(2);expect(Math.abs(box.y+box.height/2-500)).toBeLessThan(2);expect(box.width).toBe(440);
  45  | });
  46  | test('save finite OR of AND blocks and typed comparison without applying',async({page})=>{
  47  |  const state=await fixture(page);const d=await editor(page,await manager(page));await d.getByLabel('自定义筛选名称',{exact:true}).fill('  团队筛选  ');await addRow(d);
  48  |  await d.getByRole('button',{name:'组 1 且条件',exact:true}).click();await d.getByLabel('条件 1.2 字段',{exact:true}).selectOption('status');await d.getByLabel('条件 1.2 值',{exact:true}).selectOption('active');
  49  |  await d.getByRole('button',{name:'或条件',exact:true}).click();await d.getByLabel('条件 2.1 值',{exact:true}).fill('另一个成员');await d.getByLabel('条件 2.1 比较',{exact:true}).selectOption('neq');
  50  |  await d.getByRole('button',{name:'确定',exact:true}).click();await expect.poll(()=>state.writes.length).toBe(1);
  51  |  expect(state.writes[0].body).toMatchObject({name:'团队筛选',filter:{operator:'or',children:[{operator:'and',children:[{field:'account',operator:'eq',value:'preset-admin'},{field:'status',operator:'eq',value:'active'}]},{operator:'and',children:[{field:'account',operator:'neq',value:'另一个成员'}]}]},hiddenColumnIds:[],schemaVersion:1,view:'members'});
  52  |  expect(state.queries.every(q=>!q.filter)).toBe(true);await expect(page.getByRole('dialog',{name:'管理自定义筛选',exact:true})).toBeVisible();
  53  | });
  54  | test('visibility-only save has independent searches and keeps at least one business field',async({page})=>{
  55  |  const state=await fixture(page);const d=await editor(page,await manager(page));await d.getByLabel('自定义筛选名称',{exact:true}).fill('显隐配置');
  56  |  await d.getByLabel('显示字段搜索',{exact:true}).fill('部门');await expect(d.getByRole('button',{name:'隐藏部门',exact:true})).toBeVisible();await expect(d.getByRole('button',{name:'隐藏身份',exact:true})).toHaveCount(0);await d.getByRole('button',{name:'隐藏部门',exact:true}).click();
  57  |  await d.getByLabel('隐藏字段搜索',{exact:true}).fill('身份');await expect(d.getByRole('region',{name:'隐藏字段',exact:true})).toContainText('暂无字段');await d.getByLabel('隐藏字段搜索',{exact:true}).fill('');await expect(d.getByRole('button',{name:'显示部门',exact:true})).toBeVisible();
  58  |  await d.getByLabel('显示字段搜索',{exact:true}).fill('');for(const name of ['成员','身份'])await d.getByRole('button',{name:'隐藏'+name,exact:true}).click();await expect(d.getByRole('button',{name:'隐藏人员管理',exact:true})).toBeDisabled();
  59  |  await expect(d.getByRole('button',{name:'隐藏操作',exact:true})).toHaveCount(0);await d.getByRole('button',{name:'确定',exact:true}).click();await expect.poll(()=>state.writes.length).toBe(1);expect(state.writes[0].body.filter).toBeNull();expect(state.queries.every(q=>q.hiddenColumnIds===undefined)).toBe(true);
  60  | });
  61  | test('apply latest resource resets page selection while preserving search quick filters and queryVersion',async({page})=>{
  62  |  const state=await fixture(page,[saved()]);await page.getByLabel('搜索成员',{exact:true}).fill('preset');await expect.poll(()=>state.queries.at(-1)?.search).toBe('preset');await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect.poll(()=>state.queries.at(-1)?.page).toBe(2);await page.getByLabel('选择成员：preset-admin',{exact:true}).check();
  63  |  const panel=await manager(page);await panel.getByRole('button',{name:'应用方案甲',exact:true}).click();await expect.poll(()=>state.queries.at(-1)?.filter).toEqual(eq);expect(state.queries.at(-1)).toMatchObject({page:1,search:'preset',queryVersion:'cloud-context'});expect(state.reads).toContain('personnel/table-presets/'+presetA);
  64  |  await expect(page.getByLabel('选择成员：preset-admin',{exact:true})).not.toBeChecked();await expect(page.locator('.member-table thead')).not.toContainText('部门');await expect(page.locator('.member-table thead')).toContainText('操作');
  65  |  await expect(panel.getByText('已应用',{exact:true})).toHaveCount(1);
  66  | });
  67  | test('editing applied preset saves new version but preserves applied snapshot until explicit apply',async({page})=>{
  68  |  const state=await fixture(page,[saved()]);const panel=await manager(page);await panel.getByRole('button',{name:'应用方案甲',exact:true}).click();await expect.poll(()=>state.queries.at(-1)?.filter).toEqual(eq);const before=state.queries.length;
  69  |  await panel.getByRole('button',{name:'编辑方案甲',exact:true}).click();const d=page.getByRole('dialog',{name:'编辑自定义筛选',exact:true});await d.getByLabel('条件 1.1 值',{exact:true}).fill('另一个成员');await d.getByRole('button',{name:'显示部门',exact:true}).click();await d.getByRole('button',{name:'确定',exact:true}).click();await expect(panel).toContainText('已修改，待应用');expect(state.queries.length).toBe(before);await expect(page.locator('.member-table thead')).not.toContainText('部门');
  70  | });
  71  | test('switch A to B then cancel restores original visibility and does not restore A baseline',async({page})=>{
  72  |  const state=await fixture(page,[saved(),saved(presetB,'方案乙',['identities'])]);const panel=await manager(page);await panel.getByRole('button',{name:'应用方案甲',exact:true}).click();await expect(page.locator('.member-table thead')).not.toContainText('部门');await panel.getByRole('button',{name:'应用方案乙',exact:true}).click();await expect(page.locator('.member-table thead')).not.toContainText('身份');await expect(page.locator('.member-table thead')).toContainText('部门');await expect(panel.getByText('已应用',{exact:true})).toHaveCount(1);
  73  |  await panel.getByRole('button',{name:'取消应用',exact:true}).click();const confirm=page.getByRole('dialog',{name:'取消当前筛选',exact:true});await expect(confirm).toBeVisible();await confirm.getByRole('button',{name:'确认取消',exact:true}).click();await expect(page.locator('.member-table thead')).toContainText('部门');await expect(page.locator('.member-table thead')).toContainText('身份');await expect.poll(()=>state.queries.at(-1)?.filter).toBeUndefined();
  74  | });
  75  | test('delete active requires confirmation then clears filter and restores columns',async({page})=>{
  76  |  const state=await fixture(page,[saved()]);const panel=await manager(page);await panel.getByRole('button',{name:'应用方案甲',exact:true}).click();await expect(page.locator('.member-table thead')).not.toContainText('部门');await panel.getByRole('button',{name:'删除方案甲',exact:true}).click();const d=page.getByRole('dialog',{name:'删除筛选方案',exact:true});await expect(d).toContainText('取消当前应用');await d.getByRole('button',{name:'确认删除',exact:true}).click();await expect.poll(()=>state.presets.length).toBe(0);await expect(page.locator('.member-table thead')).toContainText('部门');
  77  | });
  78  | for(const code of ['PERSONNEL_PRESET_NAME_CONFLICT','PERSONNEL_PRESET_LIMIT_REACHED','PERSONNEL_PRESET_CONFLICT'])test(code+' preserves editor input with specific recovery',async({page})=>{
  79  |  const cas=code==='PERSONNEL_PRESET_CONFLICT',state=await fixture(page,cas?[saved()]:[]);state.conflict=code;const managerPanel=await manager(page);let d:Locator;if(cas){await managerPanel.getByRole('button',{name:'编辑方案甲',exact:true}).click();d=page.getByRole('dialog',{name:'编辑自定义筛选',exact:true});}else d=await editor(page,managerPanel);await d.getByLabel('自定义筛选名称',{exact:true}).fill('保留我');await d.getByRole('button',{name:'确定',exact:true}).click();await expect(d.getByRole('alert')).toContainText(code==='PERSONNEL_PRESET_NAME_CONFLICT'?'名称已存在':code==='PERSONNEL_PRESET_LIMIT_REACHED'?'20':'其他标签页');await expect(d.getByLabel('自定义筛选名称',{exact:true})).toHaveValue('保留我');if(cas){expect(state.writes[0]).toMatchObject({method:'PUT',body:{version:1}});await expect(d.getByRole('button',{name:'重新加载最新方案',exact:true})).toBeVisible();}
  80  | });
  81  | for(const code of ['COMMON_QUERY_CHANGED','COMMON_QUERY_CONTEXT_EXPIRED'])test('failed '+code+' apply cannot change active filter visibility or refresh automatically',async({page})=>{
  82  |  const state=await fixture(page,[saved()]);state.queryError=code;const panel=await manager(page);await panel.getByRole('button',{name:'应用方案甲',exact:true}).click();await expect(panel.getByRole('alert')).toContainText(code==='COMMON_QUERY_CHANGED'?'查询结果已变化':'查询上下文已过期');await expect(panel.getByText('已应用',{exact:true})).toHaveCount(0);await expect(page.locator('.member-table thead')).toContainText('部门');expect(state.queries.at(-1)?.queryVersion).toBe('cloud-context');await expect(page.getByRole('button',{name:'刷新查询',exact:true})).toBeVisible();
  83  | });
  84  | test('reopening and reloading do not autoapply persisted presets',async({page})=>{
  85  |  const state=await fixture(page,[saved()]);const p=await manager(page);await p.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(p).toHaveCount(0);await manager(page);expect(state.queries.every(q=>!q.filter)).toBe(true);await page.reload();await expect(page.locator('.member-table thead')).toContainText('部门');expect(state.queries.every(q=>!q.filter)).toBe(true);
  86  | });
  87  | test('invalid empty intermediate row stays editable and cannot be saved',async({page})=>{
  88  |  const state=await fixture(page);const d=await editor(page,await manager(page));await d.getByLabel('自定义筛选名称',{exact:true}).fill('未完成条件');await d.getByRole('button',{name:'或条件',exact:true}).click();await d.getByLabel('条件 1.1 字段',{exact:true}).selectOption('identityIds');await d.getByRole('button',{name:'确定',exact:true}).click();await expect(d.getByRole('alert')).toContainText('1.1');expect(state.writes).toHaveLength(0);await d.getByRole('button',{name:'删除条件 1.1',exact:true}).click();await d.getByRole('button',{name:'确定',exact:true}).click();await expect.poll(()=>state.writes.length).toBe(1);
  89  | });
  90  | test('narrow centered editor scrolls body with fixed footer and keyboard move controls',async({page})=>{
  91  |  await fixture(page);await page.setViewportSize({width:390,height:844});const d=await editor(page,await manager(page));await d.getByLabel('自定义筛选名称',{exact:true}).fill('窄屏');await addRow(d);for(let i=2;i<=20;i++){await d.getByRole('button',{name:'组 1 且条件',exact:true}).click();await d.getByLabel(`条件 1.${i} 值`,{exact:true}).fill('成员'+i);}
  92  |  const box=(await d.boundingBox())!;expect(box.x).toBeGreaterThanOrEqual(12);expect(box.x+box.width).toBeLessThanOrEqual(378);expect(box.y).toBeGreaterThanOrEqual(12);expect(box.y+box.height).toBeLessThanOrEqual(832);await expect(d.getByRole('button',{name:'确定',exact:true})).toBeInViewport();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  93  | });
  94  | test('open close reopen last intent survives transition and reduced motion remains operable',async({page})=>{
  95  |  await fixture(page);const p=await manager(page);await page.evaluate(()=>{(document.querySelector('[aria-label="关闭筛选管理"]') as HTMLButtonElement).click();(document.querySelector('.q36-filter-trigger') as HTMLButtonElement).click();});await expect(p).toBeVisible();await expect.poll(()=>page.evaluate(()=>document.documentElement.classList.contains('q36-filter-transition-active'))).toBe(false);await page.keyboard.press('Escape');await expect(p).toHaveCount(0);await page.emulateMedia({reducedMotion:'reduce'});await manager(page);await page.keyboard.press('Escape');await expect(p).toHaveCount(0);await expect(page.getByRole('button',{name:/^自定义筛选/})).toBeFocused();
  96  | });
  97  | test('single Arca Table hides by stable ID and preserves hidden width/order through visible resize',async({page})=>{
  98  |  await page.goto('/src/filter-manager-table-fixture.html');const table=page.getByRole('table',{name:'显隐保序',exact:true});
  99  |  await expect(table.locator('thead th')).toHaveText(['丙','乙','甲']);await page.getByRole('button',{name:'切换乙列',exact:true}).click();await expect(table.locator('thead th')).toHaveText(['丙','甲']);
  100 |  await expect(table.locator('tbody')).not.toContainText('乙数据');
  101 |  expect((await table.locator('thead th').filter({hasText:'丙'}).boundingBox())!.width).toBeCloseTo(240,0);
  102 |  const grip=table.locator('thead th').filter({hasText:'丙'}).locator('[data-resize-handle]');const box=(await grip.boundingBox())!;await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2+30,box.y+box.height/2);await page.mouse.up();
  103 |  expect(JSON.parse(await page.locator('output').innerText()).widths.b).toBe(200);await page.getByRole('button',{name:'切换乙列',exact:true}).click();await expect(table.locator('thead th')).toHaveText(['丙','乙','甲']);expect(JSON.parse(await page.locator('output').innerText()).order).toEqual(['c','b','a']);
  104 | });
  105 | test('frozen text empty string stays a typed value and is distinct from zero conditions',async({page})=>{
  106 |  const state=await fixture(page);const d=await editor(page,await manager(page));await d.getByLabel('自定义筛选名称',{exact:true}).fill('空文本值');await d.getByRole('button',{name:'或条件',exact:true}).click();await d.getByRole('button',{name:'确定',exact:true}).click();await expect.poll(()=>state.writes.length).toBe(1);expect(state.writes[0].body.filter).toEqual({operator:'and',children:[{field:'account',operator:'eq',value:''}]});
  107 | });
  108 | test('successful active delete and later query failure are reported separately with old snapshot retained',async({page})=>{
  109 |  const state=await fixture(page,[saved()]);const p=await manager(page);await p.getByRole('button',{name:'应用方案甲',exact:true}).click();await expect(page.locator('.member-table thead')).not.toContainText('部门');state.queryError='COMMON_QUERY_CHANGED';
  110 |  await page.route('**/personnel/members/search',route=>{state.queries.push(route.request().postDataJSON());return route.fulfill({status:409,json:{code:'COMMON_QUERY_CHANGED',message:'changed',data:null,meta:null}});});
  111 |  await p.getByRole('button',{name:'删除方案甲',exact:true}).click();await page.getByRole('dialog',{name:'删除筛选方案',exact:true}).getByRole('button',{name:'确认删除',exact:true}).click();await expect.poll(()=>state.presets.length).toBe(0);await expect(p.getByRole('alert')).toContainText('方案已删除');await expect(p.getByRole('alert')).toContainText('查询结果已变化');await expect(page.locator('.member-table thead')).not.toContainText('部门');await expect(p.getByRole('button',{name:'取消应用',exact:true})).toBeVisible();
  112 | });
  113 | test('unsupported runtime tree cannot be silently flattened by edit or applied as a full query',async({page})=>{
  114 |  const original={operator:'or',children:[{field:'account',operator:'eq',value:'preset-admin'}]},state=await fixture(page,[saved(presetA,'复杂原树',[],original)]);const p=await manager(page);await p.getByRole('button',{name:'编辑复杂原树',exact:true}).click();await expect(p.getByRole('alert')).toContainText('已保留原条件');expect(state.presets[0].filter).toEqual(original);expect(state.writes).toHaveLength(0);await p.getByRole('button',{name:'应用复杂原树',exact:true}).click();await expect(p.getByRole('alert')).toContainText('仅支持');expect(state.queries.every(q=>!q.filter)).toBe(true);
  115 | });
  116 | test('visibility-only applies without a query and deletion of nonactive does not change the snapshot',async({page})=>{
  117 |  const state=await fixture(page,[saved(presetA,'只隐藏', ['identities'],null),saved(presetB,'未应用')]);const before=state.queries.length,p=await manager(page);await p.getByRole('button',{name:'应用只隐藏',exact:true}).click();await expect(page.locator('.member-table thead')).not.toContainText('身份');expect(state.queries.length).toBe(before);await p.getByRole('button',{name:'删除未应用',exact:true}).click();await page.getByRole('dialog',{name:'删除筛选方案',exact:true}).getByRole('button',{name:'确认删除',exact:true}).click();await expect.poll(()=>state.presets.length).toBe(1);expect(state.queries.length).toBe(before);await expect(p.getByText('已应用',{exact:true})).toHaveCount(1);
  118 | });
  119 | test('unsaved editor Escape preserves input until explicit discard and footer cancel returns to manager',async({page})=>{
  120 |  const state=await fixture(page);let d=await editor(page,await manager(page));await d.getByLabel('自定义筛选名称',{exact:true}).fill('尚未保存');await page.keyboard.press('Escape');let c=page.getByRole('dialog',{name:'放弃未保存的筛选',exact:true});await expect(c).toBeVisible();await c.getByRole('button',{name:'返回',exact:true}).click();await expect(d.getByLabel('自定义筛选名称',{exact:true})).toHaveValue('尚未保存');await d.getByRole('button',{name:'取消',exact:true}).click();c=page.getByRole('dialog',{name:'放弃未保存的筛选',exact:true});await c.getByRole('button',{name:'放弃更改',exact:true}).click();await expect(page.getByRole('dialog',{name:'管理自定义筛选',exact:true})).toBeVisible();expect(state.writes).toHaveLength(0);
  121 | });
  122 | test('deleted reference and unknown fields fail apply before any search request',async({page})=>{
  123 |  const missing={operator:'and',children:[{field:'identityIds',operator:'eq',value:'00000000-0000-4000-8000-000000000099'}]},state=await fixture(page,[saved(presetA,'引用失效',[],missing)]);const p=await manager(page),before=state.queries.length;await p.getByRole('button',{name:'应用引用失效',exact:true}).click();await expect(p.getByRole('alert')).toContainText('已失效引用');expect(state.queries.length).toBe(before);await expect(p.getByText('已应用',{exact:true})).toHaveCount(0);
  124 | });
  125 | test('narrow typed condition retains a readable field name beside NULL controls',async({page})=>{
  126 |  await fixture(page);await page.getByRole('tab',{name:'操作记录',exact:true}).click();await page.setViewportSize({width:390,height:844});const d=await editor(page,await manager(page));await d.getByRole('button',{name:'或条件',exact:true}).click();await d.getByLabel('条件 1.1 值类型',{exact:true}).selectOption('null');
> 127 |  const size=await d.getByLabel('条件 1.1 字段',{exact:true}).evaluate((el:HTMLSelectElement)=>{const context=document.createElement('canvas').getContext('2d')!;context.font=getComputedStyle(el).font;return {actual:el.clientWidth,required:context.measureText('操作者账号').width+32};});expect(size.actual).toBeGreaterThanOrEqual(size.required);await expect(d.getByRole('button',{name:'确定',exact:true})).toBeInViewport();
      |                                                                                                                                                                                                                                                                                                         ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  128 | });
  129 | 
```