# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: q36-b2.component.spec.ts >> Q36 B2 a trusted press spanning the exiting selection mark still selects current rows
- Location: apps/web/src/q36-b2.component.spec.ts:176:1

# Error details

```
Error: expect(locator).toBeChecked() failed

Locator:  getByLabel('选择成员：q36-admin', { exact: true })
Expected: checked
Received: unchecked
Timeout:  3000ms

Call log:
  - Expect "toBeChecked" getByLabel('选择成员：q36-admin', { exact: true }) with timeout 3000ms
  - waiting for getByLabel('选择成员：q36-admin', { exact: true })
    10 × locator resolved to <button id="_r_b_" tabindex="0" type="button" role="checkbox" aria-checked="false" data-state="unchecked" aria-label="选择成员：q36-admin" class="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 outline-none transition-colors duration-200 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-60 border-muted-foreground/50 bg-background hover:border-muted-foreground"></button>
       - unexpected value "unchecked"

```

```yaml
- checkbox "选择成员：q36-admin"
```

# Test source

```ts
  89  |  await expect.poll(()=>requests.at(-1)?.page).toBe(1);expect(requests.at(-1)?.queryVersion).toBeUndefined();
  90  |  await expect(page.getByLabel('选择成员：q36-admin',{exact:true})).not.toBeChecked();
  91  | });
  92  | 
  93  | test('Q36 B2 late responses cannot overwrite the newest search',async({page})=>{
  94  |  await fixture(page);let release:((r:Route)=>Promise<void>)|undefined;let oldRoute:Route|undefined;
  95  |  await page.route('**/personnel/members/search',async r=>{const input=r.request().postDataJSON();if(input.search==='older'){oldRoute=r;release=async route=>{await route.fulfill({json:envelope(paging([{...member,account:'late-old-response'}],input))}).catch(()=>{});};return;}await r.fulfill({json:envelope(paging([{...member,account:input.search==='newer'?'newest-response':member.account}],input))});});
  96  |  await admin(page);await page.getByLabel('搜索成员',{exact:true}).fill('older');await expect.poll(()=>!!oldRoute).toBe(true);
  97  |  await page.getByLabel('搜索成员',{exact:true}).fill('newer');await expect(page.locator('.member-table')).toContainText('newest-response');
  98  |  if(release&&oldRoute)await release(oldRoute);await page.waitForTimeout(200);await expect(page.locator('.member-table')).not.toContainText('late-old-response');
  99  | });
  100 | 
  101 | test('Q36 B2 unused template card save keeps member page and validates its existing context on return',async({page})=>{
  102 |  await fixture(page);const queries:Record<string,unknown>[]=[];
  103 |  await page.route('**/personnel/members/search',r=>{const input=r.request().postDataJSON();queries.push(input);return r.fulfill({json:envelope(paging([member],input))});});
  104 |  await page.route('**/personnel/templates',r=>r.fulfill({json:envelope({...identity,id:draftId,name:'不影响成员结果的新模板',templateIds:[]})}));
  105 |  await admin(page);await page.getByLabel('跳至页',{exact:true}).fill('4');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('button',{name:'Page 4',exact:true})).toHaveAttribute('aria-current','page');
  106 |  await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');const beforeSave=queries.length;
  107 |  await page.getByRole('tab',{name:'权限模板',exact:true}).click();await page.getByRole('button',{name:'新建权限模板',exact:true}).click();await page.getByLabel('模板名称',{exact:true}).fill('不影响成员结果的新模板');
  108 |  await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByRole('button',{name:'确认保存',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'已保存'})).toBeVisible();
  109 |  await page.getByRole('tab',{name:'成员与部门',exact:true}).click();await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');
  110 |  await expect.poll(()=>queries.length).toBeGreaterThan(beforeSave);await expect(page.getByRole('button',{name:'Page 4',exact:true})).toHaveAttribute('aria-current','page');expect(queries.at(-1)?.queryVersion).toBe('context-4');expect(queries.slice(beforeSave).every(q=>!!q.queryVersion)).toBe(true);
  111 | });
  112 | 
  113 | test('Q36 B2 definition explicitly saves durable draft and restores original version with conflict',async({page})=>{
  114 |  await fixture(page);let saved:Record<string,unknown>|undefined;let current=identity;
  115 |  await page.route('**/personnel/identities/'+identityId,r=>r.fulfill({json:envelope(current)}));
  116 |  await page.route('**/personnel/drafts',r=>{if(r.request().method()==='POST'){const input=r.request().postDataJSON();saved={...input,id:draftId,version:1,createdAt:'2026-10-01T00:00:00Z',updatedAt:'2026-10-01T00:00:00Z'};return r.fulfill({status:201,json:envelope(saved)});}return r.fulfill({json:envelope({items:saved?[saved]:[]})});});
  117 |  await page.route('**/personnel/drafts/'+draftId,r=>r.fulfill({json:envelope(saved)}));
  118 |  await admin(page);await page.getByRole('tab',{name:'身份',exact:true}).click();await page.getByRole('button',{name:'测试身份',exact:true}).click();
  119 |  await page.getByLabel('说明',{exact:true}).fill('尚未提交的输入');expect(saved).toBeUndefined();
  120 |  await page.getByRole('button',{name:'保存草稿',exact:true}).click();await expect.poll(()=>saved?.baseVersion).toBe(1);
  121 |  expect(saved?.payload).toMatchObject({description:'尚未提交的输入'});current={...identity,version:2,description:'其他标签已更新'};
  122 |  await page.reload();await page.getByRole('button',{name:'草稿箱',exact:true}).click();await page.getByRole('button',{name:'恢复草稿',exact:true}).first().click();
  123 |  await expect(page.getByLabel('说明',{exact:true})).toHaveValue('尚未提交的输入');await expect(page.getByRole('alert')).toContainText('原版本 1');await expect(page.getByRole('alert')).toContainText('最新版本 2');
  124 |  await expect(page.getByRole('button',{name:'保存',exact:true})).toBeDisabled();expect(saved?.baseVersion).toBe(1);
  125 |  await page.setViewportSize({width:390,height:844});
  126 |  const resolve=page.getByRole('button',{name:'保留当前输入，使用最新对象版本',exact:true});await resolve.scrollIntoViewIfNeeded();
  127 |  const box=(await resolve.boundingBox())!;
  128 |  expect(box.x).toBeGreaterThanOrEqual(176);expect(box.x+box.width).toBeLessThanOrEqual(390);
  129 | });
  130 | 
  131 | test('Q36 B2 explicit member draft does not save automatically or bypass query guard',async({page})=>{
  132 |  await fixture(page);let saved:Record<string,unknown>|undefined;let write:Record<string,unknown>|undefined;
  133 |  await page.route('**/personnel/drafts',r=>{if(r.request().method()==='POST'){saved={...r.request().postDataJSON(),id:draftId,version:3};return r.fulfill({status:201,json:envelope(saved)});}return r.fulfill({json:envelope({items:[]})});});
  134 |  await page.route('**/personnel/members/'+id+'/identities',r=>{write=r.request().postDataJSON();return r.fulfill({json:envelope(member)});});
  135 |  await admin(page);await page.getByRole('button',{name:'配置身份',exact:true}).click();await page.getByLabel('身份：测试身份',{exact:true}).check();expect(saved).toBeUndefined();
  136 |  await page.getByRole('button',{name:'保存草稿',exact:true}).click();await expect.poll(()=>saved?.kind).toBe('member-identities');
  137 |  await page.getByRole('button',{name:'确认分配',exact:true}).click();await expect.poll(()=>write?.queryVersion).toBe('context-1');expect(write?.draftRef).toEqual({id:draftId,version:3});
  138 | });
  139 | 
  140 | test('Q36 B2 real-page animation closes on navigation and leaves no root blocker',async({page})=>{
  141 |  await fixture(page);await admin(page);await page.getByRole('button',{name:'自定义筛选',exact:true}).click();await expect(page.getByRole('dialog',{name:'管理自定义筛选',exact:true})).toBeVisible();
  142 |  await page.keyboard.press('Escape');await page.getByRole('button',{name:'自定义筛选',exact:true}).click();await page.keyboard.press('Escape');
  143 |  await page.getByRole('tab',{name:'操作记录',exact:true}).click();await page.waitForTimeout(1000);
  144 |  await expect.poll(()=>page.evaluate(()=>document.documentElement.classList.contains('q36-filter-transition-active'))).toBe(false);
  145 |  await expect(page.getByRole('button',{name:'自定义筛选',exact:true}).locator('svg')).toBeVisible();
  146 | });
  147 | 
  148 | test('Q36 B2 applied preset manager close then trigger press honors reopen intent',async({page})=>{
  149 |  await fixture(page);await admin(page);await condition(page);await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();const panel=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await expect(panel).toBeVisible();
  150 |  await page.evaluate(()=>{(document.querySelector('.preset-close') as HTMLButtonElement).click();(document.querySelector('.q36-filter-trigger') as HTMLButtonElement).click();});
  151 |  await expect(page.locator('.q36-filter-content')).toBeVisible();await expect(panel).toBeVisible();await page.waitForTimeout(1000);await expect(panel).toBeVisible();
  152 |  await expect.poll(()=>page.evaluate(()=>document.documentElement.classList.contains('q36-filter-transition-active'))).toBe(false);
  153 | });
  154 | 
  155 | test('Q36 B2 twenty AND conditions keep the save footer inside the narrow viewport',async({page})=>{
  156 |  await fixture(page);await page.setViewportSize({width:1440,height:1000});await admin(page);await page.getByRole('button',{name:'自定义筛选',exact:true}).click();const manager=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await manager.getByRole('button',{name:'新增筛选',exact:true}).click();const panel=page.getByRole('dialog',{name:'新增自定义筛选',exact:true});await panel.getByLabel('自定义筛选名称',{exact:true}).fill('二十条件');
  157 |  await panel.getByRole('button',{name:'或条件',exact:true}).click();
  158 |  for(let i=1;i<=20;i++){if(i>1)await panel.getByRole('button',{name:'组 1 且条件',exact:true}).click();await panel.getByLabel('条件 1.'+i+' 值',{exact:true}).fill('SyntheticLongAccountOutsidePageScope');}
  159 |  await page.setViewportSize({width:390,height:844});const apply=panel.getByRole('button',{name:'确定',exact:true});await expect(apply).toBeEnabled();
  160 |  await expect.poll(async()=>{const box=(await apply.boundingBox())!;return box.y+box.height;}).toBeLessThanOrEqual(844);
  161 |  await expect(apply).toBeInViewport();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  162 | });
  163 | 
  164 | test('Q36 B2 select-current-page cannot resurrect a member hidden by custom filtering',async({page})=>{
  165 |  await fixture(page);const other={...member,id:identityId,account:'other-visible-member'};
  166 |  await page.route('**/personnel/members/search',r=>{const input=r.request().postDataJSON();return r.fulfill({json:envelope({...paging(input.filter?[member]:[member,other],input),total:input.filter?1:2})});});
  167 |  await admin(page);await page.getByLabel('选择成员：other-visible-member',{exact:true}).check();await condition(page);
  168 |  await expect(page.getByLabel('选择成员：other-visible-member',{exact:true})).toHaveCount(0);
  169 |  await expect(page.getByLabel('选择成员：q36-admin',{exact:true})).toBeVisible();
  170 |  await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');
  171 |  await page.getByLabel('选择当前页成员',{exact:true}).check();await expect(page.getByLabel('选择成员：q36-admin',{exact:true})).toBeChecked();
  172 |  await cancelCondition(page);
  173 |  await expect(page.getByLabel('选择成员：other-visible-member',{exact:true})).not.toBeChecked();await expect(page.getByLabel('选择当前页成员',{exact:true})).not.toBeChecked();
  174 | });
  175 | 
  176 | test('Q36 B2 a trusted press spanning the exiting selection mark still selects current rows',async({page})=>{
  177 |  await page.addInitScript(()=>{const events:{type:string;trusted:boolean;target:string}[]=[];Object.defineProperty(window,'__q36SelectionPress',{value:events});for(const type of ['pointerdown','pointerup','click'])document.addEventListener(type,event=>{const target=event.target as Element;if(target.closest?.('[aria-label="选择当前页成员"]')){if(type==='pointerdown')events.length=0;events.push({type,trusted:event.isTrusted,target:target.tagName});}},true);});
  178 |  await fixture(page);const other={...member,id:identityId,account:'other-visible-member'};
  179 |  await page.route('**/personnel/members/search',r=>{const input=r.request().postDataJSON();return r.fulfill({json:envelope({...paging(input.filter?[member]:[member,other],input),total:input.filter?1:2})});});
  180 |  await admin(page);await page.getByLabel('选择成员：other-visible-member',{exact:true}).check();
  181 |  await condition(page);const panel=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await expect(panel).toBeHidden();
  182 |  const all=page.getByLabel('选择当前页成员',{exact:true});await all.check();await expect(page.getByLabel('选择成员：q36-admin',{exact:true})).toBeChecked();
  183 |  const box=(await all.boundingBox())!;await all.focus();await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.keyboard.press('Space');
  184 |  // Drive a real press during the existing exit, then release after its actual
  185 |  // DOM removal. No sleep, timeout change or click retry determines the result.
  186 |  await page.waitForFunction(()=>{const table=document.querySelector('.member-table table'),all=document.querySelector('[aria-label="选择当前页成员"]');return table?.getAttribute('aria-busy')==='false'&&all?.getAttribute('aria-checked')==='false'&&!!document.querySelector('[aria-label="选择成员：q36-admin"]')&&!document.querySelector('[aria-label="选择成员：other-visible-member"]')&&!!all?.querySelector('svg');});
  187 |  await page.mouse.down();await expect(all.locator('svg')).toHaveCount(0);await page.mouse.up();
  188 |  await test.info().attach('trusted-selection-press.json',{body:JSON.stringify(await page.evaluate(()=>({events:(window as unknown as {__q36SelectionPress:unknown}).__q36SelectionPress,active:document.activeElement?.getAttribute('aria-label'),button:document.querySelector('[aria-label="选择当前页成员"]')?.outerHTML,transitions:document.documentElement.className}))),contentType:'application/json'});
> 189 |  await expect(page.getByLabel('选择成员：q36-admin',{exact:true})).toBeChecked();await expect(all).toBeChecked();
      |                                                               ^ Error: expect(locator).toBeChecked() failed
  190 |  const events=await page.evaluate(()=>(window as unknown as {__q36SelectionPress:{type:string;trusted:boolean;target:string}[]}).__q36SelectionPress);
  191 |  expect(events.filter(event=>event.type==='click'&&event.trusted)).toHaveLength(1);
  192 |  await cancelCondition(page);
  193 |  await expect(page.getByLabel('选择成员：other-visible-member',{exact:true})).not.toBeChecked();await expect(all).not.toBeChecked();
  194 | });
  195 | 
  196 | test('Q36 B2 trusted select-all clicks while loading or empty cannot persist into restored or next-page rows',async({page})=>{
  197 |  await fixture(page);const other={...member,id:identityId,account:'other-visible-member'},next={...member,id:draftId,account:'next-page-member'};
  198 |  let release!:()=>void;const gate=new Promise<void>(resolve=>{release=resolve;});
  199 |  await page.route('**/personnel/members/search',async r=>{const input=r.request().postDataJSON();if(input.filter)await gate;return r.fulfill({json:envelope({...paging(input.filter?[]:input.page===2?[next]:[member,other],input),total:input.filter?0:40})});});
  200 |  await admin(page);await page.getByLabel('选择成员：other-visible-member',{exact:true}).check();await condition(page,false);
  201 |  const all=page.getByLabel('选择当前页成员',{exact:true}),table=page.locator('.member-table table');
  202 |  await expect(table).toHaveAttribute('aria-busy','true');await expect(all).toBeDisabled();
  203 |  async function trustedClick(){const box=(await all.boundingBox())!;await page.mouse.click(box.x+box.width/2,box.y+box.height/2);}
  204 |  await trustedClick();await expect(page.getByLabel('选择成员：other-visible-member',{exact:true})).toBeChecked();
  205 |  release();await expect(table).toHaveAttribute('aria-busy','false');await expect(table.locator('tbody tr[data-row-id]')).toHaveCount(0);await expect(all).toBeDisabled();await trustedClick();await expect(all).not.toBeChecked();
  206 |  const manager=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await manager.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(manager).toBeHidden();
  207 |  await cancelCondition(page);
  208 |  await expect(table).toHaveAttribute('aria-busy','false');await expect(page.getByLabel('选择成员：q36-admin',{exact:true})).not.toBeChecked();await expect(page.getByLabel('选择成员：other-visible-member',{exact:true})).not.toBeChecked();await expect(all).not.toBeChecked();
  209 |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');
  210 |  await expect(page.getByLabel('选择成员：next-page-member',{exact:true})).toBeVisible();await expect(table).toHaveAttribute('aria-busy','false');await expect(page.getByLabel('选择成员：next-page-member',{exact:true})).not.toBeChecked();await expect(all).not.toBeChecked();
  211 | });
  212 | 
```