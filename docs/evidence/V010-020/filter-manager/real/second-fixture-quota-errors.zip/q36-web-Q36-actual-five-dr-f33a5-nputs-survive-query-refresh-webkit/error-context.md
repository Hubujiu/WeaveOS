# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: q36-web.spec.ts >> Q36 actual five draft kinds persist after fresh login; member/department inputs survive query refresh
- Location: tests/acceptance/q36-web.spec.ts:107:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('status').filter({ hasText: '草稿已保存' })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('status').filter({ hasText: '草稿已保存' }) with timeout 10000ms
  - waiting for getByRole('status').filter({ hasText: '草稿已保存' })

```

```yaml
- banner:
  - strong: 管理后台
  - button "草稿箱"
  - button "保存" [disabled]
  - button "退出"
- complementary:
  - text: 管理功能
  - button "人员管理"
  - paragraph: 成员 · 部门 · 身份 · 权限
- main:
  - heading "人员管理" [level=1]
  - paragraph: 统一管理成员、部门、身份与应用访问。
  - tablist "人员管理视图":
    - tab "成员与部门" [selected]
    - tab "身份"
    - tab "权限模板"
    - tab "操作记录"
  - button "刷新查询"
  - alert:
    - text: 已保存 20 份草稿，请先明确删除不需要的草稿
    - button "重新加载"
  - tabpanel "成员与部门":
    - heading "成员与部门" [level=2]
    - paragraph: 管理成员归属与身份，部门调整不改变访问权限
    - button "新建部门"
    - button "邀请成员"
    - heading "部门 7" [level=3]
    - button "全部成员 148"
    - button "企业 0"
    - button "Q36 测试部门 1790919984541 0"
    - button "Q36 测试部门 1790920184776 0"
    - button "Q36 测试部门 1790920392046 0"
    - button "Q36 测试部门 1790920955401 0"
    - button "Q36 测试部门 1790921046322 0"
    - button "Q36 测试部门 1790921115590 0"
    - button "重命名部门" [disabled]
    - button "删除部门" [disabled]
    - paragraph: 部门只用于分组。 移动成员不会自动改变 身份或应用访问权限。
    - textbox "搜索成员"
    - button "自定义筛选":
      - img
      - text: 自定义筛选
    - text: 148 位成员
    - combobox "筛选身份": 全部身份
    - table "成员":
      - rowgroup:
        - row "选择当前页成员 拖动以调整 account 列顺序 成员 Resize account column 拖动以调整 departments 列顺序 部门 Resize departments column 拖动以调整 identities 列顺序 身份 Resize identities column 拖动以调整 personnelManage 列顺序 人员管理 Resize personnelManage column 拖动以调整 actions 列顺序 操作 Resize actions column":
          - columnheader "选择当前页成员":
            - checkbox "选择当前页成员"
          - columnheader "拖动以调整 account 列顺序 成员 Resize account column":
            - button "拖动以调整 account 列顺序":
              - img
            - text: 成员
            - button "Resize account column"
          - columnheader "拖动以调整 departments 列顺序 部门 Resize departments column":
            - button "拖动以调整 departments 列顺序":
              - img
            - text: 部门
            - button "Resize departments column"
          - columnheader "拖动以调整 identities 列顺序 身份 Resize identities column":
            - button "拖动以调整 identities 列顺序":
              - img
            - text: 身份
            - button "Resize identities column"
          - columnheader "拖动以调整 personnelManage 列顺序 人员管理 Resize personnelManage column":
            - button "拖动以调整 personnelManage 列顺序":
              - img
            - text: 人员管理
            - button "Resize personnelManage column"
          - columnheader "拖动以调整 actions 列顺序 操作 Resize actions column":
            - button "拖动以调整 actions 列顺序":
              - img
            - text: 操作
            - button "Resize actions column"
      - rowgroup:
        - row "1 选择成员：acceptance-admin-gJkyc-rSERgk2KZ3 acceptance-admin-gJkyc-rSERgk2KZ3 正常 未分组 Bootstrap Admin 默认拥有 配置身份 调整分组":
          - cell "1 选择成员：acceptance-admin-gJkyc-rSERgk2KZ3":
            - text: "1"
            - checkbox "选择成员：acceptance-admin-gJkyc-rSERgk2KZ3"
          - cell "acceptance-admin-gJkyc-rSERgk2KZ3 正常":
            - strong: acceptance-admin-gJkyc-rSERgk2KZ3
            - text: 正常
          - cell "未分组"
          - cell "Bootstrap Admin"
          - cell "默认拥有"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "2 选择成员：acceptance-user-Q8WoJHxdvyfbSj6K acceptance-user-Q8WoJHxdvyfbSj6K 正常 未分组 Q36 测试身份 1790921115590 未开启 配置身份 调整分组":
          - cell "2 选择成员：acceptance-user-Q8WoJHxdvyfbSj6K":
            - text: "2"
            - checkbox "选择成员：acceptance-user-Q8WoJHxdvyfbSj6K"
          - cell "acceptance-user-Q8WoJHxdvyfbSj6K 正常":
            - strong: acceptance-user-Q8WoJHxdvyfbSj6K
            - text: 正常
          - cell "未分组"
          - cell "Q36 测试身份 1790921115590"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "3 选择成员：acceptance-disabled-LCw4VTTuIQBfHE5k acceptance-disabled-LCw4VTTuIQBfHE5k 已停用 未分组 未分配 未开启 配置身份 调整分组":
          - cell "3 选择成员：acceptance-disabled-LCw4VTTuIQBfHE5k":
            - text: "3"
            - checkbox "选择成员：acceptance-disabled-LCw4VTTuIQBfHE5k"
          - cell "acceptance-disabled-LCw4VTTuIQBfHE5k 已停用":
            - strong: acceptance-disabled-LCw4VTTuIQBfHE5k
            - text: 已停用
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "4 选择成员：acceptance-reset-ly06yas9ILZmaeME acceptance-reset-ly06yas9ILZmaeME 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "4 选择成员：acceptance-reset-ly06yas9ILZmaeME":
            - text: "4"
            - checkbox "选择成员：acceptance-reset-ly06yas9ILZmaeME"
          - cell "acceptance-reset-ly06yas9ILZmaeME 正常":
            - strong: acceptance-reset-ly06yas9ILZmaeME
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "5 选择成员：q36-1790919984541-00 q36-1790919984541-00 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "5 选择成员：q36-1790919984541-00":
            - text: "5"
            - checkbox "选择成员：q36-1790919984541-00"
          - cell "q36-1790919984541-00 正常":
            - strong: q36-1790919984541-00
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "6 选择成员：q36-1790919984541-01 q36-1790919984541-01 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "6 选择成员：q36-1790919984541-01":
            - text: "6"
            - checkbox "选择成员：q36-1790919984541-01"
          - cell "q36-1790919984541-01 正常":
            - strong: q36-1790919984541-01
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "7 选择成员：q36-1790919984541-02 q36-1790919984541-02 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "7 选择成员：q36-1790919984541-02":
            - text: "7"
            - checkbox "选择成员：q36-1790919984541-02"
          - cell "q36-1790919984541-02 正常":
            - strong: q36-1790919984541-02
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "8 选择成员：q36-1790919984541-03 q36-1790919984541-03 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "8 选择成员：q36-1790919984541-03":
            - text: "8"
            - checkbox "选择成员：q36-1790919984541-03"
          - cell "q36-1790919984541-03 正常":
            - strong: q36-1790919984541-03
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "9 选择成员：q36-1790919984541-04 q36-1790919984541-04 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "9 选择成员：q36-1790919984541-04":
            - text: "9"
            - checkbox "选择成员：q36-1790919984541-04"
          - cell "q36-1790919984541-04 正常":
            - strong: q36-1790919984541-04
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "10 选择成员：q36-1790919984541-05 q36-1790919984541-05 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "10 选择成员：q36-1790919984541-05":
            - text: "10"
            - checkbox "选择成员：q36-1790919984541-05"
          - cell "q36-1790919984541-05 正常":
            - strong: q36-1790919984541-05
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "11 选择成员：q36-1790919984541-06 q36-1790919984541-06 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "11 选择成员：q36-1790919984541-06":
            - text: "11"
            - checkbox "选择成员：q36-1790919984541-06"
          - cell "q36-1790919984541-06 正常":
            - strong: q36-1790919984541-06
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "12 选择成员：q36-1790919984541-07 q36-1790919984541-07 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "12 选择成员：q36-1790919984541-07":
            - text: "12"
            - checkbox "选择成员：q36-1790919984541-07"
          - cell "q36-1790919984541-07 正常":
            - strong: q36-1790919984541-07
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "13 选择成员：q36-1790919984541-08 q36-1790919984541-08 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "13 选择成员：q36-1790919984541-08":
            - text: "13"
            - checkbox "选择成员：q36-1790919984541-08"
          - cell "q36-1790919984541-08 正常":
            - strong: q36-1790919984541-08
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "14 选择成员：q36-1790919984541-09 q36-1790919984541-09 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "14 选择成员：q36-1790919984541-09":
            - text: "14"
            - checkbox "选择成员：q36-1790919984541-09"
          - cell "q36-1790919984541-09 正常":
            - strong: q36-1790919984541-09
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "15 选择成员：q36-1790919984541-10 q36-1790919984541-10 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "15 选择成员：q36-1790919984541-10":
            - text: "15"
            - checkbox "选择成员：q36-1790919984541-10"
          - cell "q36-1790919984541-10 正常":
            - strong: q36-1790919984541-10
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "16 选择成员：q36-1790919984541-11 q36-1790919984541-11 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "16 选择成员：q36-1790919984541-11":
            - text: "16"
            - checkbox "选择成员：q36-1790919984541-11"
          - cell "q36-1790919984541-11 正常":
            - strong: q36-1790919984541-11
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "17 选择成员：q36-1790919984541-12 q36-1790919984541-12 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "17 选择成员：q36-1790919984541-12":
            - text: "17"
            - checkbox "选择成员：q36-1790919984541-12"
          - cell "q36-1790919984541-12 正常":
            - strong: q36-1790919984541-12
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "18 选择成员：q36-1790919984541-13 q36-1790919984541-13 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "18 选择成员：q36-1790919984541-13":
            - text: "18"
            - checkbox "选择成员：q36-1790919984541-13"
          - cell "q36-1790919984541-13 正常":
            - strong: q36-1790919984541-13
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "19 选择成员：q36-1790919984541-14 q36-1790919984541-14 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "19 选择成员：q36-1790919984541-14":
            - text: "19"
            - checkbox "选择成员：q36-1790919984541-14"
          - cell "q36-1790919984541-14 正常":
            - strong: q36-1790919984541-14
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
        - row "20 选择成员：q36-1790919984541-15 q36-1790919984541-15 正常 未分组 未分配 未开启 配置身份 调整分组":
          - cell "20 选择成员：q36-1790919984541-15":
            - text: "20"
            - checkbox "选择成员：q36-1790919984541-15"
          - cell "q36-1790919984541-15 正常":
            - strong: q36-1790919984541-15
            - text: 正常
          - cell "未分组"
          - cell "未分配"
          - cell "未开启"
          - cell "配置身份 调整分组":
            - button "配置身份"
            - button "调整分组"
    - text: 每页条数
    - combobox "每页条数": "20"
    - text: 1 - 20 / 共 148 项
    - navigation "Pagination":
      - button "上一页" [disabled]:
        - img
      - button "Page 1": "1"
      - button "Page 2": "2"
      - button "Page 3": "3"
      - button "Page 4": "4"
      - button "Page 5": "5"
      - button "Next pages": ...
      - button "Page 8": "8"
      - button "下一页":
        - img
      - text: 跳至页
      - spinbutton "跳至页": "1"
      - button "跳转到指定页":
        - img
- dialog "配置成员身份":
  - heading "配置成员身份" [level=2]
  - button "关闭": ×
  - paragraph: acceptance-admin-gJkyc-rSERgk2KZ3
  - checkbox "身份：隔离授权-chromium-1790919954810-30"
  - text: 隔离授权-chromium-1790919954810-30
  - checkbox "身份：Q36 测试身份 1790919984541"
  - text: Q36 测试身份 1790919984541
  - checkbox "身份：Q36 隔离验证授权 1790919984541"
  - text: Q36 隔离验证授权 1790919984541
  - checkbox "身份：隔离授权-firefox-1790920034075-30"
  - text: 隔离授权-firefox-1790920034075-30
  - checkbox "身份：Q36 测试身份 1790920184776"
  - text: Q36 测试身份 1790920184776
  - checkbox "身份：Q36 隔离验证授权 1790920184776"
  - text: Q36 隔离验证授权 1790920184776
  - checkbox "身份：隔离授权-webkit-1790920245707-30"
  - text: 隔离授权-webkit-1790920245707-30
  - checkbox "身份：Q36 测试身份 1790920392046"
  - text: Q36 测试身份 1790920392046
  - checkbox "身份：Q36 隔离验证授权 1790920392046"
  - text: Q36 隔离验证授权 1790920392046
  - checkbox "身份：隔离授权-chromium-1790920918227-30"
  - text: 隔离授权-chromium-1790920918227-30
  - checkbox "身份：隐藏依赖-chromium-1790920918227-37"
  - text: 隐藏依赖-chromium-1790920918227-37
  - checkbox "身份：Q36 测试身份 1790920955401"
  - text: Q36 测试身份 1790920955401
  - checkbox "身份：Q36 隔离验证授权 1790920955401"
  - text: Q36 隔离验证授权 1790920955401
  - checkbox "身份：隔离授权-firefox-1790921002181-30"
  - text: 隔离授权-firefox-1790921002181-30
  - checkbox "身份：隐藏依赖-firefox-1790921002181-37"
  - text: 隐藏依赖-firefox-1790921002181-37
  - checkbox "身份：Q36 测试身份 1790921046322"
  - text: Q36 测试身份 1790921046322
  - checkbox "身份：隔离授权-webkit-1790921081124-30"
  - text: 隔离授权-webkit-1790921081124-30
  - checkbox "身份：隐藏依赖-webkit-1790921081124-37"
  - text: 隐藏依赖-webkit-1790921081124-37
  - checkbox "身份：Q36 测试身份 1790921115590" [checked]
  - text: Q36 测试身份 1790921115590
  - button "确认分配"
  - button "刷新查询"
  - button "保存草稿"
  - alert: 已保存 20 份草稿，请先明确删除不需要的草稿
```

# Test source

```ts
  1   | import {test,expect,type Page,type BrowserContext,type APIResponse} from '@playwright/test';
  2   | import {readFileSync,mkdirSync} from 'node:fs';
  3   | import {rename} from 'node:fs/promises';
  4   | import {resolve} from 'node:path';
  5   | import type {Member,Definition,Department} from '../../apps/web/src/workspace-types';
  6   | import type {MembersQueryPage,PersonnelDraft,PersonnelDraftSummary} from '../../apps/web/src/query-contracts';
  7   | 
  8   | // Approved Q36 PLAN §§1–6. All requests reach the isolated BFF/PG/Redis;
  9   | // there are no business API mocks. No credential-bearing traces or videos.
  10  | test.use({trace:'off',screenshot:'off',video:'off'});
  11  | test.describe.configure({mode:'serial'});
  12  | const base=process.env.WEAVEOS_WEB_URL||'https://localhost:19444';
  13  | if(!['localhost','127.0.0.1'].includes(new URL(base).hostname))throw Error('Q36 requires an isolated loopback instance');
  14  | const privateFixtures=process.env.WEAVEOS_ACCEPTANCE_FIXTURES||resolve('.work/q36-b2-runtime/fixtures.json');
  15  | const evidence=resolve('docs/evidence/V010-020/filter-manager/real/q36-regression');mkdirSync(evidence,{recursive:true});
  16  | const fixture=JSON.parse(readFileSync(privateFixtures,'utf8')) as {admin:{account:string;password:string};user:{account:string;password:string};userId:string};
  17  | let identity:Definition,template:Definition,department:Department,rootDepartment:Department;
  18  | const stamp=Date.now();let presetCounter=0;const createdPresets:string[]=[];
  19  | async function login(context:BrowserContext,credentials=fixture.admin){const response=await context.request.post(base+'/api/v1/sessions',{headers:{Origin:base},data:credentials});expect(response.status(),'isolated prerequisite login').toBe(201);}
  20  | async function response(page:Page,path:string,method='GET',data?:object):Promise<APIResponse>{
  21  |  const cookie=(await page.context().cookies(base)).find(c=>c.name==='__Host-csrf');
  22  |  return page.request.fetch(base+'/api/v1/'+path,{method,headers:{Origin:base,...(cookie?{'X-CSRF-Token':cookie.value}:{})},...(data?{data}:{})});
  23  | }
  24  | async function api<T>(page:Page,path:string,method='GET',data?:object):Promise<T>{const res=await response(page,path,method,data);expect(res.ok(),'isolated '+method+' '+path.split('?')[0]+' status '+res.status()).toBe(true);if(res.status()===204)return undefined as T;const body=await res.json();expect(body.code).toBe('OK');return body.data as T;}
  25  | async function enter(page:Page){await login(page.context());page.on('dialog',dialog=>void dialog.accept());await page.goto('/app/admin');await expect(page.getByRole('tab',{name:'成员与部门',exact:true})).toBeVisible();await expect(page.locator('.member-table tbody tr[data-row-id]').first()).toBeVisible();}
  26  | async function shot(page:Page,name:string,filterOpen=false){
  27  |  await page.evaluate(()=>document.fonts.ready);
  28  |  // Base UI intentionally remains open while the native close animation runs.
  29  |  // Assert the requested screenshot state instead of treating its aria-expanded
  30  |  // flag as the user's intent during that interval.
  31  |  if(filterOpen){await expect(page.locator('.preset-popup')).toHaveAttribute('aria-hidden','false');await expect(page.locator('.q36-filter-content')).toBeVisible();}
  32  |  else await expect(page.getByRole('dialog',{name:'管理自定义筛选',exact:true})).toBeHidden();
  33  |  await page.evaluate(()=>new Promise<void>(done=>requestAnimationFrame(()=>requestAnimationFrame(()=>done()))));
  34  |  await page.waitForFunction(()=>!document.documentElement.classList.contains('q36-filter-transition-active'));
  35  |  await page.evaluate(()=>Promise.allSettled(document.getAnimations().map(animation=>animation.finished)));
  36  |  await page.screenshot({path:resolve(evidence,test.info().project.name+'-'+name+'.png'),fullPage:true});
  37  | }
  38  | async function newFilterEditor(page:Page){
  39  |  await page.getByRole('button',{name:'自定义筛选',exact:true}).click();const manager=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await manager.getByRole('button',{name:'新增筛选',exact:true}).click();const editor=page.getByRole('dialog',{name:'新增自定义筛选',exact:true});const name='Q36-'+test.info().project.name+'-'+stamp+'-'+(++presetCounter);await editor.getByLabel('自定义筛选名称',{exact:true}).fill(name);return {manager,editor,name};
  40  | }
  41  | async function saveApplyFilter(page:Page,entry:Awaited<ReturnType<typeof newFilterEditor>>){
  42  |  const saved=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname.endsWith('/table-presets'));await entry.editor.getByRole('button',{name:'确定',exact:true}).click();const body=await (await saved).json();createdPresets.push(body.data.id);await entry.manager.getByRole('button',{name:'应用'+entry.name,exact:true}).click();await expect(entry.manager.getByRole('button',{name:'关闭筛选管理',exact:true})).toBeEnabled();await entry.manager.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(entry.manager).toBeHidden();
  43  | }
  44  | async function cancelFilter(page:Page){
  45  |  await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();const manager=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await manager.getByRole('button',{name:'取消应用',exact:true}).click();await page.getByRole('dialog',{name:'取消当前筛选',exact:true}).getByRole('button',{name:'确认取消',exact:true}).click();await expect(manager.getByRole('button',{name:'关闭筛选管理',exact:true})).toBeEnabled();await manager.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(manager).toBeHidden();
  46  | }
  47  | test.afterEach(async({page})=>{for(const id of createdPresets.splice(0)){const stored=await api<{version:number}>(page,'personnel/table-presets/'+id);await api(page,'personnel/table-presets/'+id+'?version='+stored.version,'DELETE');}});
  48  | 
  49  | async function refresh(page:Page){await page.getByRole('button',{name:'刷新查询',exact:true}).first().click();await expect(page.locator('.member-table tbody tr[data-row-id]').first()).toBeVisible();}
> 50  | async function saved(page:Page){await page.getByRole('button',{name:'保存草稿',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'草稿已保存'})).toBeVisible();}
      |                                                                                                                                                                  ^ Error: expect(locator).toBeVisible() failed
  51  | async function closeSavedForm(page:Page){await page.getByRole('dialog').getByRole('button',{name:'关闭',exact:true}).click();const dirty=page.getByRole('dialog',{name:'有未保存的修改',exact:true});if(await dirty.isVisible())await dirty.getByRole('button',{name:'放弃修改',exact:true}).click();}
  52  | async function restoreKind(page:Page,kind:string){await page.getByRole('button',{name:'草稿箱',exact:true}).click();const row=page.getByRole('dialog',{name:'草稿箱',exact:true}).locator('.personnel-draft-item').filter({has:page.getByText(kind,{exact:true})});await row.getByRole('button',{name:'恢复草稿',exact:true}).first().click();}
  53  | 
  54  | test.beforeAll(async({browser})=>{
  55  |  const context=await browser.newContext({ignoreHTTPSErrors:true});await login(context);const page=await context.newPage();
  56  |  const query=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});
  57  |  rootDepartment=(await api<{items:Department[]}>(page,'personnel/departments')).items.find(d=>d.isRoot)!;
  58  |  identity=await api<Definition>(page,'personnel/identities','POST',{name:'Q36 测试身份 '+stamp,description:'原说明',templateIds:[],permissionCodes:[]});
  59  |  template=await api<Definition>(page,'personnel/templates','POST',{name:'Q36 测试模板 '+stamp,description:'原模板说明',permissionCodes:[]});
  60  |  department=await api<Department>(page,'personnel/departments','POST',{name:'Q36 测试部门 '+stamp,parentId:rootDepartment.id,queryVersion:query.queryVersion});
  61  |  // Populate two real pages with synthetic registrations via supported APIs.
  62  |  for(let i=0;i<24;i++){
  63  |   const invite=await api<{invitationCode:string}>(page,'invitations','POST',{});
  64  |   const res=await page.request.post(base+'/api/v1/registrations',{headers:{Origin:base},data:{account:'q36-'+stamp+'-'+String(i).padStart(2,'0'),password:'Synthetic@Test123',invitationCode:invite.invitationCode}});
  65  |   expect(res.status(),'isolated synthetic registration').toBe(201);
  66  |  }
  67  |  await context.close();
  68  | });
  69  | 
  70  | test('Q36 actual members: complete filtering, arbitrary pages, selection, column preservation and screenshots',async({page})=>{
  71  |  await enter(page);await page.setViewportSize({width:1440,height:1000});await shot(page,'members-default-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'members-default-narrow');await page.setViewportSize({width:1440,height:1000});
  72  |  await expect(page.locator('.member-table th[aria-sort]')).toHaveCount(0);
  73  |  const selected=page.getByLabel('选择成员：'+fixture.admin.account,{exact:true});await selected.check();
  74  |  const resize=page.getByRole('button',{name:'Resize account column',exact:true});const box=(await resize.boundingBox())!;await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2+50,box.y+box.height/2,{steps:8});await page.mouse.up();
  75  |  const before=(await page.locator('.member-table th').nth(1).boundingBox())!.width;
  76  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('button',{name:'Page 2',exact:true})).toHaveAttribute('aria-current','page');
  77  |  const entry=await newFilterEditor(page),panel=entry.editor;
  78  |  await panel.getByRole('button',{name:'或条件',exact:true}).click();await panel.getByLabel('条件 1.1 值',{exact:true}).fill(fixture.admin.account);await shot(page,'members-filter-expanded-desktop',true);
  79  |  await saveApplyFilter(page,entry);await expect(page.locator('.member-table tbody tr[data-row-id]')).toHaveCount(1);await shot(page,'members-filter-applied-desktop');
  80  |  await refresh(page);await expect(selected).not.toBeChecked();expect((await page.locator('.member-table th').nth(1).boundingBox())!.width).toBeCloseTo(before,0);await expect(page.getByRole('button',{name:'自定义筛选，已应用',exact:true})).toBeVisible();
  81  |  await page.setViewportSize({width:390,height:844});await shot(page,'members-filter-applied-narrow');await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();await shot(page,'members-filter-expanded-narrow',true);await page.keyboard.press('Escape');
  82  |  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  83  | });
  84  | 
  85  | test('Q36 actual events: backend safe display, absolute range, full-result time ordering and screenshots',async({page})=>{
  86  |  await enter(page);await page.setViewportSize({width:1440,height:1000});await page.getByRole('tab',{name:'操作记录',exact:true}).click();await expect(page.locator('.activity-table tbody tr[data-row-id]').first()).toBeVisible();await shot(page,'events-default-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'events-default-narrow');await page.setViewportSize({width:1440,height:1000});
  87  |  await page.getByRole('button',{name:'排序 occurredAt',exact:true}).click();await page.getByRole('menuitem',{name:'升序',exact:true}).click();await expect(page.locator('.activity-table th[aria-sort]')).toHaveAttribute('aria-sort','ascending');
  88  |  const entry=await newFilterEditor(page),panel=entry.editor;await panel.getByRole('button',{name:'或条件',exact:true}).click();await panel.getByLabel('条件 1.1 值',{exact:true}).fill(fixture.admin.account);await shot(page,'events-filter-expanded-desktop',true);await saveApplyFilter(page,entry);await shot(page,'events-filter-applied-desktop');
  89  |  const result=await api<{items:{occurredAt:string;display:{object:string;detail:string}}[];range:{from:string;to:string}}>(page,'personnel/events/search','POST',{page:1,pageSize:100,sortBy:'occurredAt',sortDirection:'asc',filter:{operator:'and',children:[{field:'actorAccount',operator:'eq',value:fixture.admin.account}]}});
  90  |  expect(result.items.length).toBeGreaterThan(0);expect(result.items.every((event,i,all)=>i===0||Date.parse(all[i-1].occurredAt)<=Date.parse(event.occurredAt))).toBe(true);expect(result.items.every(event=>typeof event.display.detail==='string'&&typeof event.display.object==='string')).toBe(true);expect(Date.parse(result.range.to)).toBeGreaterThan(Date.parse(result.range.from));
  91  |  await page.setViewportSize({width:390,height:844});await shot(page,'events-filter-applied-narrow');await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();await shot(page,'events-filter-expanded-narrow',true);await page.keyboard.press('Escape');expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  92  | });
  93  | 
  94  | test('Q36 actual precision: unrelated option change proceeds; related member change explicitly refreshes',async({page})=>{
  95  |  await enter(page);let currentVersion='';page.on('response',async res=>{if(res.url().endsWith('/personnel/members/search')&&res.ok()){try{currentVersion=(await res.json()).data.queryVersion;}catch{/* An obsolete response aborted by refresh has no readable body. */}}});await refresh(page);await expect.poll(()=>currentVersion.length).toBeGreaterThan(0);
  96  |  await api(page,'personnel/templates','POST',{name:'Q36 无关模板 '+stamp,description:'不影响当前成员结果',permissionCodes:[]});
  97  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('button',{name:'Page 2',exact:true})).toHaveAttribute('aria-current','page');await expect(page.getByText('查询结果已变化，请刷新查询后继续',{exact:true})).toHaveCount(0);
  98  |  const target=await api<Member>(page,'personnel/members/'+fixture.userId);await api(page,'personnel/members/'+target.id+'/identities','PUT',{version:target.version,identityIds:[identity.id],queryVersion:currentVersion});
  99  |  await page.getByLabel('跳至页',{exact:true}).fill('1');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('alert')).toContainText('查询结果已变化');await shot(page,'members-refresh-required-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'members-refresh-required-narrow');await refresh(page);await expect(page.getByRole('button',{name:'Page 1',exact:true})).toHaveAttribute('aria-current','page');
  100 | });
  101 | 
  102 | test('Q36 actual context LRU expiry is distinct from changed results',async({page})=>{
  103 |  await enter(page);for(let i=0;i<21;i++)await api(page,'personnel/members/search','POST',{page:1,pageSize:20,search:'unmatched-context-'+i});
  104 |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('alert')).toContainText('查询上下文已过期');await shot(page,'members-context-expired');await refresh(page);
  105 | });
  106 | 
  107 | test('Q36 actual five draft kinds persist after fresh login; member/department inputs survive query refresh',async({page,browser})=>{
  108 |  await enter(page);await page.getByRole('button',{name:'配置身份',exact:true}).first().click();await page.getByLabel('身份：'+identity.name,{exact:true}).check();await saved(page);await shot(page,'draft-member-identities-saved');await closeSavedForm(page);
  109 |  await page.getByRole('button',{name:'调整分组',exact:true}).first().click();await saved(page);await shot(page,'draft-member-groups-saved');await closeSavedForm(page);
  110 |  await page.getByRole('button',{name:'新建部门',exact:true}).click();await page.getByLabel('部门名称',{exact:true}).fill('Q36 未提交部门');await saved(page);await shot(page,'draft-department-saved');await closeSavedForm(page);
  111 |  await page.getByRole('tab',{name:'身份',exact:true}).click();await page.getByRole('button',{name:identity.name,exact:true}).click();await page.getByLabel('说明',{exact:true}).fill('Q36 已保存身份输入');await saved(page);await shot(page,'draft-identity-saved');await page.getByRole('tab',{name:'权限模板',exact:true}).click();await page.getByRole('dialog',{name:'有未保存的修改',exact:true}).getByRole('button',{name:'放弃修改',exact:true}).click();
  112 |  await page.getByRole('button',{name:template.name,exact:true}).click();await page.getByLabel('说明',{exact:true}).fill('Q36 已保存模板输入');await saved(page);await shot(page,'draft-template-saved');
  113 |  const stored=await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts');expect(new Set(stored.items.map(d=>d.kind))).toEqual(new Set(['member-identities','member-groups','department','identity','template']));
  114 |  const context=await browser.newContext({ignoreHTTPSErrors:true});const other=await context.newPage();await enter(other);await restoreKind(other,'部门');await expect(other.getByLabel('部门名称',{exact:true})).toHaveValue('Q36 未提交部门');await shot(other,'draft-department-restored-desktop');await other.setViewportSize({width:390,height:844});await shot(other,'draft-department-restored-narrow');
  115 |  await other.getByRole('dialog').getByRole('button',{name:'刷新查询',exact:true}).click();await expect(other.getByLabel('部门名称',{exact:true})).toHaveValue('Q36 未提交部门');await context.close();
  116 | });
  117 | 
  118 | test('Q36 actual restoration compares latest target, preserves original base, and requires explicit resolution',async({page})=>{
  119 |  await enter(page);identity=await api<Definition>(page,'personnel/identities/'+identity.id,'PUT',{name:identity.name,description:'另一标签已提交最新说明',templateIds:[],permissionCodes:[],version:identity.version});
  120 |  await restoreKind(page,'身份');await expect(page.getByLabel('说明',{exact:true})).toHaveValue('Q36 已保存身份输入');await expect(page.getByRole('alert')).toContainText('原版本 1');await expect(page.getByRole('alert')).toContainText('最新版本 2');await expect(page.getByRole('button',{name:'保存',exact:true})).toBeDisabled();await shot(page,'draft-target-conflict-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'draft-target-conflict-narrow');
  121 |  const list=await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts');const item=list.items.find(d=>d.kind==='identity'&&d.targetId===identity.id)!;const stored=await api<PersonnelDraft>(page,'personnel/drafts/'+item.id);expect(stored.baseVersion).toBe(1);
  122 |  await page.getByRole('button',{name:'保留当前输入，使用最新对象版本',exact:true}).click();await expect(page.getByLabel('说明',{exact:true})).toHaveValue('Q36 已保存身份输入');await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByRole('button',{name:'确认保存',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'已保存'})).toBeVisible();
  123 |  expect((await response(page,'personnel/drafts/'+item.id)).status()).toBe(404);const latest=await api<Definition>(page,'personnel/identities/'+identity.id);expect(latest.description).toBe('Q36 已保存身份输入');identity=latest;
  124 | });
  125 | 
  126 | test('Q36 actual draft CAS conflict preserves input; business success keeps a newer draft version',async({page})=>{
  127 |  await enter(page);await restoreKind(page,'权限模板');const items=(await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts')).items;const original=await api<PersonnelDraft>(page,'personnel/drafts/'+items.find(d=>d.kind==='template')!.id);
  128 |  if(original.kind!=='template')throw Error('wrong isolated fixture kind');
  129 |  await api(page,'personnel/drafts/'+original.id,'PUT',{version:original.version,payload:{...original.payload,description:'其他标签草稿输入'}});
  130 |  await page.getByLabel('说明',{exact:true}).fill('本标签未保存输入');await page.getByRole('button',{name:'保存草稿',exact:true}).click();await expect(page.getByRole('alert')).toContainText('草稿已由其他标签页修改');await expect(page.getByLabel('说明',{exact:true})).toHaveValue('本标签未保存输入');await shot(page,'draft-cas-conflict-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'draft-cas-conflict-narrow');
  131 |  await page.getByRole('button',{name:'保留当前输入，采用最新草稿版本',exact:true}).click();await saved(page);
  132 |  const adopted=await api<PersonnelDraft>(page,'personnel/drafts/'+original.id);expect(adopted.version).toBe(original.version+2);expect(adopted.baseVersion).toBe(original.baseVersion);
  133 |  if(adopted.kind!=='template')throw Error('wrong isolated fixture kind');const newer=await api<PersonnelDraft>(page,'personnel/drafts/'+original.id,'PUT',{version:adopted.version,payload:{...adopted.payload,description:'必须保留的新草稿'}});
  134 |  await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByRole('button',{name:'确认保存',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'已保存'})).toBeVisible();const preserved=await api<PersonnelDraft>(page,'personnel/drafts/'+original.id);expect(preserved.version).toBe(newer.version);expect(preserved.payload).toMatchObject({description:'必须保留的新草稿'});
  135 | });
  136 | 
  137 | test('Q36 actual drafts remain isolated between two currently authorized accounts',async({page,browser})=>{
  138 |  await enter(page);const foreign=(await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts')).items[0];expect(foreign).toBeTruthy();
  139 |  const target=await api<Member>(page,'personnel/members/'+fixture.userId);
  140 |  const grant=await api<Definition>(page,'personnel/identities','POST',{name:'Q36 隔离验证授权 '+stamp,description:'仅测试账号',templateIds:[],permissionCodes:['personnel.manage']});
  141 |  const query=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});
  142 |  const granted=await api<Member>(page,'personnel/members/'+target.id+'/identities','PUT',{identityIds:[...target.identityIds,grant.id],version:target.version,queryVersion:query.queryVersion});
  143 |  const context=await browser.newContext({ignoreHTTPSErrors:true});
  144 |  try{
  145 |   await login(context,fixture.user);const other=await context.newPage();await other.goto('/app/admin');await expect(other.getByRole('button',{name:'草稿箱',exact:true})).toBeVisible();
  146 |   const own=(await api<{items:PersonnelDraftSummary[]}>(other,'personnel/drafts')).items;expect(own.some(d=>d.id===foreign.id)).toBe(false);
  147 |   for(const method of ['GET','PUT','DELETE']){
  148 |    const denied=await response(other,'personnel/drafts/'+foreign.id+(method==='DELETE'?'?version='+foreign.version:''),method,method==='PUT'?{version:foreign.version,payload:{name:'禁止跨账户覆盖',parentId:null}}:undefined);
  149 |    expect(denied.status(),'foreign draft '+method).toBe(404);
  150 |   }
```