# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: filter-manager-web.spec.ts >> real events hidden time still sorts server results, time comparisons NULL and narrow fixed footer
- Location: tests/acceptance/filter-manager-web.spec.ts:65:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('dialog', { name: '管理自定义筛选', exact: true }).getByText('已应用', { exact: true })
Expected: 1
Received: 0
Timeout:  10000ms

Call log:
  - Expect "toHaveCount" getByRole('dialog', { name: '管理自定义筛选', exact: true }).getByText('已应用', { exact: true }) with timeout 10000ms
  - waiting for getByRole('dialog', { name: '管理自定义筛选', exact: true }).getByText('已应用', { exact: true })
    24 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e4]:
    - banner [ref=e5]:
      - strong [ref=e7]: 管理后台
      - generic [ref=e8]:
        - button "草稿箱" [ref=e9] [cursor=pointer]
        - button "保存" [disabled] [ref=e10]
        - button "退出" [ref=e11] [cursor=pointer]
    - complementary [ref=e12]:
      - generic [ref=e13]: 管理功能
      - button "人员管理" [ref=e14] [cursor=pointer]
      - paragraph [ref=e16]: 成员 · 部门 · 身份 · 权限
    - main [ref=e17]:
      - generic [ref=e18]:
        - heading "人员管理" [level=1] [ref=e19]
        - paragraph [ref=e20]: 统一管理成员、部门、身份与应用访问。
      - tablist "人员管理视图" [ref=e21]:
        - generic [ref=e22]:
          - tab "成员与部门" [ref=e23] [cursor=pointer]
          - tab "身份" [ref=e24] [cursor=pointer]
          - tab "权限模板" [ref=e25] [cursor=pointer]
          - tab "操作记录" [selected] [ref=e26] [cursor=pointer]
      - button "刷新查询" [ref=e28] [cursor=pointer]
      - tabpanel "操作记录" [ref=e29]:
        - generic [ref=e30]:
          - generic [ref=e31]:
            - heading "操作记录" [level=2] [ref=e32]
            - paragraph [ref=e33]: 查看成员、部门与权限配置的变更记录
          - combobox "操作类型" [ref=e35] [cursor=pointer]:
            - generic [ref=e36]: 全部操作
        - generic [ref=e39]:
          - generic [ref=e40]:
            - textbox "搜索操作记录" [ref=e42]:
              - /placeholder: 搜索成员或操作对象
            - button "自定义筛选" [expanded] [ref=e44] [cursor=pointer]
            - dialog [ref=e47]:
              - generic [ref=e48]:
                - banner [ref=e49]:
                  - heading "管理自定义筛选" [level=2] [ref=e50]
                  - button "关闭筛选管理" [ref=e51] [cursor=pointer]
                - generic [ref=e54]:
                  - alert [ref=e55]: 查询上下文已过期，请重新查询后继续
                  - button "新增筛选" [ref=e56] [cursor=pointer]
                  - list [ref=e59]:
                    - listitem [ref=e60]:
                      - strong [ref=e62]: 隐藏时间-webkit-1790921738274-31
                      - generic [ref=e63]:
                        - button "应用隐藏时间-webkit-1790921738274-31" [ref=e64] [cursor=pointer]: 应用
                        - button "编辑隐藏时间-webkit-1790921738274-31" [ref=e65] [cursor=pointer]: 编辑
                        - button "删除隐藏时间-webkit-1790921738274-31" [ref=e66] [cursor=pointer]: 删除
                  - button "重新加载方案列表" [ref=e67] [cursor=pointer]
            - paragraph [ref=e69]: 记录仅包含配置变更，不展示密码或邀请码明文。
            - group [ref=e70]:
              - generic "最近 7 天" [ref=e71] [cursor=pointer]
          - generic [ref=e73]:
            - generic [ref=e74]:
              - generic "操作记录表格滚动区域" [ref=e75]:
                - table "操作记录" [ref=e77]:
                  - rowgroup [ref=e78]:
                    - row [ref=e79]:
                      - columnheader "拖动以调整 occurredAt 列顺序 时间 排序 occurredAt Resize occurredAt column" [ref=e80]:
                        - generic [ref=e81]:
                          - button "拖动以调整 occurredAt 列顺序" [ref=e82]
                          - generic [ref=e85]:
                            - generic [ref=e86]: 时间
                            - button "排序 occurredAt" [ref=e87]
                        - button "Resize occurredAt column" [ref=e90]
                      - columnheader "拖动以调整 actorAccount 列顺序 操作者 Resize actorAccount column" [ref=e91]:
                        - generic [ref=e92]:
                          - button "拖动以调整 actorAccount 列顺序" [ref=e93]
                          - generic [ref=e96]: 操作者
                        - button "Resize actorAccount column" [ref=e98]
                      - columnheader "拖动以调整 action 列顺序 操作 Resize action column" [ref=e99]:
                        - generic [ref=e100]:
                          - button "拖动以调整 action 列顺序" [ref=e101]
                          - generic [ref=e104]: 操作
                        - button "Resize action column" [ref=e106]
                      - columnheader "拖动以调整 object 列顺序 对象 Resize object column" [ref=e107]:
                        - generic [ref=e108]:
                          - button "拖动以调整 object 列顺序" [ref=e109]
                          - generic [ref=e112]: 对象
                        - button "Resize object column" [ref=e114]
                      - columnheader "拖动以调整 detail 列顺序 变更内容 Resize detail column" [ref=e115]:
                        - generic [ref=e116]:
                          - button "拖动以调整 detail 列顺序" [ref=e117]
                          - generic [ref=e120]: 变更内容
                        - button "Resize detail column" [ref=e122]
                      - columnheader "拖动以调整 outcome 列顺序 结果 Resize outcome column" [ref=e123]:
                        - generic [ref=e124]:
                          - button "拖动以调整 outcome 列顺序" [ref=e125]
                          - generic [ref=e128]: 结果
                        - button "Resize outcome column" [ref=e130]
                  - rowgroup [ref=e131]:
                    - row [ref=e132]:
                      - cell "2026/10/2 05:46:10" [ref=e133]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e135]
                      - cell "新建身份" [ref=e137]
                      - cell "隔离授权-chromium-1790919954810-30" [ref=e139]
                      - cell "名称：无 → 隔离授权-chromium-1790919954810-30；说明：无 → 仅合成测试；权限：无 → 人员管理；权限模板：无 → 无" [ref=e141]
                      - cell "已完成" [ref=e143]
                    - row [ref=e145]:
                      - cell "2026/10/2 05:46:10" [ref=e146]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e148]
                      - cell "分配身份" [ref=e150]
                      - cell "acceptance-user-Q8WoJHxdvyfbSj6K" [ref=e152]
                      - cell "身份：无 → 隔离授权-chromium-1790919954810-30" [ref=e154]
                      - cell "已完成" [ref=e156]
                    - row [ref=e158]:
                      - cell "2026/10/2 05:46:10" [ref=e159]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e161]
                      - cell "分配身份" [ref=e163]
                      - cell "acceptance-user-Q8WoJHxdvyfbSj6K" [ref=e165]
                      - cell "身份：隔离授权-chromium-1790919954810-30 → 无" [ref=e167]
                      - cell "已完成" [ref=e169]
                    - row [ref=e171]:
                      - cell "2026/10/2 05:46:24" [ref=e172]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e174]
                      - cell "新建身份" [ref=e176]
                      - cell "Q36 测试身份 1790919984541" [ref=e178]
                      - cell "名称：无 → Q36 测试身份 1790919984541；说明：无 → 原说明；权限：无 → 无；权限模板：无 → 无" [ref=e180]
                      - cell "已完成" [ref=e182]
                    - row [ref=e184]:
                      - cell "2026/10/2 05:46:24" [ref=e185]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e187]
                      - cell "新建权限模板" [ref=e189]
                      - cell "Q36 测试模板 1790919984541" [ref=e191]
                      - cell "名称：无 → Q36 测试模板 1790919984541；说明：无 → 原模板说明；权限：无 → 无；权限模板：无 → 无" [ref=e193]
                      - cell "已完成" [ref=e195]
                    - row [ref=e197]:
                      - cell "2026/10/2 05:46:24" [ref=e198]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e200]
                      - cell "新建部门" [ref=e202]
                      - cell "Q36 测试部门 1790919984541" [ref=e204]
                      - cell "名称：无 → Q36 测试部门 1790919984541；父部门：无 → 企业" [ref=e206]
                      - cell "已完成" [ref=e208]
                    - row [ref=e210]:
                      - cell "2026/10/2 05:46:24" [ref=e211]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e213]
                      - cell "邀请成员" [ref=e215]
                      - cell "邀请码" [ref=e217]
                      - cell "已生成单次邀请码" [ref=e219]
                      - cell "已完成" [ref=e221]
                    - row [ref=e223]:
                      - cell "2026/10/2 05:46:24" [ref=e224]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e226]
                      - cell "邀请成员" [ref=e228]
                      - cell "邀请码" [ref=e230]
                      - cell "已生成单次邀请码" [ref=e232]
                      - cell "已完成" [ref=e234]
                    - row [ref=e236]:
                      - cell "2026/10/2 05:46:24" [ref=e237]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e239]
                      - cell "邀请成员" [ref=e241]
                      - cell "邀请码" [ref=e243]
                      - cell "已生成单次邀请码" [ref=e245]
                      - cell "已完成" [ref=e247]
                    - row [ref=e249]:
                      - cell "2026/10/2 05:46:24" [ref=e250]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e252]
                      - cell "邀请成员" [ref=e254]
                      - cell "邀请码" [ref=e256]
                      - cell "已生成单次邀请码" [ref=e258]
                      - cell "已完成" [ref=e260]
                    - row [ref=e262]:
                      - cell "2026/10/2 05:46:24" [ref=e263]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e265]
                      - cell "邀请成员" [ref=e267]
                      - cell "邀请码" [ref=e269]
                      - cell "已生成单次邀请码" [ref=e271]
                      - cell "已完成" [ref=e273]
                    - row [ref=e275]:
                      - cell "2026/10/2 05:46:24" [ref=e276]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e278]
                      - cell "邀请成员" [ref=e280]
                      - cell "邀请码" [ref=e282]
                      - cell "已生成单次邀请码" [ref=e284]
                      - cell "已完成" [ref=e286]
                    - row [ref=e288]:
                      - cell "2026/10/2 05:46:24" [ref=e289]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e291]
                      - cell "邀请成员" [ref=e293]
                      - cell "邀请码" [ref=e295]
                      - cell "已生成单次邀请码" [ref=e297]
                      - cell "已完成" [ref=e299]
                    - row [ref=e301]:
                      - cell "2026/10/2 05:46:24" [ref=e302]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e304]
                      - cell "邀请成员" [ref=e306]
                      - cell "邀请码" [ref=e308]
                      - cell "已生成单次邀请码" [ref=e310]
                      - cell "已完成" [ref=e312]
                    - row [ref=e314]:
                      - cell "2026/10/2 05:46:24" [ref=e315]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e317]
                      - cell "邀请成员" [ref=e319]
                      - cell "邀请码" [ref=e321]
                      - cell "已生成单次邀请码" [ref=e323]
                      - cell "已完成" [ref=e325]
                    - row [ref=e327]:
                      - cell "2026/10/2 05:46:24" [ref=e328]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e330]
                      - cell "邀请成员" [ref=e332]
                      - cell "邀请码" [ref=e334]
                      - cell "已生成单次邀请码" [ref=e336]
                      - cell "已完成" [ref=e338]
                    - row [ref=e340]:
                      - cell "2026/10/2 05:46:24" [ref=e341]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e343]
                      - cell "邀请成员" [ref=e345]
                      - cell "邀请码" [ref=e347]
                      - cell "已生成单次邀请码" [ref=e349]
                      - cell "已完成" [ref=e351]
                    - row [ref=e353]:
                      - cell "2026/10/2 05:46:25" [ref=e354]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e356]
                      - cell "邀请成员" [ref=e358]
                      - cell "邀请码" [ref=e360]
                      - cell "已生成单次邀请码" [ref=e362]
                      - cell "已完成" [ref=e364]
                    - row [ref=e366]:
                      - cell "2026/10/2 05:46:25" [ref=e367]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e369]
                      - cell "邀请成员" [ref=e371]
                      - cell "邀请码" [ref=e373]
                      - cell "已生成单次邀请码" [ref=e375]
                      - cell "已完成" [ref=e377]
                    - row [ref=e379]:
                      - cell "2026/10/2 05:46:25" [ref=e380]
                      - cell "acceptance-admin-gJkyc-rSERgk2KZ3" [ref=e382]
                      - cell "邀请成员" [ref=e384]
                      - cell "邀请码" [ref=e386]
                      - cell "已生成单次邀请码" [ref=e388]
                      - cell "已完成" [ref=e390]
              - generic [ref=e393] [cursor=pointer]
            - generic [ref=e394]:
              - generic [ref=e395]:
                - generic [ref=e396]: 每页条数
                - generic [ref=e397]:
                  - combobox "每页条数" [ref=e398]:
                    - generic [ref=e399]: "20"
                  - listbox [aria-hidden]:
                    - generic:
                      - generic:
                        - listitem:
                          - option: "5"
                        - listitem:
                          - option: "10"
                        - listitem:
                          - option [selected]: "20"
                        - listitem:
                          - option: "25"
                        - listitem:
                          - option: "50"
                        - listitem:
                          - option: "100"
              - generic [ref=e403]:
                - generic [ref=e404]: 1 - 20 / 共 308 项
                - navigation "Pagination" [ref=e405]:
                  - button "上一页" [disabled]
                  - button "Page 1" [ref=e406]: "1"
                  - button "Page 2" [ref=e407]: "2"
                  - button "Page 3" [ref=e408]: "3"
                  - button "Page 4" [ref=e409]: "4"
                  - button "Page 5" [ref=e410]: "5"
                  - button "Next pages" [ref=e411]: ...
                  - button "Page 16" [ref=e412]: "16"
                  - button "下一页" [ref=e413]
                  - generic [ref=e414]:
                    - generic [ref=e415]:
                      - text: 跳至页
                      - spinbutton "跳至页" [ref=e416]: "1"
                    - button "跳转到指定页" [ref=e417]
  - generic:
    - menu [aria-hidden]:
      - generic:
        - generic:
          - generic:
            - menuitem: 升序
          - generic:
            - menuitem: 降序
```

# Test source

```ts
  1  | import {test,expect,type Page,type BrowserContext,type Locator,type APIResponse} from '@playwright/test';
  2  | import {readFileSync,mkdirSync} from 'node:fs';
  3  | import {rename} from 'node:fs/promises';
  4  | import {resolve} from 'node:path';
  5  | import type {TablePreset} from '../../apps/web/src/TablePresetState';
  6  | import type {Member,Definition} from '../../apps/web/src/workspace-types';
  7  | import type {MembersQueryPage} from '../../apps/web/src/query-contracts';
  8  | 
  9  | // PRD / ADR008 A1–A7, reread at frozen revisions 02:58 UTC. Real APIs only;
  10 | // no request mocks, no credential-bearing browser trace or login video.
  11 | test.use({trace:'off',screenshot:'off',video:'off'});
  12 | const base=process.env.WEAVEOS_WEB_URL!;
  13 | if(!base?.startsWith('https://')||!['localhost','127.0.0.1'].includes(new URL(base).hostname))throw Error('isolated HTTPS required');
  14 | const fixture=JSON.parse(readFileSync(process.env.WEAVEOS_ACCEPTANCE_FIXTURES!,'utf8')) as {admin:{account:string;password:string};user:{account:string;password:string};userId:string};
  15 | const evidence=resolve('docs/evidence/V010-020/filter-manager/real');mkdirSync(evidence,{recursive:true});
  16 | const created:string[]=[];let counter=0;const stamp=Date.now();
  17 | const name=(label:string)=>label+'-'+test.info().project.name+'-'+stamp+'-'+(++counter);
  18 | async function login(context:BrowserContext,credentials=fixture.admin){const res=await context.request.post(base+'/api/v1/sessions',{headers:{Origin:base},data:credentials});expect(res.status(),'synthetic login').toBe(201);}
  19 | async function request(page:Page,path:string,method='GET',data?:object):Promise<APIResponse>{const csrf=(await page.context().cookies(base)).find(c=>c.name==='__Host-csrf');return page.request.fetch(base+'/api/v1/'+path,{method,headers:{Origin:base,...(csrf?{'X-CSRF-Token':csrf.value}:{})},...(data?{data}:{})});}
  20 | async function api<T>(page:Page,path:string,method='GET',data?:object):Promise<T>{const res=await request(page,path,method,data);expect(res.ok(),method+' '+path.split('?')[0]+' status '+res.status()).toBe(true);if(res.status()===204)return undefined as T;const body=await res.json();expect(body.code).toBe('OK');return body.data as T;}
  21 | async function enter(page:Page){await login(page.context());page.on('dialog',d=>void d.accept());await page.goto('/app/admin');await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');await expect(page.locator('.member-table tbody tr[data-row-id]').first()).toBeVisible();}
  22 | async function manager(page:Page){await page.getByRole('button',{name:/^自定义筛选/}).click();const d=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await expect(d).toBeVisible();return d;}
  23 | async function newEditor(page:Page,panel:Locator){await panel.getByRole('button',{name:'新增筛选',exact:true}).click();const d=page.getByRole('dialog',{name:'新增自定义筛选',exact:true});await expect(d).toBeVisible();return d;}
  24 | async function create(page:Page,label:string,hidden:string[]=[],filter:unknown=null,view='members'){const p=await api<TablePreset>(page,'personnel/table-presets','POST',{view,name:name(label),hiddenColumnIds:hidden,filter,schemaVersion:1});created.push(p.id);return p;}
  25 | async function save(page:Page,d:Locator){const response=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname.endsWith('/table-presets'));await d.getByRole('button',{name:'确定',exact:true}).click();const r=await response;expect(r.status()).toBe(201);const p=(await r.json()).data as TablePreset;created.push(p.id);return p;}
  26 | async function close(panel:Locator){await panel.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(panel).toBeHidden();}
  27 | async function settle(page:Page){await page.evaluate(()=>document.fonts.ready);await page.waitForFunction(()=>!document.documentElement.classList.contains('q36-filter-transition-active'));await page.evaluate(()=>Promise.allSettled(document.getAnimations().map(a=>a.finished)));}
  28 | async function shot(page:Page,label:string){await settle(page);await page.screenshot({path:resolve(evidence,test.info().project.name+'-'+label+'.png'),fullPage:true});}
> 29 | async function apply(panel:Locator,p:TablePreset){await panel.getByRole('button',{name:'应用'+p.name,exact:true}).click();await expect(panel.getByText('已应用',{exact:true})).toHaveCount(1);}
     |                                                                                                                                                                           ^ Error: expect(locator).toHaveCount(expected) failed
  30 | async function cancel(page:Page,panel:Locator){await panel.getByRole('button',{name:'取消应用',exact:true}).click();const c=page.getByRole('dialog',{name:'取消当前筛选',exact:true});await expect(c).toBeVisible();await c.getByRole('button',{name:'确认取消',exact:true}).click();await expect(panel.getByText('已应用',{exact:true})).toHaveCount(0);}
  31 | test.afterEach(async({page})=>{for(const id of created.splice(0)){const r=await request(page,'personnel/table-presets/'+id);if(r.status()===404)continue;expect(r.ok()).toBe(true);const p=(await r.json()).data as TablePreset;expect((await request(page,'personnel/table-presets/'+id+'?version='+p.version,'DELETE')).status()).toBe(204);}});
  32 | 
  33 | test('real centered empty manager, finite AND OR typed save-only, visibility and fresh-login persistence',async({page,browser})=>{
  34 |  await enter(page);const queries:Record<string,unknown>[]=[];page.on('request',r=>{if(r.url().endsWith('/personnel/members/search'))queries.push(r.postDataJSON());});const panel=await manager(page);await expect(panel).toContainText('暂无自定义筛选');const b=(await panel.boundingBox())!;expect(b.width).toBe(440);expect(b.x+b.width/2).toBeCloseTo(720,0);expect(b.y+b.height/2).toBeCloseTo(500,0);await shot(page,'manager-empty');
  35 |  const d=await newEditor(page,panel);await d.getByLabel('自定义筛选名称',{exact:true}).fill('  '+name('成员方案')+'  ');await shot(page,'editor-empty');await d.getByRole('button',{name:'或条件',exact:true}).click();await d.getByLabel('条件 1.1 值',{exact:true}).fill(fixture.admin.account);
  36 |  await d.getByRole('button',{name:'组 1 且条件',exact:true}).click();await d.getByLabel('条件 1.2 字段',{exact:true}).selectOption('status');await d.getByLabel('条件 1.2 值',{exact:true}).selectOption('active');await d.getByRole('button',{name:'或条件',exact:true}).click();await d.getByLabel('条件 2.1 值',{exact:true}).fill(fixture.user.account);
  37 |  await d.getByRole('button',{name:'隐藏部门',exact:true}).click();await d.getByLabel('隐藏字段搜索',{exact:true}).fill('部门');await d.getByLabel('显示字段搜索',{exact:true}).fill('身份');await shot(page,'editor-and-or-dual-search');await expect(d.getByRole('button',{name:'隐藏成员',exact:true})).toHaveCount(0);await expect(d.getByRole('button',{name:'显示部门',exact:true})).toBeVisible();
  38 |  const p=await save(page,d);expect(queries).toHaveLength(0);expect(p.name).toBe(p.name.trim());expect(p.filter).toEqual({operator:'or',children:[{operator:'and',children:[{field:'account',operator:'eq',value:fixture.admin.account},{field:'status',operator:'eq',value:'active'}]},{operator:'and',children:[{field:'account',operator:'eq',value:fixture.user.account}]}]});expect(p.hiddenColumnIds).toEqual(['departments']);await shot(page,'manager-saved');await close(panel);await page.reload();await expect(page.getByRole('button',{name:'自定义筛选',exact:true})).toBeVisible();await expect(page.locator('.member-table thead')).toContainText('部门');
  39 |  const context=await browser.newContext({ignoreHTTPSErrors:true});try{await login(context);const other=await context.newPage();await other.goto('/app/admin');const again=await manager(other);await expect(again.getByRole('button',{name:'应用'+p.name,exact:true})).toBeVisible();await expect(again.getByText('已应用',{exact:true})).toHaveCount(0);}finally{await context.close();}
  40 | });
  41 | 
  42 | test('real one active snapshot, save-without-apply, first baseline across A B, widths and confirmed deletion',async({page})=>{
  43 |  await enter(page);const a=await create(page,'隐藏部门',['departments']),b=await create(page,'隐藏身份',['identities']);const headers=page.locator('.member-table thead');const before=(await headers.getByRole('columnheader').filter({hasText:'成员'}).boundingBox())!.width;let queryCount=0;page.on('request',r=>{if(r.url().endsWith('/personnel/members/search'))queryCount++;});const panel=await manager(page);await apply(panel,a);await expect(headers).not.toContainText('部门');expect(queryCount).toBe(0);await shot(page,'manager-active');
  44 |  await panel.getByRole('button',{name:'编辑'+a.name,exact:true}).click();const d=page.getByRole('dialog',{name:'编辑自定义筛选',exact:true});await d.getByRole('button',{name:'显示部门',exact:true}).click();await d.getByRole('button',{name:'确定',exact:true}).click();await expect(panel).toContainText('已修改，待应用');await expect(headers).not.toContainText('部门');expect(queryCount).toBe(0);
  45 |  await apply(panel,b);await expect(headers).toContainText('部门');await expect(headers).not.toContainText('身份');await cancel(page,panel);await expect(headers).toContainText('部门');await expect(headers).toContainText('身份');expect((await headers.getByRole('columnheader').filter({hasText:'成员'}).boundingBox())!.width).toBeCloseTo(before,0);expect(queryCount).toBe(0);
  46 |  await apply(panel,b);await panel.getByRole('button',{name:'删除'+b.name,exact:true}).click();const c=page.getByRole('dialog',{name:'删除筛选方案',exact:true});await expect(c).toContainText('取消当前应用');await shot(page,'delete-active-confirm');await c.getByRole('button',{name:'返回',exact:true}).click();await expect(headers).not.toContainText('身份');await panel.getByRole('button',{name:'删除'+b.name,exact:true}).click();await c.getByRole('button',{name:'确认删除',exact:true}).click();await expect(headers).toContainText('身份');expect((await request(page,'personnel/table-presets/'+b.id)).status()).toBe(404);await expect(panel.getByText('已应用',{exact:true})).toHaveCount(0);
  47 | });
  48 | 
  49 | test('real stale CAS preserves input and explicit reload; precise same-view name collision',async({page})=>{
  50 |  await enter(page);const p=await create(page,'并发方案');const panel=await manager(page);await panel.getByRole('button',{name:'编辑'+p.name,exact:true}).click();const d=page.getByRole('dialog',{name:'编辑自定义筛选',exact:true});const local=name('保留当前输入');await d.getByLabel('自定义筛选名称',{exact:true}).fill(local);await api(page,'personnel/table-presets/'+p.id,'PUT',{name:p.name,filter:null,hiddenColumnIds:['departments'],schemaVersion:1,version:p.version});await d.getByRole('button',{name:'确定',exact:true}).click();await expect(d.getByRole('alert')).toContainText('其他标签页');await expect(d.getByLabel('自定义筛选名称',{exact:true})).toHaveValue(local);await shot(page,'cas-conflict');await d.getByRole('button',{name:'重新加载最新方案',exact:true}).click();const c=page.getByRole('dialog',{name:'重新加载最新方案',exact:true});await expect(c).toBeVisible();await c.getByRole('button',{name:'返回',exact:true}).click();await expect(d.getByLabel('自定义筛选名称',{exact:true})).toHaveValue(local);await d.getByRole('button',{name:'重新加载最新方案',exact:true}).click();await c.getByRole('button',{name:'确认重新加载',exact:true}).click();await expect(d.getByLabel('自定义筛选名称',{exact:true})).toHaveValue(p.name);await expect(d.getByRole('button',{name:'显示部门',exact:true})).toBeVisible();await d.getByRole('button',{name:'取消',exact:true}).click();const fresh=await newEditor(page,panel);await fresh.getByLabel('自定义筛选名称',{exact:true}).fill(p.name);await fresh.getByRole('button',{name:'确定',exact:true}).click();await expect(fresh.getByRole('alert')).toContainText('名称已存在');await expect(fresh.getByLabel('自定义筛选名称',{exact:true})).toHaveValue(p.name);await shot(page,'name-conflict');
  51 | });
  52 | 
  53 | test('real quota is twenty per view, UI disables new and a deletion frees a slot',async({page})=>{
  54 |  await enter(page);const list:TablePreset[]=[];for(let i=0;i<20;i++)list.push(await create(page,'额度'+i));const panel=await manager(page);await expect(panel.locator('.preset-list li')).toHaveCount(20);await expect(panel.getByRole('button',{name:'新增筛选',exact:true})).toBeDisabled();const denied=await request(page,'personnel/table-presets','POST',{view:'members',name:name('超额'),filter:null,hiddenColumnIds:[],schemaVersion:1});expect(denied.status()).toBe(409);expect((await denied.json()).code).toBe('PERSONNEL_PRESET_LIMIT_REACHED');await panel.getByRole('button',{name:'删除'+list[0].name,exact:true}).click();await page.getByRole('dialog',{name:'删除筛选方案',exact:true}).getByRole('button',{name:'确认删除',exact:true}).click();await expect(panel.getByRole('button',{name:'新增筛选',exact:true})).toBeEnabled();await create(page,'空出的额度');const event=await create(page,'另一视图额度',[],null,'events');expect(event.view).toBe('events');
  55 | });
  56 | 
  57 | test('real permission and owner isolation forbid foreign GET PUT DELETE and live revoked access',async({page,browser})=>{
  58 |  await enter(page);const p=await create(page,'仅本账户');const target=await api<Member>(page,'personnel/members/'+fixture.userId);const grant=await api<Definition>(page,'personnel/identities','POST',{name:name('隔离授权'),description:'仅合成测试',templateIds:[],permissionCodes:['personnel.manage']});const q=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});await api(page,'personnel/members/'+target.id+'/identities','PUT',{version:target.version,identityIds:[...target.identityIds,grant.id],queryVersion:q.queryVersion});const context=await browser.newContext({ignoreHTTPSErrors:true});try{
  59 |   await login(context,fixture.user);const other=await context.newPage();await other.goto('/app/admin');await expect(other.getByRole('button',{name:/^自定义筛选/})).toBeVisible();expect((await api<{items:TablePreset[]}>(other,'personnel/table-presets?view=members')).items.some(v=>v.id===p.id)).toBe(false);
  60 |   for(const method of ['GET','PUT','DELETE']){const r=await request(other,'personnel/table-presets/'+p.id+(method==='DELETE'?'?version=1':''),method,method==='PUT'?{version:1,name:p.name,filter:null,hiddenColumnIds:[],schemaVersion:1}:undefined);expect(r.status(),'foreign '+method).toBe(404);}
  61 |   const latest=await api<Member>(page,'personnel/members/'+target.id),current=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});await api(page,'personnel/members/'+target.id+'/identities','PUT',{version:latest.version,identityIds:target.identityIds,queryVersion:current.queryVersion});expect((await request(other,'personnel/table-presets?view=members')).status()).toBe(403);
  62 |  }finally{await context.close();const latest=await api<Member>(page,'personnel/members/'+target.id);if(latest.identityIds.includes(grant.id)){const current=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});await api(page,'personnel/members/'+target.id+'/identities','PUT',{version:latest.version,identityIds:target.identityIds,queryVersion:current.queryVersion});}}
  63 | });
  64 | 
  65 | test('real events hidden time still sorts server results, time comparisons NULL and narrow fixed footer',async({page})=>{
  66 |  await enter(page);await page.getByRole('tab',{name:'操作记录',exact:true}).click();await expect(page.locator('.activity-table table')).toHaveAttribute('aria-busy','false');await page.getByRole('button',{name:'排序 occurredAt',exact:true}).click();await page.getByRole('menuitem',{name:'升序',exact:true}).click();await expect(page.locator('.activity-table th[aria-sort]')).toHaveAttribute('aria-sort','ascending');const p=await create(page,'隐藏时间',['occurredAt'],null,'events');const panel=await manager(page);await apply(panel,p);await expect(page.locator('.activity-table thead')).not.toContainText('时间');await close(panel);await page.getByRole('button',{name:'刷新查询',exact:true}).click();await expect(page.locator('.activity-table table')).toHaveAttribute('aria-busy','false');const values=await page.locator('.activity-table tbody tr[data-row-id]').evaluateAll(rows=>rows.map(r=>r.textContent));expect(values.length).toBeGreaterThan(0);
  67 |  const again=await manager(page),d=await newEditor(page,again);await d.getByLabel('自定义筛选名称',{exact:true}).fill(name('时间比较'));await d.getByRole('button',{name:'或条件',exact:true}).click();await d.getByLabel('条件 1.1 字段',{exact:true}).selectOption('occurredAt');await expect(d.getByLabel('条件 1.1 字段',{exact:true})).toContainText('时间（已隐藏）');await d.getByLabel('条件 1.1 比较',{exact:true}).selectOption('gte');await d.getByLabel('条件 1.1 值类型',{exact:true}).selectOption('date');await d.getByLabel('条件 1.1 日期',{exact:true}).fill('2026-10-02');await d.getByLabel('条件 1.1 时区',{exact:true}).fill('Asia/Shanghai');await d.getByRole('button',{name:'组 1 且条件',exact:true}).click();await d.getByLabel('条件 1.2 字段',{exact:true}).selectOption('actorAccount');await d.getByLabel('条件 1.2 值类型',{exact:true}).selectOption('null');await shot(page,'events-time-null');
  68 |  await expect(d.getByLabel('条件 1.1 比较',{exact:true}).locator('option')).toHaveText(['等于','不等于','晚于','不早于','早于','不晚于']);await d.getByLabel('条件 1.1 比较',{exact:true}).click();await page.screenshot({path:resolve(evidence,test.info().project.name+'-operators-menu.png'),fullPage:true});await d.getByLabel('自定义筛选名称',{exact:true}).click();await d.getByLabel('条件 1.1 比较',{exact:true}).selectOption('gte');await page.setViewportSize({width:390,height:844});await shot(page,'editor-narrow');const box=(await d.boundingBox())!;expect(box.x).toBeGreaterThanOrEqual(12);expect(box.x+box.width).toBeLessThanOrEqual(378);await expect(d.getByRole('button',{name:'确定',exact:true})).toBeInViewport();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);const stored=await save(page,d);expect(stored.filter).toEqual({operator:'and',children:[{field:'occurredAt',operator:'gte',value:{date:'2026-10-02',timeZone:'Asia/Shanghai'}},{field:'actorAccount',operator:'eq',value:null}]});
  69 | });
  70 | 
  71 | test('real actual formal page open close reversal and reduced motion video',async({browser})=>{
  72 |  const context=await browser.newContext({ignoreHTTPSErrors:true,viewport:{width:1440,height:1000},recordVideo:{dir:evidence,size:{width:1440,height:1000}}});await login(context);const page=await context.newPage();await page.goto('/app/admin');await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');await settle(page);const trigger=page.getByRole('button',{name:'自定义筛选',exact:true}),d=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await page.waitForTimeout(400);await trigger.click();await expect(d).toBeVisible();await settle(page);await page.waitForTimeout(600);
  73 |  const triggerBox=(await trigger.boundingBox())!,closeBox=(await d.getByRole('button',{name:'关闭筛选管理',exact:true}).boundingBox())!;await page.evaluate(()=>{(window as unknown as {presetTrusted:boolean[]}).presetTrusted=[];for(const el of [document.querySelector('[aria-label="关闭筛选管理"]'),document.querySelector('.q36-filter-trigger')])el?.addEventListener('click',e=>(window as unknown as {presetTrusted:boolean[]}).presetTrusted.push(e.isTrusted),{once:true});});await page.mouse.click(closeBox.x+closeBox.width/2,closeBox.y+closeBox.height/2);await page.waitForTimeout(60);await page.mouse.click(triggerBox.x+triggerBox.width/2,triggerBox.y+triggerBox.height/2);expect(await page.evaluate(()=>(window as unknown as {presetTrusted:boolean[]}).presetTrusted)).toEqual([true,true]);await expect(d).toBeVisible();await settle(page);await page.waitForTimeout(500);await page.keyboard.press('Escape');await expect(d).toBeHidden();await settle(page);await expect(trigger).toBeFocused();await expect(trigger.locator('svg')).toBeVisible();await page.waitForTimeout(500);await trigger.click();await expect(d).toBeVisible();await shot(page,'motion-reopen');await page.waitForTimeout(500);await page.keyboard.press('Escape');await expect(d).toBeHidden();await settle(page);await page.emulateMedia({reducedMotion:'reduce'});await trigger.click();await expect(d).toBeVisible();await page.keyboard.press('Escape');await expect(d).toBeHidden();await settle(page);await expect(trigger).toBeFocused();await page.waitForTimeout(500);const video=page.video();await context.close();if(!video)throw Error('formal-page video unavailable');await rename(await video.path(),resolve(evidence,test.info().project.name+'-formal-open-close-reversal-reduced.webm'));
  74 | });
  75 | 
  76 | test('real deleted reference fails before search and keeps the original persisted predicate',async({page})=>{
  77 |  await enter(page);const identity=await api<Definition>(page,'personnel/identities','POST',{name:name('待删除引用'),description:'仅合成测试',templateIds:[],permissionCodes:[]});const filter={operator:'and',children:[{field:'identityIds',operator:'eq',value:identity.id}]};const p=await create(page,'失效引用',[],filter);await api(page,'personnel/identities/'+identity.id+'?version='+identity.version,'DELETE');let count=0;page.on('request',r=>{if(r.url().endsWith('/personnel/members/search'))count++;});const panel=await manager(page);await panel.getByRole('button',{name:'应用'+p.name,exact:true}).click();await expect(panel.getByRole('alert')).toContainText('已失效引用');expect(count).toBe(0);await expect(panel.getByText('已应用',{exact:true})).toHaveCount(0);expect((await api<TablePreset>(page,'personnel/table-presets/'+p.id)).filter).toEqual(filter);await shot(page,'reference-conflict');
  78 | });
  79 | 
  80 | test('real hidden identity change still invalidates apply; successful delete and failed clear retain old snapshot',async({page})=>{
  81 |  await enter(page);const a=await create(page,'当前显隐',['identities']),b=await create(page,'待应用过滤',['departments'],{operator:'and',children:[{field:'account',operator:'eq',value:fixture.admin.account}]});const panel=await manager(page);await apply(panel,a);await expect(page.locator('.member-table thead')).not.toContainText('身份');await close(panel);const selected=page.getByLabel('选择成员：'+fixture.admin.account,{exact:true});await selected.check();
  82 |  const target=await api<Member>(page,'personnel/members/'+fixture.userId),identity=await api<Definition>(page,'personnel/identities','POST',{name:name('隐藏依赖'),description:'仅合成测试',templateIds:[],permissionCodes:[]}),query=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});await api(page,'personnel/members/'+target.id+'/identities','PUT',{identityIds:[...target.identityIds,identity.id],version:target.version,queryVersion:query.queryVersion});
  83 |  try{const again=await manager(page);let count=0;page.on('request',r=>{if(r.url().endsWith('/personnel/members/search'))count++;});await again.getByRole('button',{name:'应用'+b.name,exact:true}).click();await expect(again.getByRole('alert')).toContainText('查询结果已变化');expect(count).toBe(1);await expect(selected).toBeChecked();await expect(page.locator('.member-table thead')).not.toContainText('身份');await expect(page.locator('.member-table thead')).toContainText('部门');await expect(again.locator('li').filter({hasText:a.name})).toContainText('已应用');
  84 |   await again.getByRole('button',{name:'删除'+a.name,exact:true}).click();await page.getByRole('dialog',{name:'删除筛选方案',exact:true}).getByRole('button',{name:'确认删除',exact:true}).click();await expect(again.getByRole('alert')).toContainText('方案已删除');await expect(again.getByRole('alert')).toContainText('查询结果已变化');expect((await request(page,'personnel/table-presets/'+a.id)).status()).toBe(404);await expect(page.locator('.member-table thead')).not.toContainText('身份');await expect(selected).toBeChecked();await shot(page,'deleted-success-query-conflict');await close(again);await page.getByRole('button',{name:'刷新查询',exact:true}).click();await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');await cancel(page,await manager(page));await expect(page.locator('.member-table thead')).toContainText('身份');
  85 |  }finally{const latest=await api<Member>(page,'personnel/members/'+target.id),q=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});await api(page,'personnel/members/'+target.id+'/identities','PUT',{identityIds:target.identityIds,version:latest.version,queryVersion:q.queryVersion});}
  86 | });
  87 | 
```