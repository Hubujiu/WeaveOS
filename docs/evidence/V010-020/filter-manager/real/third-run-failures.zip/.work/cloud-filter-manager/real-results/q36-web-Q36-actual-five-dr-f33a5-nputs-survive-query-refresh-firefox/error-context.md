# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: q36-web.spec.ts >> Q36 actual five draft kinds persist after fresh login; member/department inputs survive query refresh
- Location: tests/acceptance/q36-web.spec.ts:112:5

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.click: Test timeout of 120000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Q36 测试身份 1790921598660', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - strong [ref=e7]: 管理后台
    - generic [ref=e8]:
      - button "草稿箱" [ref=e9] [cursor=pointer]
      - button "保存" [disabled] [ref=e10]
      - button "退出" [ref=e11] [cursor=pointer]
  - complementary [ref=e12]:
    - generic [ref=e13]: 管理功能
    - button "人员管理" [ref=e14] [cursor=pointer]
    - paragraph [ref=e16]: 成员 · 部门 · 身份 · 权限
  - main [ref=e17]:
    - generic [ref=e18]:
      - heading "人员管理" [level=1] [ref=e19]
      - paragraph [ref=e20]: 统一管理成员、部门、身份与应用访问。
    - tablist "人员管理视图" [ref=e21]:
      - generic [ref=e22]:
        - tab "成员与部门" [ref=e23] [cursor=pointer]
        - tab "身份" [active] [selected] [ref=e24] [cursor=pointer]
        - tab "权限模板" [ref=e25] [cursor=pointer]
        - tab "操作记录" [ref=e26] [cursor=pointer]
    - button "刷新查询" [ref=e28] [cursor=pointer]
    - tabpanel "身份" [ref=e29]:
      - generic [ref=e30]:
        - generic [ref=e31]:
          - heading "身份" [level=2] [ref=e32]
          - paragraph [ref=e33]: 先配置身份，再把身份分配给成员
        - button "新建身份" [ref=e34] [cursor=pointer]
      - generic [ref=e35]:
        - generic [ref=e36]:
          - textbox "搜索身份" [ref=e38]
          - button "隔离授权-chromium-1790919954810-30" [ref=e39] [cursor=pointer]:
            - strong [ref=e40]: 隔离授权-chromium-1790919954810-30
            - generic [ref=e41]: 仅合成测试
            - generic [ref=e42]: 0 位成员使用 · 1 项直接权限
          - button "Q36 测试身份 1790919984541" [ref=e43] [cursor=pointer]:
            - strong [ref=e44]: Q36 测试身份 1790919984541
            - generic [ref=e45]: Q36 已保存身份输入
            - generic [ref=e46]: 0 位成员使用 · 0 项直接权限
          - button "Q36 隔离验证授权 1790919984541" [ref=e47] [cursor=pointer]:
            - strong [ref=e48]: Q36 隔离验证授权 1790919984541
            - generic [ref=e49]: 仅测试账号
            - generic [ref=e50]: 0 位成员使用 · 1 项直接权限
          - button "隔离授权-firefox-1790920034075-30" [ref=e51] [cursor=pointer]:
            - strong [ref=e52]: 隔离授权-firefox-1790920034075-30
            - generic [ref=e53]: 仅合成测试
            - generic [ref=e54]: 0 位成员使用 · 1 项直接权限
          - button "Q36 测试身份 1790920184776" [ref=e55] [cursor=pointer]:
            - strong [ref=e56]: Q36 测试身份 1790920184776
            - generic [ref=e57]: Q36 已保存身份输入
            - generic [ref=e58]: 0 位成员使用 · 0 项直接权限
          - button "Q36 隔离验证授权 1790920184776" [ref=e59] [cursor=pointer]:
            - strong [ref=e60]: Q36 隔离验证授权 1790920184776
            - generic [ref=e61]: 仅测试账号
            - generic [ref=e62]: 0 位成员使用 · 1 项直接权限
          - button "隔离授权-webkit-1790920245707-30" [ref=e63] [cursor=pointer]:
            - strong [ref=e64]: 隔离授权-webkit-1790920245707-30
            - generic [ref=e65]: 仅合成测试
            - generic [ref=e66]: 0 位成员使用 · 1 项直接权限
          - button "Q36 测试身份 1790920392046" [ref=e67] [cursor=pointer]:
            - strong [ref=e68]: Q36 测试身份 1790920392046
            - generic [ref=e69]: Q36 已保存身份输入
            - generic [ref=e70]: 0 位成员使用 · 0 项直接权限
          - button "Q36 隔离验证授权 1790920392046" [ref=e71] [cursor=pointer]:
            - strong [ref=e72]: Q36 隔离验证授权 1790920392046
            - generic [ref=e73]: 仅测试账号
            - generic [ref=e74]: 0 位成员使用 · 1 项直接权限
          - button "隔离授权-chromium-1790920918227-30" [ref=e75] [cursor=pointer]:
            - strong [ref=e76]: 隔离授权-chromium-1790920918227-30
            - generic [ref=e77]: 仅合成测试
            - generic [ref=e78]: 0 位成员使用 · 1 项直接权限
          - button "隐藏依赖-chromium-1790920918227-37" [ref=e79] [cursor=pointer]:
            - strong [ref=e80]: 隐藏依赖-chromium-1790920918227-37
            - generic [ref=e81]: 仅合成测试
            - generic [ref=e82]: 0 位成员使用 · 0 项直接权限
          - button "Q36 测试身份 1790920955401" [ref=e83] [cursor=pointer]:
            - strong [ref=e84]: Q36 测试身份 1790920955401
            - generic [ref=e85]: Q36 已保存身份输入
            - generic [ref=e86]: 0 位成员使用 · 0 项直接权限
          - button "Q36 隔离验证授权 1790920955401" [ref=e87] [cursor=pointer]:
            - strong [ref=e88]: Q36 隔离验证授权 1790920955401
            - generic [ref=e89]: 仅测试账号
            - generic [ref=e90]: 0 位成员使用 · 1 项直接权限
          - button "隔离授权-firefox-1790921002181-30" [ref=e91] [cursor=pointer]:
            - strong [ref=e92]: 隔离授权-firefox-1790921002181-30
            - generic [ref=e93]: 仅合成测试
            - generic [ref=e94]: 0 位成员使用 · 1 项直接权限
          - button "隐藏依赖-firefox-1790921002181-37" [ref=e95] [cursor=pointer]:
            - strong [ref=e96]: 隐藏依赖-firefox-1790921002181-37
            - generic [ref=e97]: 仅合成测试
            - generic [ref=e98]: 0 位成员使用 · 0 项直接权限
          - button "Q36 测试身份 1790921046322" [ref=e99] [cursor=pointer]:
            - strong [ref=e100]: Q36 测试身份 1790921046322
            - generic [ref=e101]: 原说明
            - generic [ref=e102]: 0 位成员使用 · 0 项直接权限
          - button "隔离授权-webkit-1790921081124-30" [ref=e103] [cursor=pointer]:
            - strong [ref=e104]: 隔离授权-webkit-1790921081124-30
            - generic [ref=e105]: 仅合成测试
            - generic [ref=e106]: 0 位成员使用 · 1 项直接权限
          - button "隐藏依赖-webkit-1790921081124-37" [ref=e107] [cursor=pointer]:
            - strong [ref=e108]: 隐藏依赖-webkit-1790921081124-37
            - generic [ref=e109]: 仅合成测试
            - generic [ref=e110]: 0 位成员使用 · 0 项直接权限
          - button "Q36 测试身份 1790921115590" [ref=e111] [cursor=pointer]:
            - strong [ref=e112]: Q36 测试身份 1790921115590
            - generic [ref=e113]: 原说明
            - generic [ref=e114]: 0 位成员使用 · 0 项直接权限
          - button "隔离授权-chromium-1790921383079-30" [ref=e115] [cursor=pointer]:
            - strong [ref=e116]: 隔离授权-chromium-1790921383079-30
            - generic [ref=e117]: 仅合成测试
            - generic [ref=e118]: 0 位成员使用 · 1 项直接权限
          - generic [ref=e119]:
            - generic [ref=e120]: 共 25 项 · 第 1 页 / 共 2 页
            - button "上一页" [disabled] [ref=e121]
            - button "下一页" [ref=e122] [cursor=pointer]
          - paragraph [ref=e123]: 身份是可分配给成员的模板。同一个身份可供多位成员使用。
        - generic [ref=e124]: 请选择身份查看配置
```

# Test source

```ts
  16  | const fixture=JSON.parse(readFileSync(privateFixtures,'utf8')) as {admin:{account:string;password:string};user:{account:string;password:string};userId:string};
  17  | let identity:Definition,template:Definition,department:Department,rootDepartment:Department;
  18  | const stamp=Date.now();let presetCounter=0;const createdPresets:string[]=[];
  19  | async function login(context:BrowserContext,credentials=fixture.admin){const response=await context.request.post(base+'/api/v1/sessions',{headers:{Origin:base},data:credentials});expect(response.status(),'isolated prerequisite login').toBe(201);}
  20  | async function response(page:Page,path:string,method='GET',data?:object):Promise<APIResponse>{
  21  |  const cookie=(await page.context().cookies(base)).find(c=>c.name==='__Host-csrf');
  22  |  return page.request.fetch(base+'/api/v1/'+path,{method,headers:{Origin:base,...(cookie?{'X-CSRF-Token':cookie.value}:{})},...(data?{data}:{})});
  23  | }
  24  | async function api<T>(page:Page,path:string,method='GET',data?:object):Promise<T>{const res=await response(page,path,method,data);expect(res.ok(),'isolated '+method+' '+path.split('?')[0]+' status '+res.status()).toBe(true);if(res.status()===204)return undefined as T;const body=await res.json();expect(body.code).toBe('OK');return body.data as T;}
  25  | async function enter(page:Page){await login(page.context());page.on('dialog',dialog=>void dialog.accept());await page.goto('/app/admin');await expect(page.getByRole('tab',{name:'成员与部门',exact:true})).toBeVisible();await expect(page.locator('.member-table tbody tr[data-row-id]').first()).toBeVisible();}
  26  | async function shot(page:Page,name:string,filterOpen=false){
  27  |  await page.evaluate(()=>document.fonts.ready);
  28  |  // Base UI intentionally remains open while the native close animation runs.
  29  |  // Assert the requested screenshot state instead of treating its aria-expanded
  30  |  // flag as the user's intent during that interval.
  31  |  if(filterOpen){await expect(page.locator('.preset-popup')).toHaveAttribute('aria-hidden','false');await expect(page.locator('.q36-filter-content')).toBeVisible();}
  32  |  else await expect(page.getByRole('dialog',{name:'管理自定义筛选',exact:true})).toBeHidden();
  33  |  await page.evaluate(()=>new Promise<void>(done=>requestAnimationFrame(()=>requestAnimationFrame(()=>done()))));
  34  |  await page.waitForFunction(()=>!document.documentElement.classList.contains('q36-filter-transition-active'));
  35  |  await page.evaluate(()=>Promise.allSettled(document.getAnimations().map(animation=>animation.finished)));
  36  |  await page.screenshot({path:resolve(evidence,test.info().project.name+'-'+name+'.png'),fullPage:true});
  37  | }
  38  | async function newFilterEditor(page:Page){
  39  |  await page.getByRole('button',{name:'自定义筛选',exact:true}).click();const manager=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await manager.getByRole('button',{name:'新增筛选',exact:true}).click();const editor=page.getByRole('dialog',{name:'新增自定义筛选',exact:true});const name='Q36-'+test.info().project.name+'-'+stamp+'-'+(++presetCounter);await editor.getByLabel('自定义筛选名称',{exact:true}).fill(name);return {manager,editor,name};
  40  | }
  41  | async function saveApplyFilter(page:Page,entry:Awaited<ReturnType<typeof newFilterEditor>>){
  42  |  const saved=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname.endsWith('/table-presets'));await entry.editor.getByRole('button',{name:'确定',exact:true}).click();const body=await (await saved).json();createdPresets.push(body.data.id);await entry.manager.getByRole('button',{name:'应用'+entry.name,exact:true}).click();await expect(entry.manager.getByRole('button',{name:'关闭筛选管理',exact:true})).toBeEnabled();await entry.manager.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(entry.manager).toBeHidden();
  43  | }
  44  | async function cancelFilter(page:Page){
  45  |  await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();const manager=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await manager.getByRole('button',{name:'取消应用',exact:true}).click();await page.getByRole('dialog',{name:'取消当前筛选',exact:true}).getByRole('button',{name:'确认取消',exact:true}).click();await expect(manager.getByRole('button',{name:'关闭筛选管理',exact:true})).toBeEnabled();await manager.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(manager).toBeHidden();
  46  | }
  47  | test.afterEach(async({page})=>{for(const id of createdPresets.splice(0)){const stored=await api<{version:number}>(page,'personnel/table-presets/'+id);await api(page,'personnel/table-presets/'+id+'?version='+stored.version,'DELETE');}});
  48  | 
  49  | async function refresh(page:Page){await page.getByRole('button',{name:'刷新查询',exact:true}).first().click();await expect(page.locator('.member-table tbody tr[data-row-id]').first()).toBeVisible();}
  50  | async function saved(page:Page){await page.getByRole('button',{name:'保存草稿',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'草稿已保存'})).toBeVisible();}
  51  | async function closeSavedForm(page:Page){await page.getByRole('dialog').getByRole('button',{name:'关闭',exact:true}).click();const dirty=page.getByRole('dialog',{name:'有未保存的修改',exact:true});if(await dirty.isVisible())await dirty.getByRole('button',{name:'放弃修改',exact:true}).click();}
  52  | async function restoreKind(page:Page,kind:string){await page.getByRole('button',{name:'草稿箱',exact:true}).click();const row=page.getByRole('dialog',{name:'草稿箱',exact:true}).locator('.personnel-draft-item').filter({has:page.getByText(kind,{exact:true})});await row.getByRole('button',{name:'恢复草稿',exact:true}).first().click();}
  53  | 
  54  | test.beforeAll(async({browser})=>{
  55  |  const context=await browser.newContext({ignoreHTTPSErrors:true});await login(context);const page=await context.newPage();
  56  |  // This private synthetic account is reused when the cloud matrix is rerun.
  57  |  // Establish the suite's empty draft precondition before its serial lifecycle;
  58  |  // preserve all five kinds throughout the subsequent fresh-login assertions.
  59  |  const priorDrafts=await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts');
  60  |  for(const item of priorDrafts.items)await api(page,'personnel/drafts/'+item.id+'?version='+item.version,'DELETE');
  61  |  const query=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});
  62  |  rootDepartment=(await api<{items:Department[]}>(page,'personnel/departments')).items.find(d=>d.isRoot)!;
  63  |  identity=await api<Definition>(page,'personnel/identities','POST',{name:'Q36 测试身份 '+stamp,description:'原说明',templateIds:[],permissionCodes:[]});
  64  |  template=await api<Definition>(page,'personnel/templates','POST',{name:'Q36 测试模板 '+stamp,description:'原模板说明',permissionCodes:[]});
  65  |  department=await api<Department>(page,'personnel/departments','POST',{name:'Q36 测试部门 '+stamp,parentId:rootDepartment.id,queryVersion:query.queryVersion});
  66  |  // Populate two real pages with synthetic registrations via supported APIs.
  67  |  for(let i=0;i<24;i++){
  68  |   const invite=await api<{invitationCode:string}>(page,'invitations','POST',{});
  69  |   const res=await page.request.post(base+'/api/v1/registrations',{headers:{Origin:base},data:{account:'q36-'+stamp+'-'+String(i).padStart(2,'0'),password:'Synthetic@Test123',invitationCode:invite.invitationCode}});
  70  |   expect(res.status(),'isolated synthetic registration').toBe(201);
  71  |  }
  72  |  await context.close();
  73  | });
  74  | 
  75  | test('Q36 actual members: complete filtering, arbitrary pages, selection, column preservation and screenshots',async({page})=>{
  76  |  await enter(page);await page.setViewportSize({width:1440,height:1000});await shot(page,'members-default-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'members-default-narrow');await page.setViewportSize({width:1440,height:1000});
  77  |  await expect(page.locator('.member-table th[aria-sort]')).toHaveCount(0);
  78  |  const selected=page.getByLabel('选择成员：'+fixture.admin.account,{exact:true});await selected.check();
  79  |  const resize=page.getByRole('button',{name:'Resize account column',exact:true});const box=(await resize.boundingBox())!;await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2+50,box.y+box.height/2,{steps:8});await page.mouse.up();
  80  |  const before=(await page.locator('.member-table th').nth(1).boundingBox())!.width;
  81  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('button',{name:'Page 2',exact:true})).toHaveAttribute('aria-current','page');
  82  |  const entry=await newFilterEditor(page),panel=entry.editor;
  83  |  await panel.getByRole('button',{name:'或条件',exact:true}).click();await panel.getByLabel('条件 1.1 值',{exact:true}).fill(fixture.admin.account);await shot(page,'members-filter-expanded-desktop',true);
  84  |  await saveApplyFilter(page,entry);await expect(page.locator('.member-table tbody tr[data-row-id]')).toHaveCount(1);await shot(page,'members-filter-applied-desktop');
  85  |  await refresh(page);await expect(selected).not.toBeChecked();expect((await page.locator('.member-table th').nth(1).boundingBox())!.width).toBeCloseTo(before,0);await expect(page.getByRole('button',{name:'自定义筛选，已应用',exact:true})).toBeVisible();
  86  |  await page.setViewportSize({width:390,height:844});await shot(page,'members-filter-applied-narrow');await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();await shot(page,'members-filter-expanded-narrow',true);await page.keyboard.press('Escape');
  87  |  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  88  | });
  89  | 
  90  | test('Q36 actual events: backend safe display, absolute range, full-result time ordering and screenshots',async({page})=>{
  91  |  await enter(page);await page.setViewportSize({width:1440,height:1000});await page.getByRole('tab',{name:'操作记录',exact:true}).click();await expect(page.locator('.activity-table tbody tr[data-row-id]').first()).toBeVisible();await shot(page,'events-default-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'events-default-narrow');await page.setViewportSize({width:1440,height:1000});
  92  |  await page.getByRole('button',{name:'排序 occurredAt',exact:true}).click();await page.getByRole('menuitem',{name:'升序',exact:true}).click();await expect(page.locator('.activity-table th[aria-sort]')).toHaveAttribute('aria-sort','ascending');
  93  |  const entry=await newFilterEditor(page),panel=entry.editor;await panel.getByRole('button',{name:'或条件',exact:true}).click();await panel.getByLabel('条件 1.1 值',{exact:true}).fill(fixture.admin.account);await shot(page,'events-filter-expanded-desktop',true);await saveApplyFilter(page,entry);await shot(page,'events-filter-applied-desktop');
  94  |  const result=await api<{items:{occurredAt:string;display:{object:string;detail:string}}[];range:{from:string;to:string}}>(page,'personnel/events/search','POST',{page:1,pageSize:100,sortBy:'occurredAt',sortDirection:'asc',filter:{operator:'and',children:[{field:'actorAccount',operator:'eq',value:fixture.admin.account}]}});
  95  |  expect(result.items.length).toBeGreaterThan(0);expect(result.items.every((event,i,all)=>i===0||Date.parse(all[i-1].occurredAt)<=Date.parse(event.occurredAt))).toBe(true);expect(result.items.every(event=>typeof event.display.detail==='string'&&typeof event.display.object==='string')).toBe(true);expect(Date.parse(result.range.to)).toBeGreaterThan(Date.parse(result.range.from));
  96  |  await page.setViewportSize({width:390,height:844});await shot(page,'events-filter-applied-narrow');await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();await shot(page,'events-filter-expanded-narrow',true);await page.keyboard.press('Escape');expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  97  | });
  98  | 
  99  | test('Q36 actual precision: unrelated option change proceeds; related member change explicitly refreshes',async({page})=>{
  100 |  await enter(page);let currentVersion='';page.on('response',async res=>{if(res.url().endsWith('/personnel/members/search')&&res.ok()){try{currentVersion=(await res.json()).data.queryVersion;}catch{/* An obsolete response aborted by refresh has no readable body. */}}});await refresh(page);await expect.poll(()=>currentVersion.length).toBeGreaterThan(0);
  101 |  await api(page,'personnel/templates','POST',{name:'Q36 无关模板 '+stamp,description:'不影响当前成员结果',permissionCodes:[]});
  102 |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('button',{name:'Page 2',exact:true})).toHaveAttribute('aria-current','page');await expect(page.getByText('查询结果已变化，请刷新查询后继续',{exact:true})).toHaveCount(0);
  103 |  const target=await api<Member>(page,'personnel/members/'+fixture.userId);await api(page,'personnel/members/'+target.id+'/identities','PUT',{version:target.version,identityIds:[identity.id],queryVersion:currentVersion});
  104 |  await page.getByLabel('跳至页',{exact:true}).fill('1');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('alert')).toContainText('查询结果已变化');await shot(page,'members-refresh-required-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'members-refresh-required-narrow');await refresh(page);await expect(page.getByRole('button',{name:'Page 1',exact:true})).toHaveAttribute('aria-current','page');
  105 | });
  106 | 
  107 | test('Q36 actual context LRU expiry is distinct from changed results',async({page})=>{
  108 |  await enter(page);for(let i=0;i<21;i++)await api(page,'personnel/members/search','POST',{page:1,pageSize:20,search:'unmatched-context-'+i});
  109 |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');await expect(page.getByRole('alert')).toContainText('查询上下文已过期');await shot(page,'members-context-expired');await refresh(page);
  110 | });
  111 | 
  112 | test('Q36 actual five draft kinds persist after fresh login; member/department inputs survive query refresh',async({page,browser})=>{
  113 |  await enter(page);await page.getByRole('button',{name:'配置身份',exact:true}).first().click();await page.getByLabel('身份：'+identity.name,{exact:true}).check();await saved(page);await shot(page,'draft-member-identities-saved');await closeSavedForm(page);
  114 |  await page.getByRole('button',{name:'调整分组',exact:true}).first().click();await saved(page);await shot(page,'draft-member-groups-saved');await closeSavedForm(page);
  115 |  await page.getByRole('button',{name:'新建部门',exact:true}).click();await page.getByLabel('部门名称',{exact:true}).fill('Q36 未提交部门');await saved(page);await shot(page,'draft-department-saved');await closeSavedForm(page);
> 116 |  await page.getByRole('tab',{name:'身份',exact:true}).click();await page.getByRole('button',{name:identity.name,exact:true}).click();await page.getByLabel('说明',{exact:true}).fill('Q36 已保存身份输入');await saved(page);await shot(page,'draft-identity-saved');await page.getByRole('tab',{name:'权限模板',exact:true}).click();await page.getByRole('dialog',{name:'有未保存的修改',exact:true}).getByRole('button',{name:'放弃修改',exact:true}).click();
      |                                                                                                                            ^ Error: locator.click: Test timeout of 120000ms exceeded.
  117 |  await page.getByRole('button',{name:template.name,exact:true}).click();await page.getByLabel('说明',{exact:true}).fill('Q36 已保存模板输入');await saved(page);await shot(page,'draft-template-saved');
  118 |  const stored=await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts');expect(new Set(stored.items.map(d=>d.kind))).toEqual(new Set(['member-identities','member-groups','department','identity','template']));
  119 |  const context=await browser.newContext({ignoreHTTPSErrors:true});const other=await context.newPage();await enter(other);await restoreKind(other,'部门');await expect(other.getByLabel('部门名称',{exact:true})).toHaveValue('Q36 未提交部门');await shot(other,'draft-department-restored-desktop');await other.setViewportSize({width:390,height:844});await shot(other,'draft-department-restored-narrow');
  120 |  await other.getByRole('dialog').getByRole('button',{name:'刷新查询',exact:true}).click();await expect(other.getByLabel('部门名称',{exact:true})).toHaveValue('Q36 未提交部门');await context.close();
  121 | });
  122 | 
  123 | test('Q36 actual restoration compares latest target, preserves original base, and requires explicit resolution',async({page})=>{
  124 |  await enter(page);identity=await api<Definition>(page,'personnel/identities/'+identity.id,'PUT',{name:identity.name,description:'另一标签已提交最新说明',templateIds:[],permissionCodes:[],version:identity.version});
  125 |  await restoreKind(page,'身份');await expect(page.getByLabel('说明',{exact:true})).toHaveValue('Q36 已保存身份输入');await expect(page.getByRole('alert')).toContainText('原版本 1');await expect(page.getByRole('alert')).toContainText('最新版本 2');await expect(page.getByRole('button',{name:'保存',exact:true})).toBeDisabled();await shot(page,'draft-target-conflict-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'draft-target-conflict-narrow');
  126 |  const list=await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts');const item=list.items.find(d=>d.kind==='identity'&&d.targetId===identity.id)!;const stored=await api<PersonnelDraft>(page,'personnel/drafts/'+item.id);expect(stored.baseVersion).toBe(1);
  127 |  await page.getByRole('button',{name:'保留当前输入，使用最新对象版本',exact:true}).click();await expect(page.getByLabel('说明',{exact:true})).toHaveValue('Q36 已保存身份输入');await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByRole('button',{name:'确认保存',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'已保存'})).toBeVisible();
  128 |  expect((await response(page,'personnel/drafts/'+item.id)).status()).toBe(404);const latest=await api<Definition>(page,'personnel/identities/'+identity.id);expect(latest.description).toBe('Q36 已保存身份输入');identity=latest;
  129 | });
  130 | 
  131 | test('Q36 actual draft CAS conflict preserves input; business success keeps a newer draft version',async({page})=>{
  132 |  await enter(page);await restoreKind(page,'权限模板');const items=(await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts')).items;const original=await api<PersonnelDraft>(page,'personnel/drafts/'+items.find(d=>d.kind==='template')!.id);
  133 |  if(original.kind!=='template')throw Error('wrong isolated fixture kind');
  134 |  await api(page,'personnel/drafts/'+original.id,'PUT',{version:original.version,payload:{...original.payload,description:'其他标签草稿输入'}});
  135 |  await page.getByLabel('说明',{exact:true}).fill('本标签未保存输入');await page.getByRole('button',{name:'保存草稿',exact:true}).click();await expect(page.getByRole('alert')).toContainText('草稿已由其他标签页修改');await expect(page.getByLabel('说明',{exact:true})).toHaveValue('本标签未保存输入');await shot(page,'draft-cas-conflict-desktop');await page.setViewportSize({width:390,height:844});await shot(page,'draft-cas-conflict-narrow');
  136 |  await page.getByRole('button',{name:'保留当前输入，采用最新草稿版本',exact:true}).click();await saved(page);
  137 |  const adopted=await api<PersonnelDraft>(page,'personnel/drafts/'+original.id);expect(adopted.version).toBe(original.version+2);expect(adopted.baseVersion).toBe(original.baseVersion);
  138 |  if(adopted.kind!=='template')throw Error('wrong isolated fixture kind');const newer=await api<PersonnelDraft>(page,'personnel/drafts/'+original.id,'PUT',{version:adopted.version,payload:{...adopted.payload,description:'必须保留的新草稿'}});
  139 |  await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByRole('button',{name:'确认保存',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'已保存'})).toBeVisible();const preserved=await api<PersonnelDraft>(page,'personnel/drafts/'+original.id);expect(preserved.version).toBe(newer.version);expect(preserved.payload).toMatchObject({description:'必须保留的新草稿'});
  140 | });
  141 | 
  142 | test('Q36 actual drafts remain isolated between two currently authorized accounts',async({page,browser})=>{
  143 |  await enter(page);const foreign=(await api<{items:PersonnelDraftSummary[]}>(page,'personnel/drafts')).items[0];expect(foreign).toBeTruthy();
  144 |  const target=await api<Member>(page,'personnel/members/'+fixture.userId);
  145 |  const grant=await api<Definition>(page,'personnel/identities','POST',{name:'Q36 隔离验证授权 '+stamp,description:'仅测试账号',templateIds:[],permissionCodes:['personnel.manage']});
  146 |  const query=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});
  147 |  const granted=await api<Member>(page,'personnel/members/'+target.id+'/identities','PUT',{identityIds:[...target.identityIds,grant.id],version:target.version,queryVersion:query.queryVersion});
  148 |  const context=await browser.newContext({ignoreHTTPSErrors:true});
  149 |  try{
  150 |   await login(context,fixture.user);const other=await context.newPage();await other.goto('/app/admin');await expect(other.getByRole('button',{name:'草稿箱',exact:true})).toBeVisible();
  151 |   const own=(await api<{items:PersonnelDraftSummary[]}>(other,'personnel/drafts')).items;expect(own.some(d=>d.id===foreign.id)).toBe(false);
  152 |   for(const method of ['GET','PUT','DELETE']){
  153 |    const denied=await response(other,'personnel/drafts/'+foreign.id+(method==='DELETE'?'?version='+foreign.version:''),method,method==='PUT'?{version:foreign.version,payload:{name:'禁止跨账户覆盖',parentId:null}}:undefined);
  154 |    expect(denied.status(),'foreign draft '+method).toBe(404);
  155 |   }
  156 |   await other.getByRole('tab',{name:'权限模板',exact:true}).click();await other.getByRole('button',{name:'新建权限模板',exact:true}).click();await other.getByLabel('模板名称',{exact:true}).fill('Q36 本账号草稿');await saved(other);
  157 |   await other.getByRole('button',{name:'草稿箱',exact:true}).click();await other.getByRole('dialog',{name:'有未保存的修改',exact:true}).getByRole('button',{name:'放弃修改',exact:true}).click();
  158 |   await expect(other.getByRole('dialog',{name:'草稿箱',exact:true}).locator('.personnel-draft-item')).toHaveCount(own.length+1);await shot(other,'draft-account-isolation');
  159 |   const unchanged=await api<PersonnelDraft>(page,'personnel/drafts/'+foreign.id);expect(unchanged.version).toBe(foreign.version);
  160 |  }finally{
  161 |   await context.close();const latest=await api<Member>(page,'personnel/members/'+granted.id);const current=await api<MembersQueryPage<Member>>(page,'personnel/members/search','POST',{page:1,pageSize:20});
  162 |   await api(page,'personnel/members/'+latest.id+'/identities','PUT',{identityIds:target.identityIds,version:latest.version,queryVersion:current.queryVersion});
  163 |  }
  164 | });
  165 | 
  166 | test('Q36 actual narrow finite AND OR groups validate twenty leaves and keep footer reachable',async({page})=>{
  167 |  await enter(page);await page.setViewportSize({width:1440,height:1000});const entry=await newFilterEditor(page),panel=entry.editor;
  168 |  await panel.getByRole('button',{name:'或条件',exact:true}).click();await panel.getByLabel('条件 1.1 字段',{exact:true}).selectOption('identityIds');await panel.getByRole('button',{name:'确定',exact:true}).click();await expect(panel.getByRole('alert')).toContainText('条件 1.1');await shot(page,'filter-invalid-desktop',true);
  169 |  await panel.getByLabel('条件 1.1 字段',{exact:true}).selectOption('account');await panel.getByLabel('条件 1.1 值',{exact:true}).fill(fixture.admin.account);
  170 |  for(let i=2;i<=20;i++){await panel.getByRole('button',{name:'组 1 且条件',exact:true}).click();await panel.getByLabel('条件 1.'+i+' 值',{exact:true}).fill(fixture.admin.account);}
  171 |  await expect(panel.getByRole('button',{name:'或条件',exact:true})).toBeDisabled();await expect(panel.getByRole('button',{name:'确定',exact:true})).toBeEnabled();await shot(page,'filter-long-groups-desktop',true);
  172 |  await page.setViewportSize({width:390,height:844});await shot(page,'filter-long-groups-narrow',true);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  173 |  const footer=(await panel.getByRole('button',{name:'确定',exact:true}).boundingBox())!;expect(footer.y+footer.height).toBeLessThanOrEqual(844);
  174 |  await saveApplyFilter(page,entry);await expect(page.locator('.member-table tbody tr[data-row-id]')).toHaveCount(1);
  175 |  await page.getByLabel('搜索成员',{exact:true}).fill('q36-no-match-'+stamp);await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');await expect(page.locator('.member-table')).toContainText('暂无成员');await shot(page,'members-empty-narrow');
  176 | });
  177 | 
  178 | test('Q36 actual page records open close stable trigger and reopen without a root blocker',async({browser})=>{
  179 |  const context=await browser.newContext({ignoreHTTPSErrors:true,viewport:{width:1440,height:1000},recordVideo:{dir:evidence,size:{width:1440,height:1000}}});
  180 |  await login(context);const page=await context.newPage();await page.goto('/app/admin');await expect(page.locator('.member-table table')).toHaveAttribute('aria-busy','false');await page.evaluate(()=>document.fonts.ready);
  181 |  const trigger=page.getByRole('button',{name:'自定义筛选',exact:true}),panel=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await page.waitForTimeout(1000);
  182 |  await trigger.click();await expect(panel).toBeVisible();await shot(page,'motion-open',true);await page.waitForTimeout(1000);
  183 |  await page.keyboard.press('Escape');await expect(panel).toBeHidden();await page.waitForFunction(()=>!document.documentElement.classList.contains('q36-filter-transition-active'));await page.waitForTimeout(1100);await shot(page,'motion-closed-stable');await expect(trigger.locator('svg')).toBeVisible();await expect(trigger).toContainText('自定义筛选');
  184 |  await trigger.click();await expect(panel).toBeVisible();await shot(page,'motion-reopened',true);await page.waitForTimeout(1000);await page.keyboard.press('Escape');await expect(panel).toBeHidden();await page.waitForTimeout(1100);await shot(page,'motion-final-stable');
  185 |  const video=page.video();await context.close();if(!video)throw Error('actual page video unavailable');await rename(await video.path(),resolve(evidence,test.info().project.name+'-actual-filter-open-close-reopen.webm'));
  186 | });
  187 | 
  188 | test('Q36 actual custom filtering clears current-page selection without resurrecting hidden members',async({page})=>{
  189 |  await enter(page);await page.setViewportSize({width:1440,height:1000});
  190 |  const hidden=page.getByLabel('选择成员：'+fixture.user.account,{exact:true});await hidden.check();await shot(page,'members-selection-before-filter');
  191 |  const entry=await newFilterEditor(page),panel=entry.editor;
  192 |  await panel.getByRole('button',{name:'或条件',exact:true}).click();await panel.getByLabel('条件 1.1 值',{exact:true}).fill(fixture.admin.account);await saveApplyFilter(page,entry);
  193 |  await expect(hidden).toHaveCount(0);await page.getByLabel('选择当前页成员',{exact:true}).check();await expect(page.getByLabel('选择成员：'+fixture.admin.account,{exact:true})).toBeChecked();await shot(page,'members-selection-filtered-current-page');
  194 |  await cancelFilter(page);
  195 |  await expect(hidden).not.toBeChecked();await expect(page.getByLabel('选择成员：'+fixture.admin.account,{exact:true})).not.toBeChecked();await expect(page.getByLabel('选择当前页成员',{exact:true})).not.toBeChecked();await shot(page,'members-selection-reset-cleared');
  196 | });
  197 | 
```