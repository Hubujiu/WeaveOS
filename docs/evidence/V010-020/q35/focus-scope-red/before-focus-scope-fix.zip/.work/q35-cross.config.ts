import { defineConfig, devices } from '@playwright/test';
import base from './q35.config';
export default defineConfig({ ...base, timeout: 30000, expect: { timeout: 5000 }, outputDir: 'q35-cross-results',
  use: { baseURL: 'http://127.0.0.1:4175' },
  webServer: { ...base.webServer as object, command: 'pnpm exec vite --host 127.0.0.1 --port 4175 --strictPort', url: 'http://127.0.0.1:4175' },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }, { name: 'firefox', use: { ...devices['Desktop Firefox'] } }, { name: 'webkit', use: { ...devices['Desktop Safari'] } }],
});
