import { defineConfig } from '@playwright/test';
import base from './q35-cross.config';
export default defineConfig({ ...base, outputDir: 'q35-font-results', use: { baseURL: 'http://127.0.0.1:4176' },
webServer: { ...base.webServer as object, command: 'pnpm exec vite --host 127.0.0.1 --port 4176 --strictPort', url: 'http://127.0.0.1:4176' } });
