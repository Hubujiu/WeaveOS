import { defineConfig } from '@playwright/test';
import base from './q29.config';
export default defineConfig({ ...base, timeout: 15000, expect: { timeout: 1500 }, outputDir: 'q35-results' });
