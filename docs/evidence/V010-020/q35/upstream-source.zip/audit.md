# Q35 fixed original Data Table source audit

Read-only source audit by /root/arca_table_source, 2026-10-01 Asia/Shanghai. No WeaveOS code/lock/config, Notion, Figma or upstream edits. Only public research artifacts were written under this directory. Main agent owns source synchronization and RED-first implementation.

Upstream: https://github.com/Hubujiu/arca-ui @ c0319d887e10775c8968a7d6a451f248858726ec. Master was rechecked and matches. Official public page https://hubujiu.github.io/arca-ui/#/components/data-table was actually opened via isolated Playwright CLI session arca-q35-source; session was closed after screenshots/readback. The prior Q34 browser was separate and closed. No private data was browsed.

## Concrete minimum direct consumption

Use the 22 original TS/TSX source files captured byte-for-byte in dependencies/src, preserving the original Table, Checkbox, TableScrollbar, TablePagination, Select, DropdownPanel, Button and Motion logic. dependencies/dependency-manifest.json records paths, SHA256 and imports; dependencies/README.md explains build and CSS isolation. Do not recreate these components with lookalike JSX/CSS. Mechanical alias rewrites to a self-contained local vendor subtree are reviewable; preserve original source snapshots and a patch list.

Exact fixed npm direct versions: @base-ui/react1.8.0, @phosphor-icons/react2.1.10, @tanstack/react-virtual3.14.13, class-variance-authority0.7.1, cn0.3.0, lucide-react1.47.0, motion13.4.0. CSS build: tailwindcss/@tailwindcss/vite4.3.3. Official font: @fontsource-variable/geist5.3.0. React/DOM19.3.0 matches WeaveOS. No full shadcn CLI or tw-animate-css graph is necessary for these 22 files. Base UI remains required by the original pagination Button.

Add package/lock/Vite paths to task ownership before editing. Do not change external source repository or approval status. The upstream README has no license and GitHub license=null; no particular license is inferred.

## Fill viewport: an explicit user extension, not an upstream feature

The original Table has no fillEmptyRows/fillViewport prop. types.ts accepts height:number, rowHeight:number. index.tsx uses paginated ? maxHeight:height, meaning paginated tables shrink with few data. Browser evidence: default 10 rows gave viewport360/root395/footer33; last page7 rows gave viewport321/root356/footer33, while maxHeight remained360. Original empty state is a p-10 colspan cell, not blank-row filling. Original virtualizer spacer rows exist only for real row virtualization.

The newly requested fillViewport must therefore be a documented optional local extension to the original source: measure the space left by the page/toolbar/footer and keep that viewport height; add noninteractive visual blank cells/rows to fill the remainder. Preserve visible original empty-state text, real data and its IDs. Placeholder rows must be aria-hidden, have no selectable identity/callback, and must not affect real selection, recordCount, page count, filtering or backend requests. Do not fake rows in the data prop or virtualizer data. Separate fixed visual occupancy from loading skeleton rows.

## Server pagination: original rendering plus a thin bridge

The original Table assumes all records are local: recordCount=sortedRows.length and paginated slices currentPage*pageSize. Feeding one server page with the server page index would double-slice it and miscount total. Preserve original TablePagination/Select/Button rendering while adding a reviewed manual/server-pagination bridge: derive pageCount from server total and skip local slice for already paged rows. Keep rowStart tied to server index, stable getRowId, current real-page selection, and pageIndex0-based only at the visual component boundary. Existing backend behavior/permissions and source-confirmed page size decisions remain the main agent's responsibility. Do not fetch all members merely to emulate the demo.

## Original effect parameters

- Table: table-layout:fixed, border-collapse:collapse, full width; white background,1px border oklch(.922 0 0), rounded-xl actually14px; font Geist14/20. Header40px (collapsed border measured40.5), sticky top0,z10, gray background. Default demo header and title computed textAlign=center. Non-sortable source branch aligns via alignFlex (default left); any chosen header alignment is an explicit consumer setting/adaptation.
- Row:40px; cell padding16px horizontally, truncate single-line; row bottom border oklab(.922 0 0/.6), cell divider1px. Hover color-mix(in oklab,muted50%,transparent); selected color-mix(in oklab,primary5%,transparent), composited over white. Colors transition150ms cubic-bezier(.4,0,.2,1).
- Selection: leading48px column. Number12px disappears on group hover/focus-within/selected and original button checkbox appears. Checkbox20x20,radius8,border2; unchecked border oklab(.556 0 0/.5),white background, hover solid. Checked/mixed bg and border primary=.205; mark primary-foreground=.985. Press scale.92 with spring stiffness500/damping30/mass.6. Original12px SVG stroke3; mark entrance opacity0/scale.5 ->1 in160ms; exit opacity0/scale.5/blur4px. Check path draws300ms, mixed200ms,both delay40ms,EASE_OUT(.16,1,.3,1). Reduced motion suppresses these physical/mark animations.
- Scrollbar: original TableScrollbar TSX hides native bars, ResizeObserver recomputes both axes.6px tracks,2px edges; vertical starts header+2px. Thumb minimum20px,radius8,rgb144/147/153 opacity.3,hover/drag.5. Track fade340ms ease-out,thumb color300ms/opacity340ms. Show on hover,scroll or drag; hide800ms after last scroll. Includes real track jump and pointer drag. Keep original cleanup and pointer handlers.
- Pager: footer33px at1280 wide,padding4x12,gap8,font12/16. Original page buttons24x24,radius8,fontweight500; selected outline1px white; others ghost; disabled opacity.5; focus-visible border-ring and3px ring-ring/50; active non-popup translate-y1px. First/last/current window with clickable ellipses remains original algorithm.
- Page-size Select: actual trigger64x24,padding8,12/16,radius12 despite rounded-md class because original Motion sets inline radii. Prefers top. Official5 options produced64x128 panel,54x24 item,8px gap,radius12,white/shadow-lg. Options selected muted. DropdownChevron spring duration.4,bounce.3,rotate180. List stagger35ms/delay50ms; items opacity0,y-6,blur3 ->opacity1/y0/blur0. Panel opening height spring.42,bounce.14; gap spring.6,bounce.5,delay.12; adjacent corners300ms,delay.14; close height260ms+delay140, gap spring.3/bounce.1,opacity160ms+delay120. Trigger corner keyframes open[0,0,12]600ms/close[12,0,12]420ms. Preserve original reduced-motion branch rather than approximating it.
- Optional original menus/resizing/reordering/editing remain in the compile source; only enable modes authorized by actual business sources. Source glyphs are original Phosphor/Lucide, not replacement SVG art.

## Current Q34 adaptation differences

PersonnelTable.tsx is authored local markup, not the original Table; it renders all rows without the original virtualizer. Native input checkbox plus static SVG misses press/draw/exit effects. Native scrollbar differs from the original custom hover/drag/track behavior. Current48px footer with only prev/next text differs from original33px pager/number window/ellipsis/page-size selector/Button focus and press effects. border-collapse:separate differs from original collapse. Project Noto Sans SC differs from official Geist. Existing wrapper maxHeight360 also shrinks with few rows and leaves unpainted flex space. Identity was converted to a table in Q34 and now must return to the permission-template-style list under the user's explicit new scope.

## Required CSS isolation

The unchanged WeaveOS workspace CSS contains unlayered .workspace button font:inherit and blue focus outline; .workspace table min-width920/text-align:left; .workspace th height44/font12; .workspace td height64/line22; .activity-table td height68; and nth-column widths. These can override Tailwind's layered utility classes even with original JSX. Exclude Arca from the legacy rules or deliberately isolate the generated original utilities/reset, instead of once again manually writing imitation component style rules. Official preflight/body/html/base globals must not globally restyle the existing app. Theme/font/reset/utility scope must include original document.body portals as well as table descendants.

## Artifacts and limits

- dependencies/:22 raw source files, upstream configs/package locks,imports/hashes/integrities and dependency report.
- core/:fixed source files specifically read for behavior comparison, normalized LF SHA256 listed in the tool record.
- official-default-computed.txt / official-default.png:full browser CSS/geometry readback including computed centered header and pager.
- official-last-page.txt / official-last-page.png:last page shrink demonstrated with real official data.
- official-page-size-open.txt / official-page-size-open.png:actual top-opening Select geometry/shadow.
- .playwright-cli/:public snapshots from the isolated session.

No integration code, dependency installation, implementation tests or build was performed by this research agent. The source effects and fixed versions are measured/read facts; the two bridge extensions are implementation recommendations requiring the main agent's source/RED gate.
