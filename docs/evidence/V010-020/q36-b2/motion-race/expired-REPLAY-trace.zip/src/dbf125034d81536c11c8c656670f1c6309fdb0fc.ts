import {test,expect} from '@playwright/test';

test('Q36 supported browser uses React native shared ViewTransition for open and close',async({page})=>{
  await page.addInitScript(()=>{
    const native = document.startViewTransition?.bind(document);
    const state={count:0};
    Object.defineProperty(window,'__q36NativeViewTransitions',{value:state});
    if(native)document.startViewTransition = ((...args:Parameters<Document['startViewTransition']>)=>{
      state.count++;
      return native(...args);
    }) as Document['startViewTransition'];
  });
  await page.goto('/src/q36-front-fixture.html');
  test.skip(!await page.evaluate(()=>typeof document.startViewTransition==='function'&&navigator.vendor!=='Apple Computer, Inc.'),'native shared transition unavailable or unsafe in this engine');
  await page.getByRole('button',{name:/自定义筛选/}).click();
  await expect(page.getByRole('dialog',{name:'自定义筛选'})).toBeVisible();
  await expect.poll(()=>page.evaluate(()=>(window as unknown as {__q36NativeViewTransitions:{count:number}}).__q36NativeViewTransitions.count)).toBeGreaterThanOrEqual(1);
  await page.getByRole('dialog',{name:'自定义筛选'}).getByRole('button',{name:'关闭筛选'}).click();
  await expect(page.getByRole('dialog',{name:'自定义筛选'})).not.toBeVisible();
  await expect.poll(()=>page.evaluate(()=>(window as unknown as {__q36NativeViewTransitions:{count:number}}).__q36NativeViewTransitions.count)).toBeGreaterThanOrEqual(2);
});

test('Q36 unsupported native transition uses popup motion and restores trigger focus',async({page})=>{
  await page.addInitScript(()=>{
    Object.defineProperty(document,'startViewTransition',{value:undefined,configurable:true});
    const native=Element.prototype.animate;
    const state={count:0};
    Object.defineProperty(window,'__q36FallbackAnimations',{value:state});
    Element.prototype.animate=function(...args){state.count++;return native.apply(this,args);};
  });
  await page.goto('/src/q36-front-fixture.html');
  const trigger=page.getByRole('button',{name:/自定义筛选/});
  await trigger.click();
  const dialog=page.getByRole('dialog',{name:'自定义筛选'});
  await expect(dialog).toBeVisible();
  await expect.poll(()=>page.evaluate(()=>(window as unknown as {__q36FallbackAnimations:{count:number}}).__q36FallbackAnimations.count)).toBeGreaterThan(0);
  await page.keyboard.press('Escape');
  await expect(dialog).not.toBeVisible();
  await expect(trigger).toBeFocused();
});

test('Q36 quick native reversal preserves last close intent and trigger focus',async({page})=>{
  await page.goto('/src/q36-front-fixture.html');
  test.skip(!await page.evaluate(()=>typeof document.startViewTransition==='function'&&navigator.vendor!=='Apple Computer, Inc.'),'native shared transition unavailable or unsafe in this engine');
  const trigger=page.getByRole('button',{name:/自定义筛选/});
  await trigger.click();
  await expect(page.getByRole('dialog',{name:'自定义筛选'})).toBeVisible();
  await page.keyboard.press('Escape');
  await trigger.click();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog',{name:'自定义筛选'})).not.toBeVisible();
  await expect(trigger).toBeFocused();
  await expect.poll(()=>page.evaluate(()=>document.documentElement.classList.contains('q36-filter-transition-active'))).toBe(false);
});

for(const hold of [0,650] as const)test(`Q36 delayed native opening commit ${hold?'after fallback expiry ':' '}cannot undo a later trusted Escape close`,async({page})=>{
  await page.addInitScript(()=>{
    const native=document.startViewTransition?.bind(document);
    let release!:()=>void;
    const gate=new Promise<void>(resolve=>{release=resolve;});
    const state={waiting:false,release,escapes:0};
    Object.defineProperty(window,'__q36DelayedNativeCommit',{value:state});
    document.addEventListener('keydown',event=>{if(event.isTrusted&&event.key==='Escape')state.escapes++;},true);
    if(native)document.startViewTransition=((input:Parameters<Document['startViewTransition']>[0])=>{
      const update=typeof input==='function'?input:input?.update;
      const delayed=async()=>{state.waiting=true;await gate;await update?.();};
      return native(typeof input==='function'?delayed:{...input,update:delayed});
    }) as Document['startViewTransition'];
  });
  await page.goto('/src/q36-front-fixture.html');
  test.skip(!await page.evaluate(()=>typeof document.startViewTransition==='function'&&navigator.vendor!=='Apple Computer, Inc.'),'native shared transition unavailable or unsafe in this engine');
  const trigger=page.getByRole('button',{name:/自定义筛选/});
  await trigger.click();
  await expect.poll(()=>page.evaluate(()=>(window as unknown as {__q36DelayedNativeCommit:{waiting:boolean}}).__q36DelayedNativeCommit.waiting)).toBe(true);
  if(hold)await page.waitForTimeout(hold); // Exercise the existing 600ms completion fallback.
  await page.keyboard.press('Escape');
  expect(await page.evaluate(()=>(window as unknown as {__q36DelayedNativeCommit:{escapes:number}}).__q36DelayedNativeCommit.escapes)).toBe(1);
  await page.evaluate(()=>(window as unknown as {__q36DelayedNativeCommit:{release:()=>void}}).__q36DelayedNativeCommit.release());
  await expect(page.getByRole('dialog',{name:'自定义筛选'})).not.toBeVisible();
  await expect(trigger).toBeFocused();
  await expect.poll(()=>page.evaluate(()=>document.documentElement.classList.contains('q36-filter-transition-active'))).toBe(false);
  await expect(trigger).toHaveAttribute('aria-expanded','false');
  await expect(page.locator('.q36-filter-popup')).toHaveAttribute('aria-hidden','true');
});

test('Q36 WebKit edits nested groups through the safe animated fallback',async({page,browserName})=>{
  test.skip(browserName!=='webkit','WebKit crash regression');
  await page.addInitScript(()=>{
    const native=document.startViewTransition?.bind(document);
    const animate=Element.prototype.animate;
    const state={native:0,fallback:0};
    Object.defineProperty(window,'__q36WebKitMotion',{value:state});
    if(native)document.startViewTransition=((...args:Parameters<Document['startViewTransition']>)=>{
      state.native++;return native(...args);
    }) as Document['startViewTransition'];
    Element.prototype.animate=function(...args){state.fallback++;return animate.apply(this,args);};
  });
  await page.goto('/src/q36-front-fixture.html');
  await page.getByRole('button',{name:/自定义筛选/}).click();
  await expect.poll(()=>page.evaluate(()=>(window as unknown as {__q36WebKitMotion:{fallback:number}}).__q36WebKitMotion.fallback)).toBeGreaterThan(0);
  await page.locator('.q36-filter-group-actions button').nth(1).click();
  await expect(page.locator('.q36-filter-group')).toHaveCount(2);
  expect(await page.evaluate(()=>(window as unknown as {__q36WebKitMotion:{native:number}}).__q36WebKitMotion.native)).toBe(0);
});
