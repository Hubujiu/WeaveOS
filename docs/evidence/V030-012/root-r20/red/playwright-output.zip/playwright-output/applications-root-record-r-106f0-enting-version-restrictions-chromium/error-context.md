# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-record-read-contract.component.spec.ts >> Root preserves description layout and canonical UUIDs without inventing version restrictions
- Location: src/applications/root-record-read-contract.component.spec.ts:74:1

# Error details

```
Error: 记录响应格式不正确
```

# Test source

```ts
  1  | import type {FieldKind,RecordItem,RecordPage,RecordSort,RuntimeField,RuntimeLayoutNode,RuntimeView,Scope,UUID} from './records/contracts';
  2  | 
  3  | const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  4  | const object=(v:unknown):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v);
  5  | const text=(v:unknown):v is string=>typeof v==='string';
  6  | const version=(v:unknown):v is number=>Number.isSafeInteger(v)&&typeof v==='number'&&v>=0;
  7  | const timestamp=(v:unknown):v is string=>text(v)&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?(?:Z|[+-]\d\d:\d\d)$/.test(v)&&Number.isFinite(Date.parse(v));
> 8  | const fail=():never=>{throw new Error('记录响应格式不正确');};
     |                             ^ Error: 记录响应格式不正确
  9  | const scopes:Scope[]=['none','own','all'];
  10 | const kinds:FieldKind[]=['text','multiline','number','money','date','datetime','single_select','multi_select','boolean','member','department'];
  11 | 
  12 | export function parseRuntimeView(raw:unknown,scope:{appId:string;viewId:string}):RuntimeView{
  13 |  if(!object(raw)||!uuid.test(scope.appId)||!uuid.test(scope.viewId)||raw.appId!==scope.appId||raw.viewId!==scope.viewId||!uuid.test(raw.tableId)||!version(raw.schemaVersion)||!version(raw.viewVersion)||!version(raw.policyRevision)||!Array.isArray(raw.fields)||!Array.isArray(raw.layout)||!object(raw.capabilities))return fail();
  14 |  const fields:RuntimeField[]=raw.fields.map((f:unknown)=>{
  15 |   if(!object(f)||!uuid.test(f.id)||!text(f.name)||!f.name.trim()||!kinds.includes(f.kind)||typeof f.required!=='boolean'||!object(f.presentation)||!(f.presentation.helpText===null||text(f.presentation.helpText))||!(f.presentation.displayTimeZone===null||text(f.presentation.displayTimeZone))||!object(f.input)||!object(f.access)||!object(f.query))return fail();
  16 |   if(!scopes.includes(f.access.read)||typeof f.access.create!=='boolean'||!scopes.includes(f.access.edit)||!scopes.includes(f.access.history)||!Array.isArray(f.query.operators)||!f.query.operators.every((op:unknown)=>['eq','neq','gt','gte','lt','lte'].includes(String(op)))||typeof f.query.sortable!=='boolean'||typeof f.query.quickSearchable!=='boolean')return fail();
  17 |   if(f.input.options!==undefined&&(!Array.isArray(f.input.options)||!f.input.options.every((option:unknown)=>object(option)&&uuid.test(option.id)&&text(option.label))))return fail();
  18 |   if(f.default!==undefined&&!validValue(f.kind,f.default,f.input.options))return fail();
  19 |   if(f.input.decimal!==undefined&&(!object(f.input.decimal)||!['precision','scale','roundingPlaces'].every(k=>version(f.input.decimal[k]))||!['HALF_UP','HALF_EVEN','TOWARD_ZERO','FLOOR','CEILING'].includes(f.input.decimal.roundingMode)))return fail();
  20 |   if(f.input.timePrecision!==undefined&&!['minute','second','millisecond'].includes(f.input.timePrecision))return fail();
  21 |   if(f.input.referenceKind!==undefined&&!['member','department'].includes(f.input.referenceKind))return fail();
  22 |   return f as RuntimeField;
  23 |  });
  24 |  if(new Set(fields.map(f=>f.id)).size!==fields.length)return fail();
  25 |  const ids=new Set(fields.map(f=>f.id));
  26 |  const layout=(nodes:unknown[]):RuntimeLayoutNode[]=>nodes.map((n:unknown)=>{
  27 |   if(!object(n)||!uuid.test(n.id))return fail();
  28 |   if(n.kind==='field'){if(!uuid.test(n.fieldId)||!ids.has(n.fieldId))return fail();return n as RuntimeLayoutNode;}
  29 |   if(n.kind==='system_field'){if(!text(n.fieldId))return fail();return n as RuntimeLayoutNode;}
  30 |   if(n.kind==='divider')return n as RuntimeLayoutNode;
  31 |   if(n.kind==='group'&&text(n.title)&&Array.isArray(n.children))return {...n,children:layout(n.children)} as RuntimeLayoutNode;
  32 |   return fail();
  33 |  });
  34 |  const c=raw.capabilities;if(typeof c.create!=='boolean'||!scopes.includes(c.read)||!scopes.includes(c.edit)||!scopes.includes(c.history)||typeof c.search!=='boolean'||typeof c.draftCreate!=='boolean'||typeof c.draftEdit!=='boolean')return fail();
  35 |  return {...raw,fields,layout:layout(raw.layout)} as RuntimeView;
  36 | }
  37 | function validValue(kind:FieldKind,value:unknown,options?:unknown):boolean{
  38 |  if(value===null)return true;
  39 |  if(kind==='boolean')return typeof value==='boolean';
  40 |  if(kind==='multi_select'||kind==='member'||kind==='department')return Array.isArray(value)&&value.every(v=>text(v)&&uuid.test(v));
  41 |  if(!text(value))return false;
  42 |  if(kind==='number'||kind==='money')return /^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(value);
  43 |  if(kind==='single_select')return !Array.isArray(options)||options.some(o=>object(o)&&o.id===value);
  44 |  if(kind==='date')return /^\d{4}-\d\d-\d\d$/.test(value)&&Number.isFinite(Date.parse(value+'T00:00:00Z'));
  45 |  if(kind==='datetime')return timestamp(value);
  46 |  return true;
  47 | }
  48 | export function parseRecordItem(raw:unknown,view:RuntimeView,actorId:string):RecordItem{
  49 |  if(!object(raw)||!uuid.test(actorId)||!uuid.test(raw.id)||raw.appId!==view.appId||raw.tableId!==view.tableId||raw.viewId!==view.viewId||!uuid.test(raw.createdBy)||!timestamp(raw.createdAt)||!timestamp(raw.updatedAt)||!version(raw.recordVersion)||!version(raw.schemaVersion)||raw.schemaVersion!==view.schemaVersion||!object(raw.values)||!object(raw.referenceDisplays))return fail();
  50 |  if(view.capabilities.read==='own'&&raw.createdBy!==actorId)return fail();
  51 |  const fieldMap=new Map(view.fields.map(field=>[field.id,field]));
  52 |  for(const [id,value] of Object.entries(raw.values)){const field=fieldMap.get(id);if(!field||field.access.read==='none'||!validValue(field.kind,value,field.input.options))return fail();}
  53 |  for(const [fieldId,displays] of Object.entries(raw.referenceDisplays)){const field=fieldMap.get(fieldId);if(!field||!['member','department'].includes(field.kind)||!object(displays))return fail();for(const [id,d] of Object.entries(displays)){if(!uuid.test(id)||!object(d)||d.id!==id||!text(d.label)||typeof d.deleted!=='boolean')return fail();}}
  54 |  return raw as RecordItem;
  55 | }
  56 | export function parseRecordPage(raw:unknown,view:RuntimeView,actorId:string,request:{page:number;pageSize:number;sort:RecordSort}):RecordPage{
  57 |  if(!object(raw)||!Array.isArray(raw.items)||!version(raw.total)||raw.page!==request.page||raw.pageSize!==request.pageSize||!version(raw.page)||!version(raw.pageSize)||raw.page<1||raw.pageSize<1||typeof raw.queryVersion!=='string'||!raw.queryVersion||raw.queryVersion.length>512||raw.schemaVersion!==view.schemaVersion||raw.viewVersion!==view.viewVersion)return fail();
  58 |  const sort=raw.sort===null?null:object(raw.sort)&&uuid.test(raw.sort.fieldId)&&['asc','desc'].includes(raw.sort.direction)?raw.sort as RecordSort:fail();
  59 |  if(JSON.stringify(sort)!==JSON.stringify(request.sort))return fail();
  60 |  const items=raw.items.map(item=>parseRecordItem(item,view,actorId));
  61 |  return {...raw,items} as RecordPage;
  62 | }
  63 | 
```