# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-record-read-contract.component.spec.ts >> Root rejects invalid decimal configuration {"precision":2,"scale":3,"roundingPlaces":2}
- Location: src/applications/root-record-read-contract.component.spec.ts:34:2

# Error details

```
Error: expect(received).toThrow()

Received function did not throw
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | import {parseRuntimeView,parseRecordItem,parseRecordPage} from './recordReadContracts';
  3   | const actor='11111111-1111-4111-8111-111111111111',app='22222222-2222-4222-8222-222222222222',viewId='33333333-3333-4333-8333-333333333333';
  4   | const fieldId='44444444-4444-4444-8444-444444444444',sourceId='55555555-5555-4555-8555-555555555555',recordId='77777777-7777-4777-8777-777777777777';
  5   | const field=(kind:string,input:object={})=>({id:fieldId,name:'字段',kind,required:false,presentation:{helpText:null,displayTimeZone:null},input,access:{read:'all',create:true,edit:'all',history:'none'},query:{operators:['eq','neq'],sortable:false,quickSearchable:false}});
  6   | const rawView=(f=field('text'))=>({appId:app,tableId:app,viewId,schemaVersion:1,viewVersion:1,policyRevision:1,fields:[f],layout:[{id:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',kind:'field',fieldId}],capabilities:{create:true,read:'all',edit:'all',history:'none',search:true,draftCreate:true,draftEdit:true}});
  7   | const row=(value:unknown)=>({id:recordId,appId:app,tableId:app,viewId,createdBy:actor,createdAt:'2026-10-03T09:00:00Z',updatedAt:'2026-10-03T09:00:00Z',recordVersion:1,schemaVersion:1,values:{[fieldId]:value},referenceDisplays:{}});
  8   | const parseView=(raw:unknown)=>parseRuntimeView(raw,{appId:app,viewId});
  9   | const page=(items:unknown[],sort:unknown=null)=>({items,total:items.length,page:1,pageSize:20,sort,queryVersion:'opaque-query',schemaVersion:1,viewVersion:1});
  10  | 
  11  | for(const kind of ['member','department']){
  12  |  test('Root read contract keeps scalar '+kind+' references including tombstones',()=>{
  13  |   const view=parseView(rawView(field(kind,{referenceKind:kind})));
  14  |   const item={...row(sourceId),referenceDisplays:{[fieldId]:{[sourceId]:{id:sourceId,label:'历史成员',deleted:true}}}};
  15  |   expect(parseRecordItem(item,view,actor).values[fieldId]).toBe(sourceId);
  16  |   expect(()=>parseRecordItem(row([sourceId]),view,actor)).toThrow();
  17  |  });
  18  | }
  19  | 
  20  | test('Root runtime accepts rounding at the hundreds place without float conversion',()=>{
  21  |  const raw=rawView(field('money',{decimal:{precision:20,scale:2,roundingPlaces:-2,roundingMode:'TOWARD_ZERO'}}));
  22  |  const view=parseView(raw);
  23  |  expect(view.fields[0].input.decimal?.roundingPlaces).toBe(-2);
  24  |  expect(parseRecordItem(row('9007199254740900.00'),view,actor).values[fieldId]).toBe('9007199254740900.00');
  25  | });
  26  | for(const decimal of [
  27  |  {precision:0,scale:0,roundingPlaces:0},
  28  |  {precision:39,scale:2,roundingPlaces:2},
  29  |  {precision:20,scale:19,roundingPlaces:2},
  30  |  {precision:2,scale:3,roundingPlaces:2},
  31  |  {precision:20,scale:2,roundingPlaces:-19},
  32  |  {precision:20,scale:2,roundingPlaces:3},
  33  | ]){
  34  |  test('Root rejects invalid decimal configuration '+JSON.stringify(decimal),()=>{
> 35  |   expect(()=>parseView(rawView(field('money',{decimal:{...decimal,roundingMode:'HALF_UP'}})))).toThrow();
      |                                                                                                ^ Error: expect(received).toThrow()
  36  |  });
  37  | }
  38  | 
  39  | test('Root record read-none and own-row policies cannot be widened by field access',()=>{
  40  |  const view=parseView(rawView());
  41  |  expect(()=>parseRecordItem(row('value'),{...view,capabilities:{...view.capabilities,read:'none'}},actor)).toThrow();
  42  |  expect(()=>parseRecordItem({...row('value'),createdBy:sourceId},{...view,capabilities:{...view.capabilities,read:'own'}},actor)).toThrow();
  43  | });
  44  | test('Root own-field value is rejected when the record belongs to somebody else',()=>{
  45  |  const raw=rawView();raw.fields[0].access.read='own';const view=parseView(raw);
  46  |  expect(parseRecordItem(row('本人值'),view,actor).values[fieldId]).toBe('本人值');
  47  |  expect(()=>parseRecordItem({...row('不属于本人的值'),createdBy:sourceId},view,actor)).toThrow();
  48  | });
  49  | test('Root persisted records require positive record and schema versions',()=>{
  50  |  const view=parseView(rawView());
  51  |  expect(()=>parseRecordItem({...row('x'),recordVersion:0},view,actor)).toThrow();
  52  |  const unready={...view,schemaVersion:0};
  53  |  expect(()=>parseRecordItem({...row('x'),schemaVersion:0},unready,actor)).toThrow();
  54  | });
  55  | 
  56  | test('Root supports system timestamp sort and ignores JSON object key order',()=>{
  57  |  const view=parseView(rawView());
  58  |  const sort={fieldId:'createdAt',direction:'asc'} as const;
  59  |  expect(parseRecordPage(page([row('x')],{direction:'asc',fieldId:'createdAt'}),view,actor,{page:1,pageSize:20,sort}).sort).toEqual(sort);
  60  |  const numeric=parseView(rawView(field('money')));numeric.fields[0].query.sortable=true;
  61  |  const fieldSort={fieldId,direction:'desc'} as const;
  62  |  expect(parseRecordPage(page([row('1.20')],{direction:'desc',fieldId}),numeric,actor,{page:1,pageSize:20,sort:fieldSort}).items).toHaveLength(1);
  63  | });
  64  | 
  65  | test('Root rejects duplicate row IDs and oversized pages',()=>{
  66  |  const view=parseView(rawView());
  67  |  expect(()=>parseRecordPage(page([row('x'),row('y')]),view,actor,{page:1,pageSize:20,sort:null})).toThrow();
  68  |  const oversized={...page([row('x')]),pageSize:101};
  69  |  expect(()=>parseRecordPage(oversized,view,actor,{page:1,pageSize:101,sort:null})).toThrow();
  70  |  const excess={...page([row('x'),{...row('y'),id:sourceId}]),pageSize:1};
  71  |  expect(()=>parseRecordPage(excess,view,actor,{page:1,pageSize:1,sort:null})).toThrow();
  72  | });
  73  | 
  74  | test('Root preserves description layout and canonical UUIDs without inventing version restrictions',()=>{
  75  |  const raw=rawView();
  76  |  const anyVersion='00000000-0000-0000-0000-000000000001';
  77  |  raw.fields[0].id=anyVersion;raw.layout[0].fieldId=anyVersion;
  78  |  const withDescription={...raw,layout:[{id:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaab',kind:'description',text:'填写说明'},...raw.layout]};
  79  |  expect(parseView(withDescription).layout[0]).toMatchObject({kind:'description',text:'填写说明'});
  80  | });
  81  | test('Root calendar dates reject impossible days and retain leap days',()=>{
  82  |  const view=parseView(rawView(field('date')));
  83  |  expect(parseRecordItem(row('2024-02-29'),view,actor).values[fieldId]).toBe('2024-02-29');
  84  |  expect(()=>parseRecordItem(row('2026-02-31'),view,actor)).toThrow();
  85  | });
  86  | test('Root query operators must be literal strings rather than coercible arrays',()=>{
  87  |  const raw=rawView();const malformed={...raw,fields:[{...raw.fields[0],query:{...raw.fields[0].query,operators:[['eq']]}}]};
  88  |  expect(()=>parseView(malformed)).toThrow();
  89  | });
  90  | test('Root layout span follows the declared integer range',()=>{
  91  |  const raw=rawView();
  92  |  expect(()=>parseView({...raw,layout:[{...raw.layout[0],span:13}]})).toThrow();
  93  |  expect(()=>parseView({...raw,layout:[{...raw.layout[0],span:1.5}]})).toThrow();
  94  |  expect(parseView({...raw,layout:[{...raw.layout[0],span:6}]}).layout[0]).toMatchObject({span:6});
  95  | });
  96  | 
  97  | test('Root ordinary runtime requires a ready schema and positive policy revision',()=>{
  98  |  const raw=rawView();
  99  |  expect(()=>parseView({...raw,schemaVersion:0})).toThrow();
  100 |  expect(()=>parseView({...raw,policyRevision:0})).toThrow();
  101 | });
  102 | test('Root reference labels cannot bypass an own-field read restriction',()=>{
  103 |  const raw=rawView(field('member',{referenceKind:'member'}));raw.fields[0].access.read='own';const view=parseView(raw);
  104 |  const invalid={...row(null),createdBy:sourceId,values:{},referenceDisplays:{[fieldId]:{[sourceId]:{id:sourceId,label:'不可读取的标签',deleted:true}}}};
  105 |  expect(()=>parseRecordItem(invalid,view,actor)).toThrow();
  106 | });
  107 | 
```