# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-record-workspace.component.spec.ts >> Root visible record selection works and sorting clears selected rows
- Location: src/applications/root-record-workspace.component.spec.ts:118:1

# Error details

```
Error: expect(locator).toBeChecked() failed

Locator:  getByRole('checkbox', { name: '选择记录：77777777-7777-4777-8777-000000000001', exact: true })
Expected: checked
Received: unchecked
Timeout:  5000ms

Call log:
  - Expect "toBeChecked" getByRole('checkbox', { name: '选择记录：77777777-7777-4777-8777-000000000001', exact: true }) with timeout 5000ms
  - waiting for getByRole('checkbox', { name: '选择记录：77777777-7777-4777-8777-000000000001', exact: true })
    14 × locator resolved to <button id="_r_3_" tabindex="0" type="button" role="checkbox" aria-checked="false" data-state="unchecked" aria-label="选择记录：77777777-7777-4777-8777-000000000001" class="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 outline-none transition-colors duration-200 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-60 border-muted-foreground/50 bg-background hover:border-muted…></button>
       - unexpected value "unchecked"

```

```yaml
- checkbox "选择记录：77777777-7777-4777-8777-000000000001"
```

# Test source

```ts
  22  |  await open(page);
  23  |  const table=page.getByRole('table',{name:'记录',exact:true});
  24  |  await expect(table).toContainText('测试记录 1');
  25  |  expect(requests.map(r=>r.pathname)).toEqual([path+'/runtime',path+'/records/search']);
  26  |  expect(requests.every(r=>r.actor===actor)).toBe(true);
  27  |  expect(requests[1]).toMatchObject({method:'POST',body:{page:1,pageSize:20,filter:null,sort:null}});
  28  |  expect(requests[1].body).not.toHaveProperty('queryVersion');
  29  |  await table.getByRole('button',{name:'打开记录：事由 测试记录 1',exact:true}).click();
  30  |  await expect.poll(async()=> (await events(page)).opened.length).toBe(1);
  31  |  const opened=(await events(page)).opened[0];
  32  |  expect(opened.record.id).toBe(row(1).id);expect(opened.view.viewId).toBe(viewId);expect(opened.queryVersion).toBe('query-first');
  33  | });
  34  | 
  35  | test('Root page jump retains old query and explicit refresh returns to page one without it',async({page})=>{
  36  |  const queries:any[]=[];
  37  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  38  |  await page.route('**'+path+'/records/search',route=>{
  39  |   const input=route.request().postDataJSON();queries.push(input);
  40  |   return route.fulfill({status:200,json:envelope(pageData(input,'query-'+queries.length))});
  41  |  });
  42  |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  43  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByRole('button',{name:'跳转到指定页',exact:true}).click();
  44  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 21');
  45  |  expect(queries[1]).toMatchObject({page:2,queryVersion:'query-1'});
  46  |  await page.getByRole('button',{name:'刷新',exact:true}).click();
  47  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  48  |  await expect.poll(()=>queries.length).toBe(3);
  49  |  expect(queries[2].page).toBe(1);expect(queries[2]).not.toHaveProperty('queryVersion');
  50  | });
  51  | 
  52  | test('Root changed query preserves existing rows until the user explicitly refreshes',async({page})=>{
  53  |  const queries:any[]=[];
  54  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  55  |  await page.route('**'+path+'/records/search',route=>{
  56  |   const input=route.request().postDataJSON();queries.push(input);
  57  |   if(queries.length===2)return route.fulfill({status:409,json:{code:'APPLICATION_QUERY_CHANGED',data:null,meta:null}});
  58  |   return route.fulfill({status:200,json:envelope(pageData(input,'query-live'))});
  59  |  });
  60  |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  61  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByRole('button',{name:'跳转到指定页',exact:true}).click();
  62  |  await expect(page.getByRole('alert')).toContainText('刷新');
  63  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  64  |  expect(queries).toHaveLength(2);
  65  |  await expect(page.getByRole('button',{name:'新建记录',exact:true})).toBeDisabled();
  66  |  await page.getByRole('button',{name:'刷新',exact:true}).click();
  67  |  await expect.poll(()=>queries.length).toBe(3);
  68  |  expect(queries[2].page).toBe(1);expect(queries[2]).not.toHaveProperty('queryVersion');
  69  |  await expect(page.getByRole('alert')).toHaveCount(0);
  70  | });
  71  | 
  72  | test('Root rejects a foreign-resource row instead of rendering or silently filtering it',async({page})=>{
  73  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  74  |  await page.route('**'+path+'/records/search',route=>{
  75  |   const result=pageData(route.request().postDataJSON(),'bad-page');
  76  |   result.items[0]={...result.items[0],appId:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',values:{[title]:'外部记录不得出现',[amount]:'1.00'}};
  77  |   return route.fulfill({status:200,json:envelope(result)});
  78  |  });
  79  |  await open(page);await expect(page.getByRole('alert')).toBeVisible();
  80  |  await expect(page.getByText('外部记录不得出现',{exact:false})).toHaveCount(0);
  81  |  expect((await events(page)).opened).toEqual([]);
  82  | });
  83  | 
  84  | test('Root create-only access opens the new record action without querying unreadable rows',async({page})=>{
  85  |  let searches=0;const view=runtime();view.capabilities.read='none';view.capabilities.search=false;view.fields.forEach(f=>{f.access.read='none';});
  86  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(view)}));
  87  |  await page.route('**'+path+'/records/search',route=>{searches++;return route.fulfill({status:403,json:{code:'APPLICATION_FORBIDDEN',data:null,meta:null}});});
  88  |  await open(page);await expect(page.getByRole('button',{name:'新建记录',exact:true})).toBeVisible();await page.getByRole('button',{name:'新建记录',exact:true}).click();
  89  |  await expect.poll(async()=> (await events(page)).creates.length).toBe(1);
  90  |  expect(searches).toBe(0);expect((await events(page)).creates[0].view.viewId).toBe(viewId);
  91  |  expect((await events(page)).creates[0].queryVersion).toBeUndefined();
  92  | });
  93  | 
  94  | test('Root metadata-only view changes reload runtime without discarding query context',async({page})=>{
  95  |  let runtimeCalls=0;const queries:any[]=[];
  96  |  await page.route('**'+path+'/runtime',route=>{
  97  |   runtimeCalls++;const next=runtime();if(runtimeCalls>1){next.viewVersion=2;next.fields[0].name='事由（新）';}
  98  |   return route.fulfill({status:200,json:envelope(next)});
  99  |  });
  100 |  await page.route('**'+path+'/records/search',route=>{
  101 |   const input=route.request().postDataJSON();queries.push(input);
  102 |   const result=pageData(input,'metadata-query-'+queries.length);if(queries.length>1)result.viewVersion=2;
  103 |   return route.fulfill({status:200,json:envelope(result)});
  104 |  });
  105 |  await open(page);
  106 |  const table=page.getByRole('table',{name:'记录',exact:true});
  107 |  await expect(table).toContainText('测试记录 1');
  108 |  await table.getByRole('button',{name:'排序 '+amount,exact:true}).click();
  109 |  await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  110 |  await expect(table.locator('thead')).toContainText('事由（新）');
  111 |  expect(runtimeCalls).toBe(2);
  112 |  expect(queries[1]).toMatchObject({page:1,queryVersion:'metadata-query-1',sort:{fieldId:amount,direction:'asc'}});
  113 |  expect(queries.slice(1).every(input=>typeof input.queryVersion==='string'&&input.queryVersion.length>0)).toBe(true);
  114 |  await expect(page.getByRole('alert')).toHaveCount(0);
  115 |  await expect(table).toContainText('测试记录 1');
  116 | });
  117 | 
  118 | test('Root visible record selection works and sorting clears selected rows',async({page})=>{
  119 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  120 |  await page.route('**'+path+'/records/search',route=>route.fulfill({status:200,json:envelope(pageData(route.request().postDataJSON(),'selection-query'))}));
  121 |  await open(page);const checkbox=page.getByRole('checkbox',{name:'选择记录：'+row(1).id,exact:true});
> 122 |  await expect(checkbox).toBeVisible();await checkbox.click();await expect(checkbox).toBeChecked();
      |                                                                                     ^ Error: expect(locator).toBeChecked() failed
  123 |  await page.getByRole('table',{name:'记录'}).getByRole('button',{name:'排序 '+amount,exact:true}).click();
  124 |  await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  125 |  await expect(checkbox).not.toBeChecked();
  126 | });
  127 | test('Root unconfigured schema gives an actionable configuration state without querying rows',async({page})=>{
  128 |  let searches=0;
  129 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:409,json:{code:'APPLICATION_SCHEMA_NOT_READY',data:null,meta:null}}));
  130 |  await page.route('**'+path+'/records/search',route=>{searches++;return route.abort();});
  131 |  await open(page);await expect(page.getByRole('alert')).toContainText('尚未配置');
  132 |  expect(searches).toBe(0);
  133 | });
  134 | test('Root pagination remains inside the bounded application work area',async({page})=>{
  135 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  136 |  await page.route('**'+path+'/records/search',route=>route.fulfill({status:200,json:envelope(pageData(route.request().postDataJSON(),'bounded-query'))}));
  137 |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  138 |  await expect.poll(async()=>{
  139 |   const button=await page.getByRole('button',{name:'跳转到指定页',exact:true}).boundingBox();
  140 |   const area=await page.getByRole('main',{name:'记录测试工作区',exact:true}).boundingBox();
  141 |   return !!button&&!!area&&button.y>=area.y&&button.y+button.height<=area.y+area.height;
  142 |  }).toBe(true);
  143 | });
  144 | 
```