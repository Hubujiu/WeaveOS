# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-record-workspace.component.spec.ts >> Root changed query preserves existing rows until the user explicitly refreshes
- Location: src/applications/root-record-workspace.component.spec.ts:52:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '跳转到指定页', exact: true })
    - locator resolved to <button tabindex="0" type="submit" data-slot="button" aria-label="跳转到指定页" class="group/button inline-flex shrink-0 items-center justify-center border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destruct…>…</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not stable
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not stable
    - retrying click action
      - waiting 100ms
    53 × waiting for element to be visible, enabled and stable
       - element is not stable
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "记录测试工作区" [ref=e5]:
    - heading "记录工作台" [level=1] [ref=e7]
    - generic [ref=e8]: 当前表单
    - region "记录工作区" [ref=e9]:
      - generic [ref=e10]:
        - button "刷新" [ref=e11] [cursor=pointer]
        - button "新建记录" [ref=e12] [cursor=pointer]
      - region "记录列表" [ref=e13]:
        - generic [ref=e15]:
          - generic "记录表格滚动区域" [ref=e17]:
            - table "记录" [ref=e19]:
              - rowgroup [ref=e24]:
                - row [ref=e25]:
                  - columnheader [ref=e26]:
                    - checkbox "选择当前页记录" [ref=e29]
                  - columnheader "拖动以调整 44444444-4444-4444-8444-444444444444 列顺序 事由 Resize 44444444-4444-4444-8444-444444444444 column" [ref=e30]:
                    - generic [ref=e31]:
                      - button "拖动以调整 44444444-4444-4444-8444-444444444444 列顺序" [ref=e32]
                      - generic [ref=e35]: 事由
                    - button "Resize 44444444-4444-4444-8444-444444444444 column" [ref=e37]
                  - columnheader "拖动以调整 55555555-5555-4555-8555-555555555555 列顺序 金额 排序 55555555-5555-4555-8555-555555555555 Resize 55555555-5555-4555-8555-555555555555 column" [ref=e38]:
                    - generic [ref=e39]:
                      - button "拖动以调整 55555555-5555-4555-8555-555555555555 列顺序" [ref=e40]
                      - generic [ref=e43]:
                        - generic [ref=e44]: 金额
                        - button "排序 55555555-5555-4555-8555-555555555555" [ref=e45]
                    - button "Resize 55555555-5555-4555-8555-555555555555 column" [ref=e48]
              - rowgroup [ref=e49]:
                - row [ref=e50]:
                  - cell [ref=e51]:
                    - generic: "1"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000001" [ref=e54]
                  - cell [ref=e55]:
                    - button "打开记录：事由 测试记录 1" [ref=e56]: 测试记录 1
                  - cell [ref=e57]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e58]: "9007199254740993.01"
                - row [ref=e59]:
                  - cell [ref=e60]:
                    - generic: "2"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000002" [ref=e63]
                  - cell [ref=e64]:
                    - button "打开记录：事由 测试记录 2" [ref=e65]: 测试记录 2
                  - cell [ref=e66]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e67]: "9007199254740993.01"
                - row [ref=e68]:
                  - cell [ref=e69]:
                    - generic: "3"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000003" [ref=e72]
                  - cell [ref=e73]:
                    - button "打开记录：事由 测试记录 3" [ref=e74]: 测试记录 3
                  - cell [ref=e75]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e76]: "9007199254740993.01"
                - row [ref=e77]:
                  - cell [ref=e78]:
                    - generic: "4"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000004" [ref=e81]
                  - cell [ref=e82]:
                    - button "打开记录：事由 测试记录 4" [ref=e83]: 测试记录 4
                  - cell [ref=e84]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e85]: "9007199254740993.01"
                - row [ref=e86]:
                  - cell [ref=e87]:
                    - generic: "5"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000005" [ref=e90]
                  - cell [ref=e91]:
                    - button "打开记录：事由 测试记录 5" [ref=e92]: 测试记录 5
                  - cell [ref=e93]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e94]: "9007199254740993.01"
                - row [ref=e95]:
                  - cell [ref=e96]:
                    - generic: "6"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000006" [ref=e99]
                  - cell [ref=e100]:
                    - button "打开记录：事由 测试记录 6" [ref=e101]: 测试记录 6
                  - cell [ref=e102]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e103]: "9007199254740993.01"
                - row [ref=e104]:
                  - cell [ref=e105]:
                    - generic: "7"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000007" [ref=e108]
                  - cell [ref=e109]:
                    - button "打开记录：事由 测试记录 7" [ref=e110]: 测试记录 7
                  - cell [ref=e111]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e112]: "9007199254740993.01"
                - row [ref=e113]:
                  - cell [ref=e114]:
                    - generic: "8"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000008" [ref=e117]
                  - cell [ref=e118]:
                    - button "打开记录：事由 测试记录 8" [ref=e119]: 测试记录 8
                  - cell [ref=e120]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e121]: "9007199254740993.01"
                - row [ref=e122]:
                  - cell [ref=e123]:
                    - generic: "9"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000009" [ref=e126]
                  - cell [ref=e127]:
                    - button "打开记录：事由 测试记录 9" [ref=e128]: 测试记录 9
                  - cell [ref=e129]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e130]: "9007199254740993.01"
                - row [ref=e131]:
                  - cell [ref=e132]:
                    - generic: "10"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000010" [ref=e135]
                  - cell [ref=e136]:
                    - button "打开记录：事由 测试记录 10" [ref=e137]: 测试记录 10
                  - cell [ref=e138]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e139]: "9007199254740993.01"
                - row [ref=e140]:
                  - cell [ref=e141]:
                    - generic: "11"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000011" [ref=e144]
                  - cell [ref=e145]:
                    - button "打开记录：事由 测试记录 11" [ref=e146]: 测试记录 11
                  - cell [ref=e147]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e148]: "9007199254740993.01"
                - row [ref=e149]:
                  - cell [ref=e150]:
                    - generic: "12"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000012" [ref=e153]
                  - cell [ref=e154]:
                    - button "打开记录：事由 测试记录 12" [ref=e155]: 测试记录 12
                  - cell [ref=e156]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e157]: "9007199254740993.01"
                - row [ref=e158]:
                  - cell [ref=e159]:
                    - generic: "13"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000013" [ref=e162]
                  - cell [ref=e163]:
                    - button "打开记录：事由 测试记录 13" [ref=e164]: 测试记录 13
                  - cell [ref=e165]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e166]: "9007199254740993.01"
                - row [ref=e167]:
                  - cell [ref=e168]:
                    - generic: "14"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000014" [ref=e171]
                  - cell [ref=e172]:
                    - button "打开记录：事由 测试记录 14" [ref=e173]: 测试记录 14
                  - cell [ref=e174]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e175]: "9007199254740993.01"
                - row [ref=e176]:
                  - cell [ref=e177]:
                    - generic: "15"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000015" [ref=e180]
                  - cell [ref=e181]:
                    - button "打开记录：事由 测试记录 15" [ref=e182]: 测试记录 15
                  - cell [ref=e183]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e184]: "9007199254740993.01"
                - row [ref=e185]:
                  - cell [ref=e186]:
                    - generic: "16"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000016" [ref=e189]
                  - cell [ref=e190]:
                    - button "打开记录：事由 测试记录 16" [ref=e191]: 测试记录 16
                  - cell [ref=e192]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e193]: "9007199254740993.01"
                - row [ref=e194]:
                  - cell [ref=e195]:
                    - generic: "17"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000017" [ref=e198]
                  - cell [ref=e199]:
                    - button "打开记录：事由 测试记录 17" [ref=e200]: 测试记录 17
                  - cell [ref=e201]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e202]: "9007199254740993.01"
                - row [ref=e203]:
                  - cell [ref=e204]:
                    - generic: "18"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000018" [ref=e207]
                  - cell [ref=e208]:
                    - button "打开记录：事由 测试记录 18" [ref=e209]: 测试记录 18
                  - cell [ref=e210]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e211]: "9007199254740993.01"
                - row [ref=e212]:
                  - cell [ref=e213]:
                    - generic: "19"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000019" [ref=e216]
                  - cell [ref=e217]:
                    - button "打开记录：事由 测试记录 19" [ref=e218]: 测试记录 19
                  - cell [ref=e219]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e220]: "9007199254740993.01"
                - row [ref=e221]:
                  - cell [ref=e222]:
                    - generic: "20"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000020" [ref=e225]
                  - cell [ref=e226]:
                    - button "打开记录：事由 测试记录 20" [ref=e227]: 测试记录 20
                  - cell [ref=e228]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e229]: "9007199254740993.01"
                - row [aria-hidden] [ref=e230]:
                  - cell [ref=e231]
                  - cell [ref=e232]
                  - cell [ref=e233]
                - row [aria-hidden] [ref=e234]:
                  - cell [ref=e235]
                  - cell [ref=e236]
                  - cell [ref=e237]
                - row [aria-hidden] [ref=e238]:
                  - cell [ref=e239]
                  - cell [ref=e240]
                  - cell [ref=e241]
                - row [aria-hidden] [ref=e242]:
                  - cell [ref=e243]
                  - cell [ref=e244]
                  - cell [ref=e245]
                - row [aria-hidden] [ref=e246]:
                  - cell [ref=e247]
                  - cell [ref=e248]
                  - cell [ref=e249]
                - row [aria-hidden] [ref=e250]:
                  - cell [ref=e251]
                  - cell [ref=e252]
                  - cell [ref=e253]
                - row [aria-hidden] [ref=e254]:
                  - cell [ref=e255]
                  - cell [ref=e256]
                  - cell [ref=e257]
                - row [aria-hidden] [ref=e258]:
                  - cell [ref=e259]
                  - cell [ref=e260]
                  - cell [ref=e261]
                - row [aria-hidden] [ref=e262]:
                  - cell [ref=e263]
                  - cell [ref=e264]
                  - cell [ref=e265]
                - row [aria-hidden] [ref=e266]:
                  - cell [ref=e267]
                  - cell [ref=e268]
                  - cell [ref=e269]
                - row [aria-hidden] [ref=e270]:
                  - cell [ref=e271]
                  - cell [ref=e272]
                  - cell [ref=e273]
                - row [aria-hidden] [ref=e274]:
                  - cell [ref=e275]
                  - cell [ref=e276]
                  - cell [ref=e277]
                - row [aria-hidden] [ref=e278]:
                  - cell [ref=e279]
                  - cell [ref=e280]
                  - cell [ref=e281]
                - row [aria-hidden] [ref=e282]:
                  - cell [ref=e283]
                  - cell [ref=e284]
                  - cell [ref=e285]
                - row [aria-hidden] [ref=e286]:
                  - cell [ref=e287]
                  - cell [ref=e288]
                  - cell [ref=e289]
                - row [aria-hidden] [ref=e290]:
                  - cell [ref=e291]
                  - cell [ref=e292]
                  - cell [ref=e293]
                - row [aria-hidden] [ref=e294]:
                  - cell [ref=e295]
                  - cell [ref=e296]
                  - cell [ref=e297]
                - row [aria-hidden] [ref=e298]:
                  - cell [ref=e299]
                  - cell [ref=e300]
                  - cell [ref=e301]
                - row [aria-hidden] [ref=e302]:
                  - cell [ref=e303]
                  - cell [ref=e304]
                  - cell [ref=e305]
                - row [aria-hidden] [ref=e306]:
                  - cell [ref=e307]
                  - cell [ref=e308]
                  - cell [ref=e309]
                - row [aria-hidden] [ref=e310]:
                  - cell [ref=e311]
                  - cell [ref=e312]
                  - cell [ref=e313]
                - row [aria-hidden] [ref=e314]:
                  - cell [ref=e315]
                  - cell [ref=e316]
                  - cell [ref=e317]
                - row [aria-hidden] [ref=e318]:
                  - cell [ref=e319]
                  - cell [ref=e320]
                  - cell [ref=e321]
                - row [aria-hidden] [ref=e322]:
                  - cell [ref=e323]
                  - cell [ref=e324]
                  - cell [ref=e325]
                - row [aria-hidden] [ref=e326]:
                  - cell [ref=e327]
                  - cell [ref=e328]
                  - cell [ref=e329]
                - row [aria-hidden] [ref=e330]:
                  - cell [ref=e331]
                  - cell [ref=e332]
                  - cell [ref=e333]
                - row [aria-hidden] [ref=e334]:
                  - cell [ref=e335]
                  - cell [ref=e336]
                  - cell [ref=e337]
                - row [aria-hidden] [ref=e338]:
                  - cell [ref=e339]
                  - cell [ref=e340]
                  - cell [ref=e341]
                - row [aria-hidden] [ref=e342]:
                  - cell [ref=e343]
                  - cell [ref=e344]
                  - cell [ref=e345]
                - row [aria-hidden] [ref=e346]:
                  - cell [ref=e347]
                  - cell [ref=e348]
                  - cell [ref=e349]
                - row [aria-hidden] [ref=e350]:
                  - cell [ref=e351]
                  - cell [ref=e352]
                  - cell [ref=e353]
                - row [aria-hidden] [ref=e354]:
                  - cell [ref=e355]
                  - cell [ref=e356]
                  - cell [ref=e357]
                - row [aria-hidden] [ref=e358]:
                  - cell [ref=e359]
                  - cell [ref=e360]
                  - cell [ref=e361]
                - row [aria-hidden] [ref=e362]:
                  - cell [ref=e363]
                  - cell [ref=e364]
                  - cell [ref=e365]
                - row [aria-hidden] [ref=e366]:
                  - cell [ref=e367]
                  - cell [ref=e368]
                  - cell [ref=e369]
                - row [aria-hidden] [ref=e370]:
                  - cell [ref=e371]
                  - cell [ref=e372]
                  - cell [ref=e373]
                - row [aria-hidden] [ref=e374]:
                  - cell [ref=e375]
                  - cell [ref=e376]
                  - cell [ref=e377]
                - row [aria-hidden] [ref=e378]:
                  - cell [ref=e379]
                  - cell [ref=e380]
                  - cell [ref=e381]
                - row [aria-hidden] [ref=e382]:
                  - cell [ref=e383]
                  - cell [ref=e384]
                  - cell [ref=e385]
                - row [aria-hidden] [ref=e386]:
                  - cell [ref=e387]
                  - cell [ref=e388]
                  - cell [ref=e389]
                - row [aria-hidden] [ref=e390]:
                  - cell [ref=e391]
                  - cell [ref=e392]
                  - cell [ref=e393]
                - row [aria-hidden] [ref=e394]:
                  - cell [ref=e395]
                  - cell [ref=e396]
                  - cell [ref=e397]
                - row [aria-hidden] [ref=e398]:
                  - cell [ref=e399]
                  - cell [ref=e400]
                  - cell [ref=e401]
          - generic [ref=e402]:
            - generic [ref=e403]:
              - generic [ref=e404]: 每页条数
              - generic [ref=e405]:
                - combobox "每页条数" [ref=e406]:
                  - generic [ref=e407]: "20"
                - listbox [aria-hidden]:
                  - generic:
                    - generic:
                      - listitem:
                        - option: "5"
                      - listitem:
                        - option: "10"
                      - listitem:
                        - option [selected]: "20"
                      - listitem:
                        - option: "25"
                      - listitem:
                        - option: "50"
                      - listitem:
                        - option: "100"
            - generic [ref=e411]:
              - generic [ref=e412]: 1 - 20 / 共 40 项
              - navigation "Pagination" [ref=e413]:
                - button "上一页" [disabled]
                - button "Page 1" [ref=e414]: "1"
                - button "Page 2" [ref=e415]: "2"
                - button "下一页" [ref=e416]
                - generic [ref=e417]:
                  - generic [ref=e418]:
                    - text: 跳至页
                    - spinbutton "跳至页" [active] [ref=e419]: "2"
                  - button "跳转到指定页" [ref=e420]
  - generic:
    - menu [aria-hidden]:
      - generic:
        - generic:
          - generic:
            - menuitem: 升序
          - generic:
            - menuitem: 降序
```

# Test source

```ts
  1   | import {test,expect,type Page} from '@playwright/test';
  2   | const actor='11111111-1111-4111-8111-111111111111',app='22222222-2222-4222-8222-222222222222',viewId='33333333-3333-4333-8333-333333333333';
  3   | const title='44444444-4444-4444-8444-444444444444',amount='55555555-5555-4555-8555-555555555555';
  4   | const path='/api/v1/applications/'+app+'/forms/'+viewId;
  5   | const field=(id:string,name:string,kind:string)=>({id,name,kind,required:false,presentation:{helpText:null,displayTimeZone:null},input:{},access:{read:'all',create:true,edit:'all',history:'none'},query:{operators:kind==='money'?['eq','neq','gt','gte','lt','lte']:['eq','neq'],sortable:kind==='money',quickSearchable:kind==='text'}});
  6   | const runtime=()=>({appId:app,tableId:app,viewId,schemaVersion:1,viewVersion:1,policyRevision:1,fields:[field(title,'事由','text'),field(amount,'金额','money')],layout:[{id:'aaaaaaaa-aaaa-4aaa-8aaa-000000000001',kind:'field',fieldId:title},{id:'aaaaaaaa-aaaa-4aaa-8aaa-000000000002',kind:'field',fieldId:amount}],capabilities:{create:true,read:'all',edit:'all',history:'none',search:true,draftCreate:true,draftEdit:true}});
  7   | const row=(i:number)=>({id:'77777777-7777-4777-8777-'+String(i).padStart(12,'0'),appId:app,tableId:app,viewId,createdBy:actor,createdAt:'2026-10-03T09:00:00Z',updatedAt:'2026-10-03T09:00:00Z',recordVersion:1,schemaVersion:1,values:{[title]:'测试记录 '+i,[amount]:'9007199254740993.01'},referenceDisplays:{}});
  8   | const pageData=(input:any,token:string)=>({items:Array.from({length:20},(_,i)=>row((input.page-1)*20+i+1)),total:40,page:input.page,pageSize:20,sort:input.sort??null,queryVersion:token,schemaVersion:1,viewVersion:1});
  9   | const envelope=(data:unknown)=>({code:'OK',data,meta:null});
  10  | const events=(page:Page)=>page.evaluate(()=>(window as any).__rootRecordWorkspace);
  11  | const open=(page:Page)=>page.goto('/src/applications/root-record-workspace-fixture.html');
  12  | 
  13  | test('Root runtime record list reads ordinary endpoints then opens the exact row context',async({page})=>{
  14  |  const requests:{method:string;pathname:string;body:any;actor?:string}[]=[];
  15  |  await page.route('**/api/v1/**',route=>{
  16  |   const request=route.request(),pathname=new URL(request.url()).pathname,body=request.postData()?request.postDataJSON():null;
  17  |   requests.push({method:request.method(),pathname,body,actor:request.headers()['x-expected-actor-id']});
  18  |   if(pathname===path+'/runtime')return route.fulfill({status:200,json:envelope(runtime())});
  19  |   if(pathname===path+'/records/search')return route.fulfill({status:200,json:envelope(pageData(body,'query-first'))});
  20  |   return route.fulfill({status:404,json:{code:'TEST_UNEXPECTED_ENDPOINT',data:null,meta:null}});
  21  |  });
  22  |  await open(page);
  23  |  const table=page.getByRole('table',{name:'记录',exact:true});
  24  |  await expect(table).toContainText('测试记录 1');
  25  |  expect(requests.map(r=>r.pathname)).toEqual([path+'/runtime',path+'/records/search']);
  26  |  expect(requests.every(r=>r.actor===actor)).toBe(true);
  27  |  expect(requests[1]).toMatchObject({method:'POST',body:{page:1,pageSize:20,filter:null,sort:null}});
  28  |  expect(requests[1].body).not.toHaveProperty('queryVersion');
  29  |  await table.getByRole('button',{name:'打开记录：事由 测试记录 1',exact:true}).click();
  30  |  await expect.poll(async()=> (await events(page)).opened.length).toBe(1);
  31  |  const opened=(await events(page)).opened[0];
  32  |  expect(opened.record.id).toBe(row(1).id);expect(opened.view.viewId).toBe(viewId);expect(opened.queryVersion).toBe('query-first');
  33  | });
  34  | 
  35  | test('Root page jump retains old query and explicit refresh returns to page one without it',async({page})=>{
  36  |  const queries:any[]=[];
  37  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  38  |  await page.route('**'+path+'/records/search',route=>{
  39  |   const input=route.request().postDataJSON();queries.push(input);
  40  |   return route.fulfill({status:200,json:envelope(pageData(input,'query-'+queries.length))});
  41  |  });
  42  |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  43  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByRole('button',{name:'跳转到指定页',exact:true}).click();
  44  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 21');
  45  |  expect(queries[1]).toMatchObject({page:2,queryVersion:'query-1'});
  46  |  await page.getByRole('button',{name:'刷新',exact:true}).click();
  47  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  48  |  await expect.poll(()=>queries.length).toBe(3);
  49  |  expect(queries[2].page).toBe(1);expect(queries[2]).not.toHaveProperty('queryVersion');
  50  | });
  51  | 
  52  | test('Root changed query preserves existing rows until the user explicitly refreshes',async({page})=>{
  53  |  const queries:any[]=[];
  54  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  55  |  await page.route('**'+path+'/records/search',route=>{
  56  |   const input=route.request().postDataJSON();queries.push(input);
  57  |   if(queries.length===2)return route.fulfill({status:409,json:{code:'APPLICATION_QUERY_CHANGED',data:null,meta:null}});
  58  |   return route.fulfill({status:200,json:envelope(pageData(input,'query-live'))});
  59  |  });
  60  |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
> 61  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByRole('button',{name:'跳转到指定页',exact:true}).click();
      |                                                                                                                ^ Error: locator.click: Test timeout of 30000ms exceeded.
  62  |  await expect(page.getByRole('alert')).toContainText('刷新');
  63  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  64  |  expect(queries).toHaveLength(2);
  65  |  await expect(page.getByRole('button',{name:'新建记录',exact:true})).toBeDisabled();
  66  |  await page.getByRole('button',{name:'刷新',exact:true}).click();
  67  |  await expect.poll(()=>queries.length).toBe(3);
  68  |  expect(queries[2].page).toBe(1);expect(queries[2]).not.toHaveProperty('queryVersion');
  69  |  await expect(page.getByRole('alert')).toHaveCount(0);
  70  | });
  71  | 
  72  | test('Root rejects a foreign-resource row instead of rendering or silently filtering it',async({page})=>{
  73  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  74  |  await page.route('**'+path+'/records/search',route=>{
  75  |   const result=pageData(route.request().postDataJSON(),'bad-page');
  76  |   result.items[0]={...result.items[0],appId:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',values:{[title]:'外部记录不得出现',[amount]:'1.00'}};
  77  |   return route.fulfill({status:200,json:envelope(result)});
  78  |  });
  79  |  await open(page);await expect(page.getByRole('alert')).toBeVisible();
  80  |  await expect(page.getByText('外部记录不得出现',{exact:false})).toHaveCount(0);
  81  |  expect((await events(page)).opened).toEqual([]);
  82  | });
  83  | 
  84  | test('Root create-only access opens the new record action without querying unreadable rows',async({page})=>{
  85  |  let searches=0;const view=runtime();view.capabilities.read='none';view.capabilities.search=false;view.fields.forEach(f=>{f.access.read='none';});
  86  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(view)}));
  87  |  await page.route('**'+path+'/records/search',route=>{searches++;return route.fulfill({status:403,json:{code:'APPLICATION_FORBIDDEN',data:null,meta:null}});});
  88  |  await open(page);await expect(page.getByRole('button',{name:'新建记录',exact:true})).toBeVisible();await page.getByRole('button',{name:'新建记录',exact:true}).click();
  89  |  await expect.poll(async()=> (await events(page)).creates.length).toBe(1);
  90  |  expect(searches).toBe(0);expect((await events(page)).creates[0].view.viewId).toBe(viewId);
  91  |  expect((await events(page)).creates[0].queryVersion).toBeUndefined();
  92  | });
  93  | 
  94  | test('Root metadata-only view changes reload runtime without discarding query context',async({page})=>{
  95  |  let runtimeCalls=0;const queries:any[]=[];
  96  |  await page.route('**'+path+'/runtime',route=>{
  97  |   runtimeCalls++;const next=runtime();if(runtimeCalls>1){next.viewVersion=2;next.fields[0].name='事由（新）';}
  98  |   return route.fulfill({status:200,json:envelope(next)});
  99  |  });
  100 |  await page.route('**'+path+'/records/search',route=>{
  101 |   const input=route.request().postDataJSON();queries.push(input);
  102 |   const result=pageData(input,'metadata-query-'+queries.length);if(queries.length>1)result.viewVersion=2;
  103 |   return route.fulfill({status:200,json:envelope(result)});
  104 |  });
  105 |  await open(page);
  106 |  const table=page.getByRole('table',{name:'记录',exact:true});
  107 |  await expect(table).toContainText('测试记录 1');
  108 |  await table.getByRole('button',{name:'排序 '+amount,exact:true}).click();
  109 |  await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  110 |  await expect(table.locator('thead')).toContainText('事由（新）');
  111 |  expect(runtimeCalls).toBe(2);
  112 |  expect(queries[1]).toMatchObject({page:1,queryVersion:'metadata-query-1',sort:{fieldId:amount,direction:'asc'}});
  113 |  expect(queries.slice(1).every(input=>typeof input.queryVersion==='string'&&input.queryVersion.length>0)).toBe(true);
  114 |  await expect(page.getByRole('alert')).toHaveCount(0);
  115 |  await expect(table).toContainText('测试记录 1');
  116 | });
  117 | 
  118 | test('Root visible record selection works and sorting clears selected rows',async({page})=>{
  119 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  120 |  await page.route('**'+path+'/records/search',route=>route.fulfill({status:200,json:envelope(pageData(route.request().postDataJSON(),'selection-query'))}));
  121 |  await open(page);const checkbox=page.getByRole('checkbox',{name:'选择记录：'+row(1).id,exact:true});
  122 |  await expect(checkbox).toBeVisible();await checkbox.click();await expect(checkbox).toBeChecked();
  123 |  await page.getByRole('table',{name:'记录'}).getByRole('button',{name:'排序 '+amount,exact:true}).click();
  124 |  await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  125 |  await expect(checkbox).not.toBeChecked();
  126 | });
  127 | test('Root unconfigured schema gives an actionable configuration state without querying rows',async({page})=>{
  128 |  let searches=0;
  129 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:409,json:{code:'APPLICATION_SCHEMA_NOT_READY',data:null,meta:null}}));
  130 |  await page.route('**'+path+'/records/search',route=>{searches++;return route.abort();});
  131 |  await open(page);await expect(page.getByRole('alert')).toContainText('尚未配置');
  132 |  expect(searches).toBe(0);
  133 | });
  134 | test('Root pagination remains inside the bounded application work area',async({page})=>{
  135 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  136 |  await page.route('**'+path+'/records/search',route=>route.fulfill({status:200,json:envelope(pageData(route.request().postDataJSON(),'bounded-query'))}));
  137 |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  138 |  await expect.poll(async()=>{
  139 |   const button=await page.getByRole('button',{name:'跳转到指定页',exact:true}).boundingBox();
  140 |   const area=await page.getByRole('main',{name:'记录测试工作区',exact:true}).boundingBox();
  141 |   return !!button&&!!area&&button.y>=area.y&&button.y+button.height<=area.y+area.height;
  142 |  }).toBe(true);
  143 | });
  144 | 
```