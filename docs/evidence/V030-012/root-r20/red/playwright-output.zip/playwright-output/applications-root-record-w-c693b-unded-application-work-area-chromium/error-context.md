# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-record-workspace.component.spec.ts >> Root pagination remains inside the bounded application work area
- Location: src/applications/root-record-workspace.component.spec.ts:134:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - main "记录测试工作区" [ref=e5]:
    - heading "记录工作台" [level=1] [ref=e7]
    - generic [ref=e8]: 当前表单
    - region "记录工作区" [ref=e9]:
      - generic [ref=e10]:
        - button "刷新" [ref=e11] [cursor=pointer]
        - button "新建记录" [ref=e12] [cursor=pointer]
      - region "记录列表" [ref=e13]:
        - generic [ref=e15]:
          - generic "记录表格滚动区域" [ref=e17]:
            - table "记录" [ref=e19]:
              - rowgroup [ref=e24]:
                - row [ref=e25]:
                  - columnheader [ref=e26]:
                    - checkbox "选择当前页记录" [ref=e29]
                  - columnheader "拖动以调整 44444444-4444-4444-8444-444444444444 列顺序 事由 Resize 44444444-4444-4444-8444-444444444444 column" [ref=e30]:
                    - generic [ref=e31]:
                      - button "拖动以调整 44444444-4444-4444-8444-444444444444 列顺序" [ref=e32]
                      - generic [ref=e35]: 事由
                    - button "Resize 44444444-4444-4444-8444-444444444444 column" [ref=e37]
                  - columnheader "拖动以调整 55555555-5555-4555-8555-555555555555 列顺序 金额 排序 55555555-5555-4555-8555-555555555555 Resize 55555555-5555-4555-8555-555555555555 column" [ref=e38]:
                    - generic [ref=e39]:
                      - button "拖动以调整 55555555-5555-4555-8555-555555555555 列顺序" [ref=e40]
                      - generic [ref=e43]:
                        - generic [ref=e44]: 金额
                        - button "排序 55555555-5555-4555-8555-555555555555" [ref=e45]
                    - button "Resize 55555555-5555-4555-8555-555555555555 column" [ref=e48]
              - rowgroup [ref=e49]:
                - row [ref=e50]:
                  - cell [ref=e51]:
                    - generic: "1"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000001" [ref=e54]
                  - cell [ref=e55]:
                    - button "打开记录：事由 测试记录 1" [ref=e56]: 测试记录 1
                  - cell [ref=e57]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e58]: "9007199254740993.01"
                - row [ref=e59]:
                  - cell [ref=e60]:
                    - generic: "2"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000002" [ref=e63]
                  - cell [ref=e64]:
                    - button "打开记录：事由 测试记录 2" [ref=e65]: 测试记录 2
                  - cell [ref=e66]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e67]: "9007199254740993.01"
                - row [ref=e68]:
                  - cell [ref=e69]:
                    - generic: "3"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000003" [ref=e72]
                  - cell [ref=e73]:
                    - button "打开记录：事由 测试记录 3" [ref=e74]: 测试记录 3
                  - cell [ref=e75]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e76]: "9007199254740993.01"
                - row [ref=e77]:
                  - cell [ref=e78]:
                    - generic: "4"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000004" [ref=e81]
                  - cell [ref=e82]:
                    - button "打开记录：事由 测试记录 4" [ref=e83]: 测试记录 4
                  - cell [ref=e84]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e85]: "9007199254740993.01"
                - row [ref=e86]:
                  - cell [ref=e87]:
                    - generic: "5"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000005" [ref=e90]
                  - cell [ref=e91]:
                    - button "打开记录：事由 测试记录 5" [ref=e92]: 测试记录 5
                  - cell [ref=e93]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e94]: "9007199254740993.01"
                - row [ref=e95]:
                  - cell [ref=e96]:
                    - generic: "6"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000006" [ref=e99]
                  - cell [ref=e100]:
                    - button "打开记录：事由 测试记录 6" [ref=e101]: 测试记录 6
                  - cell [ref=e102]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e103]: "9007199254740993.01"
                - row [ref=e104]:
                  - cell [ref=e105]:
                    - generic: "7"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000007" [ref=e108]
                  - cell [ref=e109]:
                    - button "打开记录：事由 测试记录 7" [ref=e110]: 测试记录 7
                  - cell [ref=e111]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e112]: "9007199254740993.01"
                - row [ref=e113]:
                  - cell [ref=e114]:
                    - generic: "8"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000008" [ref=e117]
                  - cell [ref=e118]:
                    - button "打开记录：事由 测试记录 8" [ref=e119]: 测试记录 8
                  - cell [ref=e120]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e121]: "9007199254740993.01"
                - row [ref=e122]:
                  - cell [ref=e123]:
                    - generic: "9"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000009" [ref=e126]
                  - cell [ref=e127]:
                    - button "打开记录：事由 测试记录 9" [ref=e128]: 测试记录 9
                  - cell [ref=e129]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e130]: "9007199254740993.01"
                - row [ref=e131]:
                  - cell [ref=e132]:
                    - generic: "10"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000010" [ref=e135]
                  - cell [ref=e136]:
                    - button "打开记录：事由 测试记录 10" [ref=e137]: 测试记录 10
                  - cell [ref=e138]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e139]: "9007199254740993.01"
                - row [ref=e140]:
                  - cell [ref=e141]:
                    - generic: "11"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000011" [ref=e144]
                  - cell [ref=e145]:
                    - button "打开记录：事由 测试记录 11" [ref=e146]: 测试记录 11
                  - cell [ref=e147]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e148]: "9007199254740993.01"
                - row [ref=e149]:
                  - cell [ref=e150]:
                    - generic: "12"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000012" [ref=e153]
                  - cell [ref=e154]:
                    - button "打开记录：事由 测试记录 12" [ref=e155]: 测试记录 12
                  - cell [ref=e156]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e157]: "9007199254740993.01"
                - row [ref=e158]:
                  - cell [ref=e159]:
                    - generic: "13"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000013" [ref=e162]
                  - cell [ref=e163]:
                    - button "打开记录：事由 测试记录 13" [ref=e164]: 测试记录 13
                  - cell [ref=e165]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e166]: "9007199254740993.01"
                - row [ref=e167]:
                  - cell [ref=e168]:
                    - generic: "14"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000014" [ref=e171]
                  - cell [ref=e172]:
                    - button "打开记录：事由 测试记录 14" [ref=e173]: 测试记录 14
                  - cell [ref=e174]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e175]: "9007199254740993.01"
                - row [ref=e176]:
                  - cell [ref=e177]:
                    - generic: "15"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000015" [ref=e180]
                  - cell [ref=e181]:
                    - button "打开记录：事由 测试记录 15" [ref=e182]: 测试记录 15
                  - cell [ref=e183]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e184]: "9007199254740993.01"
                - row [ref=e185]:
                  - cell [ref=e186]:
                    - generic: "16"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000016" [ref=e189]
                  - cell [ref=e190]:
                    - button "打开记录：事由 测试记录 16" [ref=e191]: 测试记录 16
                  - cell [ref=e192]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e193]: "9007199254740993.01"
                - row [ref=e194]:
                  - cell [ref=e195]:
                    - generic: "17"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000017" [ref=e198]
                  - cell [ref=e199]:
                    - button "打开记录：事由 测试记录 17" [ref=e200]: 测试记录 17
                  - cell [ref=e201]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e202]: "9007199254740993.01"
                - row [ref=e203]:
                  - cell [ref=e204]:
                    - generic: "18"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000018" [ref=e207]
                  - cell [ref=e208]:
                    - button "打开记录：事由 测试记录 18" [ref=e209]: 测试记录 18
                  - cell [ref=e210]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e211]: "9007199254740993.01"
                - row [ref=e212]:
                  - cell [ref=e213]:
                    - generic: "19"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000019" [ref=e216]
                  - cell [ref=e217]:
                    - button "打开记录：事由 测试记录 19" [ref=e218]: 测试记录 19
                  - cell [ref=e219]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e220]: "9007199254740993.01"
                - row [ref=e221]:
                  - cell [ref=e222]:
                    - generic: "20"
                    - checkbox "选择记录：77777777-7777-4777-8777-000000000020" [ref=e225]
                  - cell [ref=e226]:
                    - button "打开记录：事由 测试记录 20" [ref=e227]: 测试记录 20
                  - cell [ref=e228]:
                    - button "打开记录：金额 9007199254740993.01" [ref=e229]: "9007199254740993.01"
                - row [aria-hidden] [ref=e230]:
                  - cell [ref=e231]
                  - cell [ref=e232]
                  - cell [ref=e233]
                - row [aria-hidden] [ref=e234]:
                  - cell [ref=e235]
                  - cell [ref=e236]
                  - cell [ref=e237]
                - row [aria-hidden] [ref=e238]:
                  - cell [ref=e239]
                  - cell [ref=e240]
                  - cell [ref=e241]
                - row [aria-hidden] [ref=e242]:
                  - cell [ref=e243]
                  - cell [ref=e244]
                  - cell [ref=e245]
                - row [aria-hidden] [ref=e246]:
                  - cell [ref=e247]
                  - cell [ref=e248]
                  - cell [ref=e249]
                - row [aria-hidden] [ref=e250]:
                  - cell [ref=e251]
                  - cell [ref=e252]
                  - cell [ref=e253]
                - row [aria-hidden] [ref=e254]:
                  - cell [ref=e255]
                  - cell [ref=e256]
                  - cell [ref=e257]
          - generic [ref=e258]:
            - generic [ref=e259]:
              - generic [ref=e260]: 每页条数
              - generic [ref=e261]:
                - combobox "每页条数" [ref=e262]:
                  - generic [ref=e263]: "20"
                - listbox [aria-hidden]:
                  - generic:
                    - generic:
                      - listitem:
                        - option: "5"
                      - listitem:
                        - option: "10"
                      - listitem:
                        - option [selected]: "20"
                      - listitem:
                        - option: "25"
                      - listitem:
                        - option: "50"
                      - listitem:
                        - option: "100"
            - generic [ref=e267]:
              - generic [ref=e268]: 1 - 20 / 共 40 项
              - navigation "Pagination" [ref=e269]:
                - button "上一页" [disabled]
                - button "Page 1" [ref=e270]: "1"
                - button "Page 2" [ref=e271]: "2"
                - button "下一页" [ref=e272]
                - generic [ref=e273]:
                  - generic [ref=e274]:
                    - text: 跳至页
                    - spinbutton "跳至页" [ref=e275]: "1"
                  - button "跳转到指定页" [ref=e276]
  - generic:
    - menu [aria-hidden]:
      - generic:
        - generic:
          - generic:
            - menuitem: 升序
          - generic:
            - menuitem: 降序
```

# Test source

```ts
  42  |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  43  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByRole('button',{name:'跳转到指定页',exact:true}).click();
  44  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 21');
  45  |  expect(queries[1]).toMatchObject({page:2,queryVersion:'query-1'});
  46  |  await page.getByRole('button',{name:'刷新',exact:true}).click();
  47  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  48  |  await expect.poll(()=>queries.length).toBe(3);
  49  |  expect(queries[2].page).toBe(1);expect(queries[2]).not.toHaveProperty('queryVersion');
  50  | });
  51  | 
  52  | test('Root changed query preserves existing rows until the user explicitly refreshes',async({page})=>{
  53  |  const queries:any[]=[];
  54  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  55  |  await page.route('**'+path+'/records/search',route=>{
  56  |   const input=route.request().postDataJSON();queries.push(input);
  57  |   if(queries.length===2)return route.fulfill({status:409,json:{code:'APPLICATION_QUERY_CHANGED',data:null,meta:null}});
  58  |   return route.fulfill({status:200,json:envelope(pageData(input,'query-live'))});
  59  |  });
  60  |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  61  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByRole('button',{name:'跳转到指定页',exact:true}).click();
  62  |  await expect(page.getByRole('alert')).toContainText('刷新');
  63  |  await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  64  |  expect(queries).toHaveLength(2);
  65  |  await expect(page.getByRole('button',{name:'新建记录',exact:true})).toBeDisabled();
  66  |  await page.getByRole('button',{name:'刷新',exact:true}).click();
  67  |  await expect.poll(()=>queries.length).toBe(3);
  68  |  expect(queries[2].page).toBe(1);expect(queries[2]).not.toHaveProperty('queryVersion');
  69  |  await expect(page.getByRole('alert')).toHaveCount(0);
  70  | });
  71  | 
  72  | test('Root rejects a foreign-resource row instead of rendering or silently filtering it',async({page})=>{
  73  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  74  |  await page.route('**'+path+'/records/search',route=>{
  75  |   const result=pageData(route.request().postDataJSON(),'bad-page');
  76  |   result.items[0]={...result.items[0],appId:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',values:{[title]:'外部记录不得出现',[amount]:'1.00'}};
  77  |   return route.fulfill({status:200,json:envelope(result)});
  78  |  });
  79  |  await open(page);await expect(page.getByRole('alert')).toBeVisible();
  80  |  await expect(page.getByText('外部记录不得出现',{exact:false})).toHaveCount(0);
  81  |  expect((await events(page)).opened).toEqual([]);
  82  | });
  83  | 
  84  | test('Root create-only access opens the new record action without querying unreadable rows',async({page})=>{
  85  |  let searches=0;const view=runtime();view.capabilities.read='none';view.capabilities.search=false;view.fields.forEach(f=>{f.access.read='none';});
  86  |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(view)}));
  87  |  await page.route('**'+path+'/records/search',route=>{searches++;return route.fulfill({status:403,json:{code:'APPLICATION_FORBIDDEN',data:null,meta:null}});});
  88  |  await open(page);await expect(page.getByRole('button',{name:'新建记录',exact:true})).toBeVisible();await page.getByRole('button',{name:'新建记录',exact:true}).click();
  89  |  await expect.poll(async()=> (await events(page)).creates.length).toBe(1);
  90  |  expect(searches).toBe(0);expect((await events(page)).creates[0].view.viewId).toBe(viewId);
  91  |  expect((await events(page)).creates[0].queryVersion).toBeUndefined();
  92  | });
  93  | 
  94  | test('Root metadata-only view changes reload runtime without discarding query context',async({page})=>{
  95  |  let runtimeCalls=0;const queries:any[]=[];
  96  |  await page.route('**'+path+'/runtime',route=>{
  97  |   runtimeCalls++;const next=runtime();if(runtimeCalls>1){next.viewVersion=2;next.fields[0].name='事由（新）';}
  98  |   return route.fulfill({status:200,json:envelope(next)});
  99  |  });
  100 |  await page.route('**'+path+'/records/search',route=>{
  101 |   const input=route.request().postDataJSON();queries.push(input);
  102 |   const result=pageData(input,'metadata-query-'+queries.length);if(queries.length>1)result.viewVersion=2;
  103 |   return route.fulfill({status:200,json:envelope(result)});
  104 |  });
  105 |  await open(page);
  106 |  const table=page.getByRole('table',{name:'记录',exact:true});
  107 |  await expect(table).toContainText('测试记录 1');
  108 |  await table.getByRole('button',{name:'排序 '+amount,exact:true}).click();
  109 |  await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  110 |  await expect(table.locator('thead')).toContainText('事由（新）');
  111 |  expect(runtimeCalls).toBe(2);
  112 |  expect(queries[1]).toMatchObject({page:1,queryVersion:'metadata-query-1',sort:{fieldId:amount,direction:'asc'}});
  113 |  expect(queries.slice(1).every(input=>typeof input.queryVersion==='string'&&input.queryVersion.length>0)).toBe(true);
  114 |  await expect(page.getByRole('alert')).toHaveCount(0);
  115 |  await expect(table).toContainText('测试记录 1');
  116 | });
  117 | 
  118 | test('Root visible record selection works and sorting clears selected rows',async({page})=>{
  119 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  120 |  await page.route('**'+path+'/records/search',route=>route.fulfill({status:200,json:envelope(pageData(route.request().postDataJSON(),'selection-query'))}));
  121 |  await open(page);const checkbox=page.getByRole('checkbox',{name:'选择记录：'+row(1).id,exact:true});
  122 |  await expect(checkbox).toBeVisible();await checkbox.click();await expect(checkbox).toBeChecked();
  123 |  await page.getByRole('table',{name:'记录'}).getByRole('button',{name:'排序 '+amount,exact:true}).click();
  124 |  await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  125 |  await expect(checkbox).not.toBeChecked();
  126 | });
  127 | test('Root unconfigured schema gives an actionable configuration state without querying rows',async({page})=>{
  128 |  let searches=0;
  129 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:409,json:{code:'APPLICATION_SCHEMA_NOT_READY',data:null,meta:null}}));
  130 |  await page.route('**'+path+'/records/search',route=>{searches++;return route.abort();});
  131 |  await open(page);await expect(page.getByRole('alert')).toContainText('尚未配置');
  132 |  expect(searches).toBe(0);
  133 | });
  134 | test('Root pagination remains inside the bounded application work area',async({page})=>{
  135 |  await page.route('**'+path+'/runtime',route=>route.fulfill({status:200,json:envelope(runtime())}));
  136 |  await page.route('**'+path+'/records/search',route=>route.fulfill({status:200,json:envelope(pageData(route.request().postDataJSON(),'bounded-query'))}));
  137 |  await open(page);await expect(page.getByRole('table',{name:'记录'})).toContainText('测试记录 1');
  138 |  await expect.poll(async()=>{
  139 |   const button=await page.getByRole('button',{name:'跳转到指定页',exact:true}).boundingBox();
  140 |   const area=await page.getByRole('main',{name:'记录测试工作区',exact:true}).boundingBox();
  141 |   return !!button&&!!area&&button.y>=area.y&&button.y+button.height<=area.y+area.height;
> 142 |  }).toBe(true);
      |     ^ Error: expect(received).toBe(expected) // Object.is equality
  143 | });
  144 | 
```