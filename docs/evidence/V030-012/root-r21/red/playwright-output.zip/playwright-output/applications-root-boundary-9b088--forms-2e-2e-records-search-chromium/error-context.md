# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-boundary.component.spec.ts >> Root read-only search rejects normalized path applications/22222222-2222-4222-8222-222222222222/forms/%2e%2e/records/search
- Location: src/applications/root-boundary.component.spec.ts:85:2

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Object {
-   "message": "Read-only POST is restricted to record search",
-   "typeError": true,
+   "message": "服务暂时不可用，请稍后重试",
+   "typeError": false,
  }
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | const actor='11111111-1111-4111-8111-111111111111';
  3   | const path='applications/22222222-2222-4222-8222-222222222222/forms/33333333-3333-4333-8333-333333333333/records';
  4   | test.beforeEach(async({page})=>{await page.goto('/src/applications/root-boundary-fixture.html');});
  5   | 
  6   | test('Root recovery owns an immutable deep snapshot of the sent packet',async({page})=>{
  7   |  const result=await page.evaluate(()=>{
  8   |   const {recovery}= (window as any).__rootApplicationBoundary;
  9   |   const packet={actorId:'actor-A',scope:'form-A',path:'applications/a/forms/v/records',method:'POST',expectedStatus:201,body:{operationId:'operation-A',values:{amount:'9007199254740993.01',choices:['A']}}};
  10  |   recovery.keepPacket(packet,true);
  11  |   packet.body.values.amount='0';packet.body.values.choices.push('B');
  12  |   const saved=recovery.getRecovery('actor-A','form-A');
  13  |   return {amount:saved.packet.body.values.amount,choices:saved.packet.body.values.choices,
  14  |    frozen:Object.isFrozen(saved.packet)&&Object.isFrozen(saved.packet.body.values)&&Object.isFrozen(saved.packet.body.values.choices),
  15  |    otherActor:recovery.getRecovery('actor-B','form-A')??null,
  16  |    otherScope:recovery.getRecovery('actor-A','form-B')??null};
  17  |  });
  18  |  expect(result).toEqual({amount:'9007199254740993.01',choices:['A'],frozen:true,otherActor:null,otherScope:null});
  19  | });
  20  | 
  21  | test('Root successful PATCH retains actor and exact JSON body',async({page})=>{
  22  |  let observed:any;
  23  |  await page.route('**/api/v1/'+path+'/record-A',async route=>{
  24  |   observed={method:route.request().method(),actor:route.request().headers()['x-expected-actor-id'],body:route.request().postDataJSON()};
  25  |   await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({code:'OK',data:{id:'record-A'},meta:null})});
  26  |  });
  27  |  const result=await page.evaluate(async({actor,path})=>(window as any).__rootApplicationBoundary.api.applicationApi(actor,path+'/record-A','PATCH',{operationId:'operation-A',changes:{amount:'1.20'}},undefined,200),{actor,path});
  28  |  expect(result).toEqual({id:'record-A'});
  29  |  expect(observed).toEqual({method:'PATCH',actor,body:{operationId:'operation-A',changes:{amount:'1.20'}}});
  30  | });
  31  | 
  32  | test('Root DELETE confirms only an exact empty 204',async({page})=>{
  33  |  await page.route('**/api/v1/**',route=>route.fulfill({status:204,body:''}));
  34  |  const result=await page.evaluate(async actor=>{
  35  |   const reply=await (window as any).__rootApplicationBoundary.api.applicationApiEnvelope(actor,'applications/a/forms/v/drafts/d?operationId=o&expectedDraftVersion=1','DELETE',undefined,undefined,204);
  36  |   return {empty:reply.data===undefined,meta:reply.meta};
  37  |  },actor);
  38  |  expect(result).toEqual({empty:true,meta:null});
  39  | });
  40  | 
  41  | test('Root DELETE unexpected successful status stays unconfirmed',async({page})=>{
  42  |  await page.route('**/api/v1/**',route=>route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({code:'OK',data:{},meta:null})}));
  43  |  const result=await page.evaluate(async actor=>{
  44  |   try{await (window as any).__rootApplicationBoundary.api.applicationApi(actor,'applications/a/forms/v/drafts/d','DELETE',undefined,undefined,204);return {confirmed:true};}
  45  |   catch(error){const e=error as any;return {confirmed:false,status:e.status,unknown:e.unconfirmed};}
  46  |  },actor);
  47  |  expect(result).toEqual({confirmed:false,status:200,unknown:true});
  48  | });
  49  | 
  50  | for(const readOnly of [false,true]){
  51  |  test('Root network failure uncertainty follows '+(readOnly?'read-only search':'mutation'),async({page})=>{
  52  |   await page.route('**/api/v1/**',route=>route.abort('failed'));
  53  |   const result=await page.evaluate(async({actor,path,readOnly})=>{
  54  |    const api=(window as any).__rootApplicationBoundary.api;
  55  |    try{if(readOnly)await api.applicationReadPost(actor,path+'/search',{page:1,pageSize:20});else await api.applicationApi(actor,path,'POST',{operationId:'operation-A'},undefined,201);return null;}
  56  |    catch(error){const e=error as any;return {status:e.status,unknown:e.unconfirmed};}
  57  |   },{actor,path,readOnly});
  58  |   expect(result).toEqual({status:0,unknown:!readOnly});
  59  |  });
  60  | }
  61  | 
  62  | test('Root read-only POST does not grant mutation paths read semantics',async({page})=>{
  63  |  let requests=0;await page.route('**/api/v1/**',route=>{requests++;return route.abort();});
  64  |  const result=await page.evaluate(async({actor,path})=>{
  65  |   try{await (window as any).__rootApplicationBoundary.api.applicationReadPost(actor,path,{values:{}});return false;}
  66  |   catch(error){return {typeError:error instanceof TypeError,message:(error as Error).message};}
  67  |  },{actor,path});
  68  |  expect(result).toEqual({typeError:true,message:'Read-only POST is restricted to record search'});expect(requests).toBe(0);
  69  | });
  70  | 
  71  | test('Root malformed read-only search response does not create unknown write state',async({page})=>{
  72  |  await page.route('**/api/v1/**',route=>route.fulfill({status:200,contentType:'application/json',body:'{"code":"OK"}'}));
  73  |  const result=await page.evaluate(async({actor,path})=>{
  74  |   try{await (window as any).__rootApplicationBoundary.api.applicationReadPost(actor,path+'/search',{page:1,pageSize:20});return null;}
  75  |   catch(error){const e=error as any;return {unknown:e.unconfirmed};}
  76  |  },{actor,path});
  77  |  expect(result).toEqual({unknown:false});
  78  | });
  79  | 
  80  | for(const badPath of [
  81  |  'applications/22222222-2222-4222-8222-222222222222#fragment/forms/33333333-3333-4333-8333-333333333333/records/search',
  82  |  'applications/../forms/33333333-3333-4333-8333-333333333333/records/search',
  83  |  'applications/22222222-2222-4222-8222-222222222222/forms/%2e%2e/records/search',
  84  | ]){
  85  |  test('Root read-only search rejects normalized path '+badPath,async({page})=>{
  86  |   let requests=0;await page.route('**/api/v1/**',route=>{requests++;return route.abort();});
  87  |   const result=await page.evaluate(async({actor,badPath})=>{
  88  |    try{await (window as any).__rootApplicationBoundary.api.applicationReadPost(actor,badPath,{page:1,pageSize:20});return null;}
  89  |    catch(error){return {typeError:error instanceof TypeError,message:(error as Error).message};}
  90  |   },{actor,badPath});
> 91  |   expect(result).toEqual({typeError:true,message:'Read-only POST is restricted to record search'});
      |                  ^ Error: expect(received).toEqual(expected) // deep equality
  92  |   expect(requests).toBe(0);
  93  |  });
  94  | }
  95  | test('Root read-only search HTTP 503 remains a read failure',async({page})=>{
  96  |  await page.route('**/api/v1/**',route=>route.fulfill({status:503,json:{code:'COMMON_SERVICE_UNAVAILABLE',data:null,meta:null}}));
  97  |  const result=await page.evaluate(async({actor,path})=>{
  98  |   try{await (window as any).__rootApplicationBoundary.api.applicationReadPost(actor,path+'/search',{page:1,pageSize:20});return null;}
  99  |   catch(error){const e=error as any;return {status:e.status,unknown:e.unconfirmed};}
  100 |  },{actor,path});
  101 |  expect(result).toEqual({status:503,unknown:false});
  102 | });
  103 | 
```