# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-operation-guard.component.spec.ts >> Root leave guard sees preflight immediately and cancellation prevents the write
- Location: src/applications/root-operation-guard.component.spec.ts:14:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
-   "preflight",
+   "missing",
  ]
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - text: 金额
    - textbox "金额" [disabled] [ref=e5]: "1.20"
  - button "保存" [disabled] [ref=e6]
  - button "核查原操作" [disabled] [ref=e7]
  - button "重试原操作" [disabled] [ref=e8]
  - status "操作阶段" [ref=e9]: pending
  - status "当前操作" [ref=e10]: 9e20f0a7-d286-400a-baea-8e0b6cec537e
  - status "错误代码"
  - paragraph
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | const actorId='11111111-1111-4111-8111-111111111111',appId='22222222-2222-4222-8222-222222222222',viewId='33333333-3333-4333-8333-333333333333';
  3  | const recordId='77777777-7777-4777-8777-777777777777';
  4  | const path='/api/v1/applications/'+appId+'/forms/'+viewId+'/records';
  5  | const envelope=(data:unknown)=>({code:'OK',data,meta:null});
  6  | const receipt=(operationId:string)=>({operationId,id:recordId,recordVersion:1,schemaVersion:1,createdAt:'2026-10-03T09:00:00Z',updatedAt:'2026-10-03T09:00:00Z'});
  7  | const events=(page:Page)=>page.evaluate(()=>(window as any).__rootScopedOperation);
  8  | const pending=(page:Page)=>page.evaluate(()=>(window as any).__rootPendingStatus());
  9  | async function open(page:Page,mode='create'){
  10 |  await page.route('**/api/v1/sessions/current',route=>route.fulfill({status:200,json:envelope({id:actorId,account:'root'})}));
  11 |  await page.goto('/src/applications/root-scoped-fixture.html?mode='+mode);
  12 | }
  13 | 
  14 | test('Root leave guard sees preflight immediately and cancellation prevents the write',async({page})=>{
  15 |  await open(page);let release!:()=>void,started!:()=>void,settled!:()=>void;let writes=0;
  16 |  const gate=new Promise<void>(resolve=>{release=resolve;});
  17 |  const entered=new Promise<void>(resolve=>{started=resolve;});
  18 |  const done=new Promise<void>(resolve=>{settled=resolve;});
  19 |  await page.route('**/api/v1/sessions/current',async route=>{started();await gate;try{await route.fulfill({status:200,json:envelope({id:actorId,account:'root'})});}finally{settled();}});
  20 |  await page.route('**'+path,route=>{writes++;const op=route.request().postDataJSON().operationId;return route.fulfill({status:201,headers:{Location:path+'/'+recordId},json:envelope(receipt(op))});});
  21 |  const wire=page.waitForEvent('requestfinished',{predicate:r=>r.url().endsWith('/sessions/current')});
  22 |  try{
  23 |   await page.getByRole('button',{name:'保存',exact:true}).click();await entered;
> 24 |   expect((await events(page)).afterStartPending).toEqual(['preflight']);
     |                                                  ^ Error: expect(received).toEqual(expected) // deep equality
  25 |   expect(await pending(page)).toBe('preflight');
  26 |   expect(await page.evaluate(()=>(window as any).__rootCancelPreflight())).toBeNull();
  27 |  }finally{release();await Promise.allSettled([wire,done]);}
  28 |  await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))));
  29 |  expect(writes).toBe(0);await expect(page.getByLabel('操作阶段')).toHaveText('idle');
  30 | });
  31 | 
  32 | test('Root leave guard distinguishes a sent write and clears only on confirmation',async({page})=>{
  33 |  let release!:()=>void,started!:()=>void;
  34 |  const gate=new Promise<void>(resolve=>{release=resolve;});const entered=new Promise<void>(resolve=>{started=resolve;});
  35 |  await page.route('**'+path,async route=>{const op=route.request().postDataJSON().operationId;started();await gate;await route.fulfill({status:201,headers:{Location:path+'/'+recordId},json:envelope(receipt(op))});});
  36 |  await open(page);
  37 |  try{await page.getByRole('button',{name:'保存',exact:true}).click();await entered;expect(await pending(page)).toBe('write_in_flight');}
  38 |  finally{release();}
  39 |  await expect.poll(async()=> (await events(page)).confirmed.length).toBe(1);
  40 |  expect(await pending(page)).toBeNull();
  41 | });
  42 | 
  43 | for(const status of [408,500,504]){
  44 |  test('Root ambiguous HTTP '+status+' keeps the original write pending',async({page})=>{
  45 |   await page.route('**'+path,route=>route.fulfill({status,json:{code:'COMMON_SERVICE_UNAVAILABLE',data:null,meta:null}}));
  46 |   await open(page);await page.getByRole('button',{name:'保存',exact:true}).click();
  47 |   await expect(page.getByLabel('操作阶段')).toHaveText('unconfirmed');
  48 |   expect(await pending(page)).toBe('unknown');
  49 |   await expect(page.getByRole('button',{name:'保存',exact:true})).toBeDisabled();
  50 |   expect((await events(page)).confirmed).toEqual([]);
  51 |  });
  52 | }
  53 | test('Root definitive record conflict exposes a safe error code for refresh handling',async({page})=>{
  54 |  await page.route('**'+path+'/'+recordId,route=>route.fulfill({status:409,json:{code:'APPLICATION_RECORD_CONFLICT',data:{currentRecordVersion:2},meta:null}}));
  55 |  await open(page,'edit');await page.getByRole('button',{name:'保存',exact:true}).click();
  56 |  await expect(page.getByLabel('操作阶段')).toHaveText('error');
  57 |  await expect(page.getByLabel('错误代码')).toHaveText('APPLICATION_RECORD_CONFLICT');
  58 |  expect(await pending(page)).toBeNull();expect((await events(page)).confirmed).toEqual([]);
  59 | });
  60 | 
```