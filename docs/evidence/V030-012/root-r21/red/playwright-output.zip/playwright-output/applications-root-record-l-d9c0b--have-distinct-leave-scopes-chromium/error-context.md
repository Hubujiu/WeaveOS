# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: applications/root-record-leave.component.spec.ts >> Root record drafts, saved records and persistent drafts have distinct leave scopes
- Location: src/applications/root-record-leave.component.spec.ts:7:1

# Error details

```
Error: expect(received).toHaveLength(expected)

Expected length: 4
Received length: 2
Received array:  [{"controller": {"getStatus": [Function getStatus], "prepareLeave": [Function prepareLeave]}, "scope": {"actorId": "11111111-1111-4111-8111-111111111111", "appId": "22222222-2222-4222-8222-222222222222", "kind": "record", "recordId": "44444444-4444-4444-8444-444444444444", "viewId": "33333333-3333-4333-8333-333333333333"}, "status": "draft"}, {"controller": {"getStatus": [Function getStatus], "prepareLeave": [Function prepareLeave]}, "scope": {"actorId": "11111111-1111-4111-8111-111111111111", "appId": "22222222-2222-4222-8222-222222222222", "draftId": "44444444-4444-4444-8444-444444444444", "kind": "draft", "viewId": "33333333-3333-4333-8333-333333333333"}, "status": "draft"}]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {LeaveGuards} from './shell/leaveGuards';
  3  | import type {LeaveController,LeaveScope} from './forms';
  4  | const actorId='11111111-1111-4111-8111-111111111111',appId='22222222-2222-4222-8222-222222222222',viewId='33333333-3333-4333-8333-333333333333';
  5  | const a='44444444-4444-4444-8444-444444444444',b='55555555-5555-4555-8555-555555555555';
  6  | const controller=(name:string,calls:string[]):LeaveController=>({getStatus:()=> 'draft',prepareLeave:decision=>{calls.push(name+':'+decision);return {ok:true};}});
  7  | test('Root record drafts, saved records and persistent drafts have distinct leave scopes',()=>{
  8  |  const guards=new LeaveGuards(),calls:string[]=[];
  9  |  const scopes:LeaveScope[]=[
  10 |   {kind:'record',actorId,appId,viewId,clientDraftId:a},
  11 |   {kind:'record',actorId,appId,viewId,clientDraftId:b},
  12 |   {kind:'record',actorId,appId,viewId,recordId:a},
  13 |   {kind:'draft',actorId,appId,viewId,draftId:a},
  14 |  ];
  15 |  scopes.forEach((scope,index)=>guards.register(scope,controller(String(index),calls)));
> 16 |  const snapshot=guards.snapshot(actorId);expect(snapshot).toHaveLength(4);
     |                                                           ^ Error: expect(received).toHaveLength(expected)
  17 |  expect(guards.prepare(snapshot)).toEqual({ok:true});
  18 |  expect(calls).toEqual(['0:discard','1:discard','2:discard','3:discard']);
  19 | });
  20 | test('Root old record-scope cleanup cannot remove its replacement',()=>{
  21 |  const guards=new LeaveGuards(),calls:string[]=[];
  22 |  const scope:LeaveScope={kind:'record',actorId,appId,viewId,clientDraftId:a};
  23 |  const old=guards.register(scope,controller('old',calls));
  24 |  guards.register(scope,controller('new',calls));old();
  25 |  expect(guards.snapshot(actorId)).toHaveLength(1);
  26 |  expect(guards.prepare(guards.snapshot(actorId))).toEqual({ok:true});expect(calls).toEqual(['new:discard']);
  27 | });
  28 | test('Root record leave guards remain actor-isolated',()=>{
  29 |  const guards=new LeaveGuards(),calls:string[]=[];
  30 |  guards.register({kind:'record',actorId,appId,viewId,clientDraftId:a},controller('A',calls));
  31 |  guards.register({kind:'record',actorId:b,appId,viewId,clientDraftId:a},controller('B',calls));
  32 |  expect(guards.snapshot(actorId)).toHaveLength(1);
  33 |  expect(guards.prepare(guards.snapshot(actorId))).toEqual({ok:true});expect(calls).toEqual(['A:discard']);
  34 | });
  35 | 
```