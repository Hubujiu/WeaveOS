package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/session"
	"github.com/jackc/pgx/v5/pgxpool"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"reflect"
	"strings"
	"testing"
)

func TestDefinitionConfigRequiresDedicatedExplicitKeyAndLimits(t *testing.T) {
	values := map[string]string{"WEAVEOS_DEFINITION_HMAC_KEY": base64.StdEncoding.EncodeToString([]byte("isolated-definition-test-32bytes!")), "WEAVEOS_DEFINITION_KEY_ID": "test", "WEAVEOS_SCHEMA_LOCK_TIMEOUT_MS": "1000", "WEAVEOS_SCHEMA_STATEMENT_TIMEOUT_MS": "5000"}
	cfg, e := readConfig(func(k string) string { return values[k] })
	if e != nil {
		t.Fatal(e)
	}
	key := reflect.ValueOf(cfg).FieldByName("DefinitionKey")
	if !key.IsValid() || key.Len() < 32 {
		t.Fatal("dedicated injected definition key was not loaded")
	}
	values["WEAVEOS_SCHEMA_LOCK_TIMEOUT_MS"] = "0"
	if _, e = readConfig(func(k string) string { return values[k] }); e == nil {
		t.Fatal("explicit zero lock budget accepted")
	}
	delete(values, "WEAVEOS_SCHEMA_LOCK_TIMEOUT_MS")
	if _, e = readConfig(func(k string) string { return values[k] }); e == nil {
		t.Fatal("partial definition configuration accepted")
	}
}
func TestBFFCompositionExposesDefinitionWithSameSession(t *testing.T) {
	c := context.Background()
	values := map[string]string{"WEAVEOS_DATABASE_URL": os.Getenv("WEAVEOS_TEST_DATABASE_URL"), "WEAVEOS_REDIS_URL": os.Getenv("WEAVEOS_TEST_REDIS_URL"), "WEAVEOS_PUBLIC_ORIGIN": "https://weaveos.test", "WEAVEOS_SESSION_GENERATION": "v013-composition", "WEAVEOS_AUDIT_KEY_ID": "test", "WEAVEOS_AUDIT_HMAC_KEY": base64.StdEncoding.EncodeToString([]byte("synthetic-audit-key-32-bytes-only!")), "WEAVEOS_DEFINITION_HMAC_KEY": base64.StdEncoding.EncodeToString([]byte("isolated-definition-test-32bytes!")), "WEAVEOS_DEFINITION_KEY_ID": "test", "WEAVEOS_SCHEMA_LOCK_TIMEOUT_MS": "1000", "WEAVEOS_SCHEMA_STATEMENT_TIMEOUT_MS": "5000"}
	cfg, e := readConfig(func(k string) string { return values[k] })
	if e != nil {
		t.Fatal(e)
	}
	p, e := pgxpool.New(c, cfg.DatabaseURL)
	if e != nil {
		t.Fatal(e)
	}
	defer p.Close()
	roles, e := os.ReadFile("../../../../infra/runtime/roles.sql")
	if e != nil {
		t.Fatal(e)
	}
	if _, e = p.Exec(c, string(roles)); e != nil {
		t.Fatal(e)
	}
	// Compose the service using the actual restricted runtime role, while the
	// separate fixture connection owns isolated setup and source application.
	runtimeURL, e := url.Parse(cfg.DatabaseURL)
	if e != nil {
		t.Fatal(e)
	}
	query := runtimeURL.Query()
	query.Set("options", "-c role=auth_app")
	runtimeURL.RawQuery = query.Encode()
	cfg.DatabaseURL = runtimeURL.String()
	var actor, app, operation string
	e = p.QueryRow(c, "INSERT INTO auth.users(account) VALUES('definition-composition-'||gen_random_uuid()) RETURNING id::text,gen_random_uuid()::text").Scan(&actor, &operation)
	if e != nil {
		t.Fatal(e)
	}
	e = p.QueryRow(c, "INSERT INTO applications.apps(name,owner_user_id) VALUES('composition',$1) RETURNING id::text", actor).Scan(&app)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = p.Exec(c, "INSERT INTO applications.menu_resources VALUES($1,'application',$1)", app); e != nil {
		t.Fatal(e)
	}
	if _, e = p.Exec(c, "SELECT applications.register_catalog_entry($1)", app); e != nil {
		t.Fatal(e)
	}
	store := session.NewStore(cfg.RedisURL, cfg.Generation)
	defer store.Close()
	sid, csrf, e := store.Create(c, session.Record{UserID: actor, SessionRef: operation, AuthVersion: "1"})
	if e != nil {
		t.Fatal(e)
	}
	defer store.Revoke(c, sid)
	h, close, e := buildHandler(c, cfg)
	if e != nil {
		t.Fatal(e)
	}
	defer close()
	request := func(method, path, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, cfg.Origin+"/api/v1/applications/"+app+path, strings.NewReader(body))
		r.Header.Set("Origin", cfg.Origin)
		r.Header.Set("Content-Type", "application/json")
		r.Header.Set("X-CSRF-Token", csrf)
		r.AddCookie(&http.Cookie{Name: session.SessionCookieName, Value: sid})
		r.AddCookie(&http.Cookie{Name: session.CSRFCookieName, Value: csrf})
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		return w
	}
	w := request("GET", "/structure", "")
	if w.Code != 200 {
		t.Fatalf("composed definition read %d %s", w.Code, w.Body.String())
	}
	w = request("POST", "/forms", `{"operationId":"`+operation+`","name":"表单","source":{"kind":"new_table"},"directoryId":null,"position":0,"expectedStructureVersion":0}`)
	if w.Code != 201 {
		t.Fatalf("composed definition create %d %s", w.Code, w.Body.String())
	}
	var out struct {
		Data struct{ Form struct{ ID string } }
	}
	json.Unmarshal(w.Body.Bytes(), &out)
	var saveID string
	p.QueryRow(c, "SELECT gen_random_uuid()::text").Scan(&saveID)
	var fieldID string
	p.QueryRow(c, "SELECT gen_random_uuid()::text").Scan(&fieldID)
	w = request("PUT", "/forms/"+out.Data.Form.ID+"/definition", `{"operationId":"`+saveID+`","expectedSchemaVersion":0,"expectedViewVersion":0,"fields":[{"id":"`+fieldID+`","name":"标题","kind":"text","required":false,"default":null,"config":{"maxLength":null},"presentation":{"helpText":null,"displayTimeZone":null}}],"layout":[],"optionMappings":[],"confirmationToken":null}`)
	if w.Code != 200 {
		t.Fatalf("composed actual Save %d %s", w.Code, w.Body.String())
	}
	newID := func() string {
		var id string
		if e := p.QueryRow(c, "SELECT gen_random_uuid()::text").Scan(&id); e != nil { t.Fatal(e) }
		return id
	}
	root := "/forms/"+out.Data.Form.ID
	t.Run("record HTTP and atomic history",func(t *testing.T) {
		createID := newID()
		body := `{"operationId":"`+createID+`","expectedSchemaVersion":1,"values":{"`+fieldID+`":"alpha"}}`
		w := request("POST",root+"/records",body)
		if w.Code != 201 { t.Fatalf("published record create want201 got%d %s",w.Code,w.Body.String()) }
		var mutation struct{Data struct{ID string; RecordVersion,SchemaVersion int64}}
		if e:=json.Unmarshal(w.Body.Bytes(),&mutation); e!=nil {t.Fatal(e)}
		id:=mutation.Data.ID
		if id=="" || mutation.Data.RecordVersion!=1 || mutation.Data.SchemaVersion!=1 || !strings.HasSuffix(w.Header().Get("Location"),"/records/"+id) {t.Fatalf("exact create response %s",w.Body.String())}
		w=request("GET",root+"/records/"+id,"")
		if w.Code!=200 || !strings.Contains(w.Body.String(),`"alpha"`) || !strings.Contains(w.Body.String(),`"appId":"`+app+`"`) {t.Fatalf("same RR record read %d %s",w.Code,w.Body.String())}
		w=request("POST",root+"/records/search",`{"page":1,"pageSize":20,"filter":null,"sort":null}`)
		if w.Code!=200 {t.Fatalf("actual search %d %s",w.Code,w.Body.String())}
		var page struct {Data struct {Total int64; QueryVersion string}}
		if json.Unmarshal(w.Body.Bytes(),&page)!=nil || page.Data.Total!=1 || page.Data.QueryVersion=="" {t.Fatalf("complete query page %s",w.Body.String())}
		w=request("PATCH",root+"/records/"+id,`{"operationId":"`+newID()+`","expectedSchemaVersion":1,"expectedRecordVersion":1,"queryVersion":"`+page.Data.QueryVersion+`","changes":{"`+fieldID+`":"beta"}}`)
		if w.Code!=200 {t.Fatalf("actual edit %d %s",w.Code,w.Body.String())}
		w=request("POST",root+"/records",body)
		if w.Code!=201 || strings.Contains(w.Body.String(),`"alpha"`) || strings.Contains(w.Body.String(),`"beta"`) {t.Fatalf("minimum confirmed replay %d %s",w.Code,w.Body.String())}
		w=request("GET",root+"/records/"+id+"/history","")
		if w.Code!=200 || !strings.Contains(w.Body.String(),`"alpha"`) || !strings.Contains(w.Body.String(),`"beta"`) {t.Fatalf("real same-Tx history %d %s",w.Code,w.Body.String())}
		var count int
		if e:=p.QueryRow(c,"SELECT count(*) FROM applications.record_change_events WHERE app_id=$1 AND record_id=$2",app,id).Scan(&count);e!=nil||count!=2 {t.Fatalf("actual history events %d %v",count,e)}
	})
	t.Run("draft HTTP remains separate from records",func(t *testing.T) {
		w:=request("POST",root+"/drafts",`{"operationId":"`+newID()+`","targetRecordId":null,"schemaVersion":1,"baseRecordVersion":null,"values":{"`+fieldID+`":"unfinished"}}`)
		if w.Code!=201 {t.Fatalf("actual draft create %d %s",w.Code,w.Body.String())}
		var draft struct {Data struct {ID string;DraftVersion int64}}
		if json.Unmarshal(w.Body.Bytes(),&draft)!=nil || draft.Data.ID=="" || draft.Data.DraftVersion!=1 {t.Fatalf("draft response %s",w.Body.String())}
		path:=root+"/drafts/"+draft.Data.ID
		w=request("GET",path,"")
		if w.Code!=200 || !strings.Contains(w.Body.String(),`"unfinished"`) {t.Fatalf("draft read %d %s",w.Code,w.Body.String())}
		w=request("PATCH",path,`{"operationId":"`+newID()+`","expectedDraftVersion":1,"changes":{},"removeFieldIds":["`+fieldID+`"]}`)
		if w.Code!=200 || strings.Contains(w.Body.String(),`"unfinished"`) {t.Fatalf("draft sparse remove %d %s",w.Code,w.Body.String())}
		w=request("GET",root+"/drafts?pageSize=1","")
		if w.Code!=200 || !strings.HasPrefix(strings.TrimSpace(w.Body.String()),`{"code":"OK"`) || !strings.Contains(w.Body.String(),`"pagination"`) {t.Fatalf("draft list envelope %d %s",w.Code,w.Body.String())}
		query:=path+"?operationId="+newID()+"&expectedDraftVersion=2"
		w=request("DELETE",query,"")
		if w.Code!=204 || w.Body.Len()!=0 {t.Fatalf("discard must be204 bodyless %d %s",w.Code,w.Body.String())}
		w=request("DELETE",query,"")
		if w.Code!=204 || w.Body.Len()!=0 {t.Fatalf("discard replay204 %d %s",w.Code,w.Body.String())}
	})
	t.Run("ordinary runtime uses registered form tuple",func(t *testing.T) {
		var member,group,grant,table string
		if e:=p.QueryRow(c,"INSERT INTO auth.users(account) VALUES('ordinary-composition-'||gen_random_uuid()) RETURNING id::text").Scan(&member);e!=nil{t.Fatal(e)}
		if e:=p.QueryRow(c,"INSERT INTO applications.permission_groups(app_id,name) VALUES($1,'ordinary') RETURNING id::text",app).Scan(&group);e!=nil{t.Fatal(e)}
		if _,e:=p.Exec(c,"INSERT INTO applications.group_members(app_id,group_id,user_id) VALUES($1,$2,$3)",app,group,member);e!=nil{t.Fatal(e)}
		if _,e:=p.Exec(c,"INSERT INTO applications.grants(app_id,group_id,resource_kind,resource_id,action,row_scope) VALUES($1,$2,'form',$3,'menu.enter','all')",app,group,out.Data.Form.ID);e!=nil{t.Fatal(e)}
		if e:=p.QueryRow(c,"INSERT INTO applications.grants(app_id,group_id,resource_kind,resource_id,action,row_scope) VALUES($1,$2,'form',$3,'data.read','own') RETURNING id::text",app,group,out.Data.Form.ID).Scan(&grant);e!=nil{t.Fatal(e)}
		if e:=p.QueryRow(c,"SELECT table_id::text FROM applications.form_views WHERE id=$1",out.Data.Form.ID).Scan(&table);e!=nil{t.Fatal(e)}
		if _,e:=p.Exec(c,"INSERT INTO applications.grant_fields(app_id,grant_id,table_id,field_id) VALUES($1,$2,$3,$4)",app,grant,table,fieldID);e!=nil{t.Fatal(e)}
		memberSID,memberCSRF,e:=store.Create(c,session.Record{UserID:member,SessionRef:newID(),AuthVersion:"1"});if e!=nil{t.Fatal(e)}
		defer store.Revoke(c,memberSID)
		r:=httptest.NewRequest("GET",cfg.Origin+"/api/v1/applications/"+app+root+"/runtime",nil)
		r.AddCookie(&http.Cookie{Name:session.SessionCookieName,Value:memberSID})
		r.AddCookie(&http.Cookie{Name:session.CSRFCookieName,Value:memberCSRF})
		w:=httptest.NewRecorder();h.ServeHTTP(w,r)
		if w.Code!=200 || !strings.Contains(w.Body.String(),`"read":"own"`) || strings.Contains(w.Body.String(),`"create":true`) {t.Fatalf("ordinary runtime actual grant projection %d %s",w.Code,w.Body.String())}
	})
}
