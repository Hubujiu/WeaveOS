package appstructure

import (
	"encoding/json"
	"net/http"
)

// Decode only the closed public envelope; V015 owns field normalization,
// live tuple policy and the query compiler.
func decodeRecord(w http.ResponseWriter,r *http.Request,kind string) (map[string]json.RawMessage,error) {
	return nil,invalid()
}
