package appstructure

import (
	"context"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/applications"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/session"
	"github.com/jackc/pgx/v5"
	"time"
)

type RecordGate struct{ AppID, TableID, ViewID string }

func (RecordGate) LockTable(context.Context, pgx.Tx, string, int64) error {
	return session.ErrUnavailable
}

type RecordFence struct{ AppID, TableID string }

func (RecordFence) Check(context.Context, pgx.Tx, string, string, int64) error {
	return session.ErrUnavailable
}

type RecordMutationResult struct {
	OperationID   string    `json:"operationId"`
	ID            string    `json:"id"`
	RecordVersion int64     `json:"recordVersion"`
	SchemaVersion int64     `json:"schemaVersion"`
	CreatedAt     time.Time `json:"createdAt"`
	UpdatedAt     time.Time `json:"updatedAt"`
}
type RecordAudit struct {
	Context             applications.RecordContext
	OperationID         string
	BeforeRecordVersion int64
	Metadata            applications.Metadata
}

func (RecordAudit) Append(context.Context, pgx.Tx, RecordMutationResult, string, []string) error {
	return session.ErrUnavailable
}
