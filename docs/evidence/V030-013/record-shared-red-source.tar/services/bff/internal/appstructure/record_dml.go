package appstructure

import (
	"context"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/session"
	"github.com/jackc/pgx/v5"
	"time"
)

// These neutral shapes mirror V015's fixed TypedDML port without importing or
// modifying its exclusive core package. V015 can use ordinary Go conversions.
type RecordTable struct {
	AppID, TableID, ViewID, Namespace string
	SchemaVersion                     int64
	Ready                             bool
	ActiveFieldIDs                    []string
}
type RecordCreate struct {
	OperationID, ID, ActorID string
	ExpectedSchemaVersion    int64
	Values                   map[string]any
}
type RecordEdit struct {
	OperationID, ID, ActorID                     string
	ExpectedSchemaVersion, ExpectedRecordVersion int64
	Changes                                      map[string]any
}
type StoredRecordHeader struct {
	ID, CreatedBy        string
	RecordVersion        int64
	CreatedAt, UpdatedAt time.Time
}
type RecordDML struct{}

func (RecordDML) Insert(context.Context, pgx.Tx, RecordTable, RecordCreate, []string) (StoredRecordHeader, error) {
	return StoredRecordHeader{}, session.ErrUnavailable
}
func (RecordDML) LockHeader(context.Context, pgx.Tx, RecordTable, string) (StoredRecordHeader, error) {
	return StoredRecordHeader{}, session.ErrUnavailable
}
func (RecordDML) UpdateCAS(context.Context, pgx.Tx, RecordTable, RecordEdit, []string) (StoredRecordHeader, error) {
	return StoredRecordHeader{}, session.ErrUnavailable
}
