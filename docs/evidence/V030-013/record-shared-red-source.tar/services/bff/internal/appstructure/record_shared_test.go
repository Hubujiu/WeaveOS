package appstructure

import (
	"context"
	"errors"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/applications"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/session"
	"github.com/jackc/pgx/v5"
	"testing"
	"time"
)

func TestNonManagerRecordTransactionResolvesActualResourcesAndSession(t *testing.T) {
	owner, ordinary := setup(t), setup(t)
	view, table := newForm(t, owner)
	opts := applications.RecordWriteOptions{LockTimeout: time.Second, StatementTimeout: 5 * time.Second, OperationID: uuid(t, owner.owner), Kind: "record.create", Authorize: func(context.Context, pgx.Tx, applications.RecordContext) error { return applications.ErrDenied }}
	app := &applications.Application{Pool: ordinary.runtime}
	p := session.Principal{UserID: ordinary.actor, Record: session.Record{AuthVersion: "1"}}
	write, e := app.BeginRecordWrite(context.Background(), p, owner.app, view, opts)
	if e != nil {
		t.Fatalf("trusted ordinary Session must resolve real resource without manager gate: %v", e)
	}
	defer write.Rollback(context.Background())
	facts := write.Context()
	if facts.Actor.ID != ordinary.actor || facts.App.ID != owner.app || facts.TableID != table || facts.ViewID != view || facts.App.OwnerUserID != owner.actor {
		t.Fatalf("trusted current facts: %+v", facts)
	}
	if e := write.Claim(context.Background(), opts.OperationID, opts.Kind, opts.Fingerprint); !errors.Is(e, applications.ErrDenied) {
		t.Fatalf("disconnected ordinary action must deny before operation claim: %v", e)
	}
	write.Rollback(context.Background())
	p.Record.AuthVersion = "2"
	if write, e := app.BeginRecordWrite(context.Background(), p, owner.app, view, opts); !errors.Is(e, session.ErrUnauthorized) {
		if write != nil {
			write.Rollback(context.Background())
		}
		t.Fatalf("live Session version must be rechecked: %v", e)
	}
	p.Record.AuthVersion = "1"
	if write, e := app.BeginRecordWrite(context.Background(), p, ordinary.app, view, opts); !errors.Is(e, applications.ErrMissing) {
		if write != nil {
			write.Rollback(context.Background())
		}
		t.Fatalf("cross-app form must not resolve: %v", e)
	}
}

func TestRecordSharedMigrationRelationsAreReal(t *testing.T) {
	f := setup(t)
	for _, name := range []string{"record_drafts", "record_write_audit", "record_command_fences", "member_sources", "department_sources", "member_department_sources", "reference_source_revision"} {
		var exists bool
		if e := f.owner.QueryRow(context.Background(), "SELECT to_regclass($1) IS NOT NULL", "applications."+name).Scan(&exists); e != nil {
			t.Fatal(e)
		}
		if !exists {
			t.Errorf("frozen shared relation %s is absent", name)
		}
	}
}

func TestControlledRecordDMLWritesNativeValuesAndProtectsSystemAndCAS(t *testing.T) {
	f := setup(t)
	view, table := newForm(t, f)
	money := field(t, f, "money", nil, map[string]any{})
	text := field(t, f, "text", "default literal", map[string]any{"maxLength": 20})
	data(t, f.call(t, "PUT", "/forms/"+view+"/definition", input(t, f, 0, 0, money, text)), 200)
	resource := RecordTable{AppID: f.app, TableID: table, ViewID: view, Namespace: "appdata", SchemaVersion: 1, Ready: true, ActiveFieldIDs: []string{money["id"].(string), text["id"].(string)}}
	ctx := context.Background()
	tx, e := f.runtime.Begin(ctx)
	if e != nil {
		t.Fatal(e)
	}
	defer tx.Rollback(ctx)
	id := uuid(t, f.owner)
	native := RecordDML{}
	header, e := native.Insert(ctx, tx, resource, RecordCreate{OperationID: uuid(t, f.owner), ID: id, ActorID: f.actor, ExpectedSchemaVersion: 1, Values: map[string]any{money["id"].(string): "1.20"}}, []string{money["id"].(string)})
	if e != nil {
		t.Fatalf("real restricted native insert must work: %v", e)
	}
	if header.ID != id || header.CreatedBy != f.actor || header.RecordVersion != 1 || header.CreatedAt.IsZero() || !header.CreatedAt.Equal(header.UpdatedAt) {
		t.Fatalf("protected create header %+v", header)
	}
	var amount, label string
	if e := tx.QueryRow(ctx, "SELECT "+columnPhysical(money["id"].(string))+"::text,"+columnPhysical(text["id"].(string))+" FROM "+tablePhysical(table)+" WHERE id=$1", id).Scan(&amount, &label); e != nil || amount != "1.20" || label != "default literal" {
		t.Fatal("typed values/defaults", amount, label, e)
	}
	next, e := native.UpdateCAS(ctx, tx, resource, RecordEdit{OperationID: uuid(t, f.owner), ID: id, ActorID: f.actor, ExpectedSchemaVersion: 1, ExpectedRecordVersion: 1, Changes: map[string]any{money["id"].(string): "-2.50"}}, []string{money["id"].(string)})
	if e != nil || next.RecordVersion != 2 || next.CreatedBy != f.actor || !next.CreatedAt.Equal(header.CreatedAt) {
		t.Fatal("native update must preserve creator and increment CAS", next, e)
	}
	locked, e := native.LockHeader(ctx, tx, resource, id)
	if e != nil || locked.RecordVersion != 2 {
		t.Fatal("controlled row lock must work without broad UPDATE grant", locked, e)
	}
	if _, e = native.UpdateCAS(ctx, tx, resource, RecordEdit{OperationID: uuid(t, f.owner), ID: id, ActorID: f.actor, ExpectedSchemaVersion: 1, ExpectedRecordVersion: 1, Changes: map[string]any{}}, []string{}); e == nil {
		t.Fatal("stale CAS must reject")
	}
}
