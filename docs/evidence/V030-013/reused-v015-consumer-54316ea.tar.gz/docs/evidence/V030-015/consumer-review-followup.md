# V030-015 consumer review follow-up · 2026-10-03

This checkpoint extends isolated branch `task/V030-015-records-query-drafts`
after `24d7be1`. It changes only V015-owned `apprecordservice`, `appdrafts`,
task documentation and evidence. It does not change V013-owned HTTP,
OpenAPI, migrations, roles or controlled DML.

| Review finding | Correction and real PostgreSQL/Redis evidence |
| --- | --- |
| A stale schema/base draft could not explicitly remove an old key | `UpdateDraft` permits only a nonempty `removeFieldIds` with empty `changes` across the stale binding. `Store.UpdateInTx` requires every removed key to exist in this Session owner's locked draft; schema/base bindings remain unchanged and the response retains conflicts without old values. New values still fail. Physical field drop, simultaneous schema/base conflict, revoked grant and same-transaction operation/audit checks are in [RED](consumer-draft-conflict-cleanup-red.txt) and [GREEN](consumer-draft-conflict-cleanup-green.txt). |
| Omitted member/department defaults bypassed active-source checks | Create now checks the effective reference from an explicit value or current schema default under `BeginRecordWrite`'s source revision lock. The physical DB default remains server-applied; a caller needs no create mask on the defaulted field. Active default, disabled default with zero new row/audit/confirmed operation, and preservation of an unchanged old reference are in [RED](consumer-default-reference-red.txt) and [GREEN](consumer-default-reference-green.txt). [Race evidence](consumer-default-source-race.txt) observes the create blocked on the source writer's revision lock, then rejecting after that writer commits disabled status. |
| A removed saved quick-search field returned invalid/forbidden instead of query changed | Saved criteria check current field existence before checking its current grant. Missing/kind-changed saved fields return `querycontext.ErrChanged`; a retained field with revoked read permission remains forbidden; invalid incoming criteria remain invalid. [RED](consumer-quick-schema-red.txt), [GREEN](consumer-quick-schema-green.txt). |
| Redis Advance failed after the RR receipt committed, preventing original-key recovery | Both RR validation and post-RR Redis Advance failures now take a **replay-only** V013 live-Session/actor/key/kind/fingerprint path. A confirmed operation returns its minimum result; an absent operation returns the original read error. No Claim or business DML occurs in this fallback. Confirmed, unconfirmed and inactive-Session cases are in [RED](consumer-advance-replay-red.txt) and [GREEN](consumer-advance-replay-green.txt). |
| Create/read/edit conflated authorized schema-not-ready with denial or generic unavailable | Live menu and action grants run first. Authorized not-ready returns `APPLICATION_SCHEMA_NOT_READY` across create, edit, search and detail; unauthorized access remains denied. Create [RED](consumer-notready-red.txt)/[GREEN](consumer-notready-green.txt), read/edit [RED](consumer-read-edit-notready-red.txt)/[GREEN](consumer-read-edit-notready-green.txt). |
| Empty edit skipped the action precheck and leaked schema readiness | Edit now requires a real current `data.edit` action tuple (or owner/bootstrap authority) before checking readiness, including an empty changes map. The Writer still checks the target's immutable `createdBy` after row lock, so an own-scope grant does not authorize another row. Menu-only ready/not-ready, own-scope foreign row and own-row empty PATCH are in [RED](consumer-empty-edit-action-red.txt) and [GREEN](consumer-empty-edit-action-green.txt). |
| The service record DTO omitted frozen identity/control fields | Both page items and detail now return `appId`, `tableId`, `viewId` and same-RR `schemaVersion`. The page also returns `page`, `pageSize` and canonical `sort`. The full-P fingerprint still excludes schema control versions. [RED](consumer-record-dto-red.txt), [GREEN](consumer-record-dto-green.txt). |
| Reference `EXISTS` in the predicate hid missing registry rows before integrity checking | Reference UUID equality now evaluates on the typed column. A separate authorization/mask-conditioned integrity check runs before Observe COUNT, and page hydration fails if a visible page reference has no source row. A retained tombstone still matches and displays `deleted=true`. [RED](consumer-reference-integrity-red.txt), [GREEN](consumer-reference-integrity-green.txt). |

The V013 Save port updates `logical_tables.fields_json` and physical column
defaults in one table-gated transaction. V015 checks those trusted metadata
defaults before controlled DML while the PR21 personnel/source revision locks
are held. For defense in depth, V013 can assert metadata/physical default
parity in its controlled `RecordDML.Insert` port or expose the effective
default reference set from the same gated transaction; V015 did not change
that shared port. It must not require the caller to send defaults or use the
caller field mask as a substitute for source validation.

The [service COMMIT boundary tests](consumer-commit-boundary-green.txt) use
the same actual PostgreSQL wire-frame seam as V013's application tests. A
test-only connection drops the reply after reading the server's successful
`COMMIT` tag. The service returns `applications.ErrUnconfirmed`; the separate
normal connection sees one typed row, the draft consumed, one audit row and
one confirmed minimum operation result. GET Operation and replay with the
original key return the same result without repeating work. Reusing the key
with a changed body returns `ErrOperationConflict`. A second test injects
`SELECT 1/0` in the real transaction just before COMMIT: PostgreSQL reports
`pgx.ErrTxCommitRollback`, the draft remains, and no row/audit/operation is
committed; an explicit original-key retry then commits once. These tests
exercise the restricted `auth_app` service transaction, not HTTPS/CSRF or
browser handling. They passed on first run and therefore have no fabricated
RED stage. No production fault hook or shared V013 file was changed.

The combined [V015 core race suite](consumer-followup-core-race.txt) passed
against PostgreSQL 18.6 with runtime `SET ROLE auth_app` and Redis. The
[BFF-wide follow-up](consumer-followup-bff-race-shared-skip.txt) retains one
explicit skip for the V013-owned B5 disabled-member test. Its old oracle
expects acceptance of a newly inactive member, while the frozen newer policy
requires active members; V013 owns that oracle repair. A skip is not a fully
green BFF gate.

Shared HTTP/OpenAPI/config/history wiring, real Session/CSRF and browser API
acceptance, and the broad
million-row × 200-context full-chain capacity gate remain open. No compact
algorithm or timeout substitution was made.
