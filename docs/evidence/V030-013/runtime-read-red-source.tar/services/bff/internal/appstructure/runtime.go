package appstructure

import (
	"context"
	"encoding/json"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/appfields"
	"github.com/Hubujiu/WeaveOS/services/bff/internal/applications"
	"github.com/jackc/pgx/v5"
)

// ResolveRecordAccess is injected by the V015 policy consumer. Facts and Tx
// originate from live Session/resource reads, never from HTTP JSON.
type ResolveRecordAccess func(context.Context, pgx.Tx, applications.RecordContext) (RecordAccess, error)
type FieldAccess struct {
	Read string `json:"read"`
	Create bool `json:"create"`
	Edit string `json:"edit"`
	History string `json:"-"`
}
type RecordAccess struct {
	MenuEnter, Create bool
	Read, Edit, History string
	Fields map[string]FieldAccess
}
type RuntimeInput struct {
	Decimal *appfields.DecimalConfig `json:"decimal,omitempty"`
	TimePrecision string `json:"timePrecision,omitempty"`
	Options *[]appfields.Option `json:"options,omitempty"`
	ReferenceKind string `json:"referenceKind,omitempty"`
}
type RuntimeQuery struct {
	Operators []string `json:"operators"`
	Sortable bool `json:"sortable"`
	QuickSearchable bool `json:"quickSearchable"`
}
type RuntimeField struct {
	ID string `json:"id"`
	Name string `json:"name"`
	Kind string `json:"kind"`
	Required bool `json:"required"`
	Presentation appfields.Presentation `json:"presentation"`
	Input RuntimeInput `json:"input"`
	Default json.RawMessage `json:"default,omitempty"`
	Access FieldAccess `json:"access"`
	Query RuntimeQuery `json:"query"`
}
type RuntimeCapabilities struct {
	Create bool `json:"create"`
	Read string `json:"read"`
	Edit string `json:"edit"`
	Search bool `json:"search"`
	DraftCreate bool `json:"draftCreate"`
	DraftEdit bool `json:"draftEdit"`
}
type RuntimeView struct {
	AppID string `json:"appId"`
	TableID string `json:"tableId"`
	ViewID string `json:"viewId"`
	SchemaVersion int64 `json:"schemaVersion"`
	ViewVersion int64 `json:"viewVersion"`
	PolicyRevision int64 `json:"policyRevision"`
	Fields []RuntimeField `json:"fields"`
	Layout []appfields.LayoutNode `json:"layout"`
	Capabilities RuntimeCapabilities `json:"capabilities"`
}
func ProjectRuntime(facts applications.RecordContext, access RecordAccess) (RuntimeView,error) {
	return RuntimeView{}, ErrUnavailable
}
