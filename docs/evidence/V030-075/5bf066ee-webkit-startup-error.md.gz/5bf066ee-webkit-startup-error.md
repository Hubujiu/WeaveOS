# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: q36-b2.component.spec.ts >> Q36 B2 real member page uses POST typed filter and old context without text sorting
- Location: apps/web/src/q36-b2.component.spec.ts:52:1

# Error details

```
"beforeAll" hook timeout of 15000ms exceeded.
```

# Test source

```ts
  1   | import {writeFile} from 'node:fs/promises';
  2   | import {test,expect,type Page,type Route,type Request} from '@playwright/test';
  3   | 
  4   | // Prepare only the browser engine, outside each unchanged business-test budget.
  5   | // No app navigation or shared context: the normal page fixture stays isolated.
> 6   | test.beforeAll(async ({browser})=>{
      |      ^ "beforeAll" hook timeout of 15000ms exceeded.
  7   |  const context=await browser.newContext();
  8   |  try {
  9   |   const page=await context.newPage();
  10  |   await page.goto('about:blank');
  11  |  } finally {
  12  |   await context.close();
  13  |  }
  14  | });
  15  | 
  16  | const id='00000000-0000-4000-8000-000000000001';
  17  | const identityId='00000000-0000-4000-8000-000000000002';
  18  | const draftId='00000000-0000-4000-8000-000000000009';
  19  | const user={id,account:'q36-admin'};
  20  | const member={...user,status:'active',bootstrapAdmin:true,version:0,departmentIds:[],identityIds:[],departments:[],identities:[],permissions:[]};
  21  | const identity={id:identityId,name:'测试身份',description:'原说明',version:1,templateIds:[],permissionCodes:[],affectedMembers:0,affectedIdentities:0};
  22  | const envelope=(data:unknown)=>({code:'OK',message:'success',data,meta:null});
  23  | const paging=(items:unknown[],input:{page?:number;pageSize?:number}={})=>({items,total:100,page:input.page??1,pageSize:input.pageSize??20,queryVersion:'context-'+(input.page??1),sort:null});
  24  | async function fixture(page:Page){
  25  |  let preset:Record<string,unknown>|null=null;
  26  |  await page.route('**/api/v1/**',async r=>{
  27  |   const path=new URL(r.request().url()).pathname.replace('/api/v1/','');
  28  |   if(path.startsWith('personnel/table-presets')){if(r.request().method()==='POST'){preset={...r.request().postDataJSON(),id:draftId,version:1,createdAt:'2026-10-02T03:00:00Z',updatedAt:'2026-10-02T03:00:00Z'};return r.fulfill({status:201,json:envelope(preset)});}return r.fulfill({json:envelope(path==='personnel/table-presets'?{items:preset?[preset]:[]}:preset)});}
  29  |   const data=path==='sessions/current'?user:path==='me/access'?{user,bootstrapAdmin:true,personnelManage:true,identities:[],permissions:[],applications:[]}:
  30  |    path==='personnel/departments'?{items:[]}:path==='personnel/permissions'?{items:[]}:
  31  |    path==='personnel/identities'?{items:[identity],total:1,page:1,pageSize:20}:path==='personnel/identities/'+identityId?identity:
  32  |    path==='personnel/templates'?{items:[],total:0,page:1,pageSize:20}:path==='personnel/members/'+id?member:
  33  |    path==='personnel/members'||path==='personnel/members/search'?paging([member]):
  34  |    path==='personnel/events'||path==='personnel/events/search'?{...paging([]),range:{from:'2026-09-24T00:00:00Z',to:'2026-10-02T00:00:00Z'}}:
  35  |    path==='personnel/drafts'?{items:[]}:{};
  36  |   await r.fulfill({json:envelope(data)});
  37  |  });
  38  | }
  39  | async function admin(page:Page){await page.goto('/app/admin');await expect(page.getByRole('tab',{name:'成员与部门',exact:true})).toBeVisible();}
  40  | async function condition(page:Page,wait=true){
  41  |  await page.getByRole('button',{name:'自定义筛选',exact:true}).click();
  42  |  const panel=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await expect(panel).toBeVisible();
  43  |  await panel.getByRole('button',{name:'新增筛选',exact:true}).click();const editor=page.getByRole('dialog',{name:'新增自定义筛选',exact:true});
  44  |  await editor.getByLabel('自定义筛选名称',{exact:true}).fill('Q36 回归方案');await editor.getByRole('button',{name:'或条件',exact:true}).click();await editor.getByLabel('条件 1.1 值',{exact:true}).fill('q36-admin');await editor.getByRole('button',{name:'确定',exact:true}).click();
  45  |  await panel.getByRole('button',{name:'应用Q36 回归方案',exact:true}).click();
  46  |  if(wait){await expect(panel.getByRole('button',{name:'关闭筛选管理',exact:true})).toBeEnabled();await panel.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(panel).toBeHidden();}
  47  | }
  48  | async function cancelCondition(page:Page){
  49  |  await page.getByRole('button',{name:'自定义筛选，已应用',exact:true}).click();const p=page.getByRole('dialog',{name:'管理自定义筛选',exact:true});await p.getByRole('button',{name:'取消应用',exact:true}).click();await page.getByRole('dialog',{name:'取消当前筛选',exact:true}).getByRole('button',{name:'确认取消',exact:true}).click();await expect(p.getByRole('button',{name:'关闭筛选管理',exact:true})).toBeEnabled();await p.getByRole('button',{name:'关闭筛选管理',exact:true}).click();await expect(p).toBeHidden();
  50  | }
  51  | 
  52  | test('Q36 B2 real member page uses POST typed filter and old context without text sorting',async({page})=>{
  53  |  await fixture(page);const requests:Record<string,unknown>[]=[];
  54  |  await page.route('**/personnel/members/search',r=>{expect(r.request().method()).toBe('POST');const input=r.request().postDataJSON();requests.push(input);return r.fulfill({json:envelope(paging([member],input))});});
  55  |  await admin(page);await expect.poll(()=>requests.length).toBeGreaterThan(0);
  56  |  await expect(page.locator('.member-table th[aria-sort]')).toHaveCount(0);
  57  |  await condition(page);await expect.poll(()=>requests.at(-1)?.filter).toEqual({operator:'and',children:[{field:'account',operator:'eq',value:'q36-admin'}]});
  58  |  expect(requests.at(-1)?.queryVersion).toBe('context-1');
  59  |  await page.getByLabel('跳至页',{exact:true}).fill('4');await page.getByLabel('跳至页',{exact:true}).press('Enter');
  60  |  await expect.poll(()=>requests.at(-1)?.page).toBe(4);
  61  | });
  62  | 
  63  | test('Q36 B2 event page uses server display and only occurredAt server ordering',async({page})=>{
  64  |  await fixture(page);const requests:Record<string,unknown>[]=[];
  65  |  const event={id,occurredAt:'2026-10-01T00:00:00Z',actorAccount:'other-account',action:'MEMBER_IDENTITIES_UPDATED',outcome:'success',objectType:'member',objectId:id,summary:null,display:{action:'后端操作',object:'当前页之外的成员',detail:'后端安全摘要',outcome:'已完成'}};
  66  |  await page.route('**/personnel/events/search',r=>{const input=r.request().postDataJSON();requests.push(input);return r.fulfill({json:envelope({...paging([event],input),sort:{key:'occurredAt',direction:input.sortDirection??'desc'},range:{from:'2026-09-24T00:00:00Z',to:'2026-10-02T00:00:00Z'}})});});
  67  |  await admin(page);await page.getByRole('tab',{name:'操作记录',exact:true}).click();
  68  |  await expect(page.locator('.activity-table')).toContainText('当前页之外的成员');await expect(page.locator('.activity-table')).toContainText('后端安全摘要');
  69  |  await page.getByRole('button',{name:'排序 occurredAt',exact:true}).click();await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  70  |  await expect.poll(()=>requests.at(-1)?.sortDirection).toBe('asc');expect(requests.at(-1)?.sortBy).toBe('occurredAt');expect(requests.at(-1)?.queryVersion).toBeTruthy();
  71  |  expect(await page.locator('.activity-table th[aria-sort]').count()).toBe(1);
  72  |  const prior=requests.length;
  73  |  await page.getByRole('button',{name:'排序 occurredAt',exact:true}).click();await page.getByRole('menuitem',{name:'升序',exact:true}).click();
  74  |  await expect.poll(()=>requests.length).toBeGreaterThan(prior);
  75  |  expect(requests.at(-1)?.sortBy).toBeUndefined();expect(requests.at(-1)?.sortDirection).toBeUndefined();
  76  |  expect(requests.at(-1)?.queryVersion).toBeTruthy();expect(requests.at(-1)?.from).toBe('2026-09-24T00:00:00Z');expect(requests.at(-1)?.to).toBe('2026-10-02T00:00:00Z');
  77  |  await expect(page.locator('.activity-table th[aria-sort]')).toHaveCount(0);
  78  | });
  79  | 
  80  | test('Q36 B2 restored invalid identity reference remains editable until explicitly resolved',async({page})=>{
  81  |  await fixture(page);const missing='00000000-0000-4000-8000-000000000088';
  82  |  const stored={id:draftId,kind:'member-identities',targetId:id,baseVersion:0,version:1,createdAt:'2026-10-01T00:00:00Z',updatedAt:'2026-10-01T00:00:00Z',payload:{identityIds:[missing]}};
  83  |  await page.route('**/personnel/drafts',r=>r.fulfill({json:envelope({items:[stored]})}));await page.route('**/personnel/drafts/'+draftId,r=>r.fulfill({json:envelope(stored)}));
  84  |  await admin(page);await page.getByRole('button',{name:'草稿箱',exact:true}).click();await page.getByRole('button',{name:'恢复草稿',exact:true}).click();
  85  |  await expect(page.getByRole('alert')).toContainText('已失效引用');
  86  |  const invalid=page.getByLabel('已失效身份：'+missing,{exact:true});await expect(invalid).toBeChecked();await invalid.click();await expect(invalid).toHaveCount(0);
  87  |  await page.getByRole('button',{name:'保留当前输入，使用最新对象版本',exact:true}).click();await expect(page.getByRole('alert')).toHaveCount(0);
  88  | });
  89  | 
  90  | test('Q36 B2 modal query refresh preserves unsaved member input and original object version',async({page})=>{
  91  |  await fixture(page);await admin(page);await page.getByRole('button',{name:'配置身份',exact:true}).click();const dialog=page.getByRole('dialog',{name:'配置成员身份',exact:true});
  92  |  await dialog.getByLabel('身份：测试身份',{exact:true}).check();await dialog.getByRole('button',{name:'刷新查询',exact:true}).click();await expect(dialog.getByLabel('身份：测试身份',{exact:true})).toBeChecked();
  93  | });
  94  | 
  95  | for(const code of ['COMMON_QUERY_CHANGED','COMMON_QUERY_CONTEXT_EXPIRED'])test('Q36 B2 '+code+' requires explicit page-one refresh and clears selection',async({page})=>{
  96  |  await fixture(page);let failed=false;const requests:Record<string,unknown>[]=[];
  97  |  await page.route('**/personnel/members/search',r=>{const input=r.request().postDataJSON();requests.push(input);if(input.page===2&&!failed){failed=true;return r.fulfill({status:409,json:{code,message:'conflict',data:null,meta:null}});}return r.fulfill({json:envelope(paging([member],input))});});
  98  |  await admin(page);await page.getByLabel('选择成员：q36-admin',{exact:true}).check();
  99  |  await page.getByLabel('跳至页',{exact:true}).fill('2');await page.getByLabel('跳至页',{exact:true}).press('Enter');
  100 |  await expect(page.getByRole('alert')).toContainText(code==='COMMON_QUERY_CHANGED'?'查询结果已变化':'查询上下文已过期');
  101 |  await page.getByRole('button',{name:'刷新查询',exact:true}).click();
  102 |  await expect.poll(()=>requests.at(-1)?.page).toBe(1);expect(requests.at(-1)?.queryVersion).toBeUndefined();
  103 |  await expect(page.getByLabel('选择成员：q36-admin',{exact:true})).not.toBeChecked();
  104 | });
  105 | 
  106 | test('Q36 B2 late responses cannot overwrite the newest search',async({page})=>{
```