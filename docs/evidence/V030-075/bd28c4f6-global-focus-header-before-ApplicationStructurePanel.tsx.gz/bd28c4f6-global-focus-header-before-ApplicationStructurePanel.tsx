import {StructureDeletionDialog,type StructureDeletionSelection} from './StructureDeletionDialog';
import {scopedUnconfirmed} from '../recovery';
import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {formApi,formErrorText,FormApiError,immutablePacket,validDirectoryResult,validFormResult,
  type FormWrite,type FormUpdate,type StructureWrite} from './api';
import type {Directory,FormSource,Structure,UUID} from './contracts';
import {FormsDialog} from './FormsDialog';
import {createLeaveController,type LeaveController,type LeaveGuardProps,type LeaveStatus} from './leaveGuard';
import './forms.css';

export type ApplicationStructureProps=LeaveGuardProps&{applicationPolicyRevision?:number;onApplicationDeleted?:()=>void;requestSectionLeave?:(action:()=>void)=>void;appId:string;actorId:string;onOpenForm?:(viewId:string)=>void;
  onConfigureForm?:(viewId:string)=>void;
  onDirtyChange?:(dirty:boolean)=>void;onUnauthorized?:()=>void;onIdentityMismatch?:()=>void};
type Selected={kind:'directory'|'form';id:UUID}|null;
type Dialog='directory'|'renameDirectory'|'moveDirectory'|'form'|'editForm'|null;
type Pending={operationId:UUID;run:()=>Promise<unknown>;httpStatus:200|201;matches:(result:unknown)=>boolean};
const uuid=()=>crypto.randomUUID();
const descendants=(items:Directory[],source:UUID,target:UUID|null)=>{const seen=new Set<UUID>();
  while(target){if(target===source||seen.has(target))return true;seen.add(target);target=items.find(item=>item.id===target)?.parentId??null;}return false;};
const position=(items:{position:number}[])=>Math.max(-1,...items.map(item=>item.position))+1;
type StructureSnapshot={structure:Structure|null;selected:Selected;dialog:Dialog;name:string;parentId:UUID|null;
  source:FormSource;error:string;notice:string;unconfirmed:boolean;pending:Pending|null;conflict:boolean;
  permissionRevoked:boolean};
const structureMemory=new Map<string,StructureSnapshot>();
export function ApplicationStructurePanel(props:ApplicationStructureProps){
  const scopeKey=JSON.stringify([props.actorId,props.appId]);
  return <ApplicationStructureScope key={scopeKey} {...props} scopeKey={scopeKey}/>;
}
function ApplicationStructureScope({applicationPolicyRevision,onApplicationDeleted,requestSectionLeave,appId,actorId,onOpenForm,onConfigureForm,onDirtyChange,onUnauthorized,onIdentityMismatch,registerLeaveGuard,
  scopeKey}:ApplicationStructureProps&{scopeKey:string}){
  const restored=structureMemory.get(scopeKey);
  const [deletion,setDeletion]=useState<StructureDeletionSelection|null>(null),[deletionDirty,setDeletionDirty]=useState(false);
  const deletionRecovery=scopedUnconfirmed(actorId).flatMap(packet=>{
    const resource=packet.resource,body=packet.body;
    if(resource?.kind!=='structure-deletion'||resource.appId!==appId||!Number.isSafeInteger(body?.expectedStructureVersion)||!Number.isSafeInteger(body?.expectedResourceVersion))return [];
    return [{operationId:packet.operationId,kind:resource.resourceKind,id:resource.id,structureVersion:body!.expectedStructureVersion as number,resourceVersion:body!.expectedResourceVersion as number}];
  });
  const deletionBlocked=!!deletion||deletionDirty||deletionRecovery.length>0;
  const [structure,reactSetStructure]=useState<Structure|null>(restored?.structure??null),
    [selected,reactSetSelected]=useState<Selected>(restored?.selected??null);
  const [dialog,reactSetDialog]=useState<Dialog>(restored?.dialog??null),[name,reactSetName]=useState(restored?.name??''),
    [parentId,reactSetParentId]=useState<UUID|null>(restored?.parentId??null);
  const [source,reactSetSource]=useState<FormSource>(restored?.source??{kind:'new_table'}),
    [error,setError]=useState(restored?.error??''),[notice,setNotice]=useState(restored?.notice??'');
  const [busy,reactSetBusy]=useState(false),[unconfirmed,reactSetUnconfirmed]=useState(restored?.unconfirmed||!!restored?.pending),
    [pending,reactSetPending]=useState<Pending|null>(restored?.pending??null);
  const [conflict,setConflict]=useState(restored?.conflict??false),
    [permissionRevoked,setPermissionRevoked]=useState(restored?.permissionRevoked??false);
  const [verified,setVerified]=useState(false),[verificationError,setVerificationError]=useState('');
  const [reload,setReload]=useState(0),request=useRef(0),scope=useRef(scopeKey),alive=useRef(true);
  const live=useRef({structure,selected,dialog,name,parentId,source,busy,unconfirmed,pending});
  const setStructure=(next:Structure|null)=>{live.current.structure=next;reactSetStructure(next);};
  const setSelected=(next:Selected)=>{live.current.selected=next;reactSetSelected(next);};
  const setDialog=(next:Dialog)=>{live.current.dialog=next;reactSetDialog(next);};
  const setName=(next:string)=>{live.current.name=next;reactSetName(next);};
  const setParentId=(next:UUID|null)=>{live.current.parentId=next;reactSetParentId(next);};
  const setSource=(next:FormSource)=>{live.current.source=next;reactSetSource(next);};
  const setBusy=(next:boolean)=>{live.current.busy=next;reactSetBusy(next);};
  const setUnconfirmed=(next:boolean)=>{live.current.unconfirmed=next;reactSetUnconfirmed(next);};
  const setPending=(next:Pending|null)=>{live.current.pending=next;reactSetPending(next);};
  const leaveController=useRef<LeaveController|null>(null);
  const dirtyCallback=useRef(onDirtyChange);dirtyCallback.current=onDirtyChange;
  const reportAuth=(problem:unknown)=>{
    if(!(problem instanceof FormApiError))return;
    if(problem.status===401||problem.status===403||problem.code==='AUTH_SESSION_CHANGED'){
      setVerified(false);setVerificationError(formErrorText(problem));
    }
    if(problem.status===401)onUnauthorized?.();
    else if(problem.code==='AUTH_SESSION_CHANGED')onIdentityMismatch?.();
  };
  if(!leaveController.current)leaveController.current=createLeaveController(()=>{
    const current=live.current;
    const status:LeaveStatus=current.pending?(current.unconfirmed?'unknown':'write_in_flight'):
      current.dialog&&(!!current.name.trim()||current.dialog==='moveDirectory')?'draft':'clean';
    return {status,fingerprint:JSON.stringify({status,structureVersion:current.structure?.structureVersion,
      selected:current.selected,dialog:current.dialog,name:current.name,parentId:current.parentId,
      source:current.source,busy:current.busy,unconfirmed:current.unconfirmed,
      pending:current.pending?.operationId})};
  },decision=>{
    const cached=structureMemory.get(scopeKey),current=live.current;
    if(decision==='retain_operation'){
      if(cached)structureMemory.set(scopeKey,{...cached,structure:current.structure,selected:current.selected,
        dialog:current.dialog,name:current.name,parentId:current.parentId,source:current.source,
        unconfirmed:current.unconfirmed||!!current.pending,pending:current.pending});
      return;
    }
    if(cached)structureMemory.set(scopeKey,{...cached,selected:null,dialog:null,name:'',parentId:null,
      source:{kind:'new_table'},pending:null,unconfirmed:false,conflict:false,error:'',notice:''});
    setSelected(null);setDialog(null);setName('');setParentId(null);setSource({kind:'new_table'});
    setPending(null);setUnconfirmed(false);setBusy(false);setConflict(false);setError('');setNotice('');
  });
  useEffect(()=>registerLeaveGuard({kind:'structure',actorId,appId},leaveController.current!),
    [registerLeaveGuard,actorId,appId]);
  useEffect(()=>{alive.current=true;return()=>{alive.current=false;request.current++;};},[]);
  useEffect(()=>()=>{dirtyCallback.current?.(false);},[]);
  useLayoutEffect(()=>{structureMemory.set(scopeKey,{structure,selected,dialog,name,parentId,source,error,notice,
    unconfirmed,pending,conflict,permissionRevoked});},[scopeKey,structure,selected,dialog,name,parentId,source,
    error,notice,unconfirmed,pending,conflict,permissionRevoked]);
  useEffect(()=>{
    const current=++request.current,controller=new AbortController();
    const preserve=!!pending||!!dialog&&!!name.trim();
    setVerified(false);setVerificationError('');
    void formApi.structure(appId,actorId,controller.signal).then(value=>{if(!alive.current||current!==request.current)return;
      if(preserve&&!value.capabilities.canManageDefinition){
        setPermissionRevoked(true);setVerificationError('没有目录与表单配置权限，已隐藏原输入与操作');return;
      }
      setPermissionRevoked(false);
      if(preserve){
        setError(pending?'操作结果暂未确认，请查询原操作或按原请求重试':'');
        if(structure&&value.structureVersion!==structure.structureVersion)
          setError('目录版本已变化，原输入仍保留；请核查原操作或手动决定是否放弃输入');
      }else{
        setStructure(value);setSelected(null);setDialog(null);setName('');setNotice('');
        setPending(null);setBusy(false);setUnconfirmed(false);setConflict(false);setError('');
      }
      setVerified(true);
    })
      .catch(problem=>{if(alive.current&&!controller.signal.aborted&&current===request.current){
        reportAuth(problem);setVerificationError(formErrorText(problem));}});
    return()=>{controller.abort();request.current++;};},[appId,actorId,reload,scopeKey]);
  useEffect(()=>onDirtyChange?.(!!pending||!!dialog&&!!name.trim()||deletionDirty||deletionRecovery.length>0),[dialog,name,pending,deletionDirty,deletionRecovery.length,onDirtyChange]);
  const folder=structure?.directories.find(item=>selected?.kind==='directory'&&item.id===selected.id);
  const form=structure?.forms.find(item=>selected?.kind==='form'&&item.id===selected.id);
  const canEdit=verified&&!!structure?.capabilities.canManageDefinition&&!permissionRevoked;
  const dirs=[...(structure?.directories??[])].sort((a,b)=>a.position-b.position);
  const open=(kind:Exclude<Dialog,null>,item?:{id:UUID;name:string;parentId?:UUID|null})=>{
    if(!canEdit||pending||deletionBlocked)return;setDialog(kind);setError('');setNotice('');setUnconfirmed(false);setPending(null);setConflict(false);
    setName(kind==='renameDirectory'||kind==='moveDirectory'||kind==='editForm'?item?.name??'':'');
    setParentId(kind==='directory'?item?.id??null:item?.parentId??null);setSource({kind:'new_table'});
  };
  const refresh=()=>formApi.structure(appId,actorId).then(value=>{if(alive.current&&scope.current===scopeKey)setStructure(value);})
    .catch(problem=>{reportAuth(problem);throw problem;});
  const apply=async(work:Pending,wasUnknown=false)=>{const current=scope.current;
    const cached=structureMemory.get(scopeKey);if(cached)structureMemory.set(scopeKey,{...cached,pending:work});
    setPending(work);setBusy(true);setError('');
    try{await work.run();if(!alive.current||scope.current!==current)return;
      setPending(null);setUnconfirmed(false);setConflict(false);setDialog(null);setName('');setNotice('已保存');
      try{await refresh();}catch(problem){if(alive.current&&scope.current===current)setError(`更改已确认，目录刷新失败：${formErrorText(problem)}`);}}
    catch(problem){if(!alive.current||scope.current!==current)return;reportAuth(problem);
      if(wasUnknown||problem instanceof FormApiError&&(problem.status===0||problem.status===408||problem.status>=500||
        problem.code==='APPLICATION_OPERATION_UNCONFIRMED')){
      setUnconfirmed(true);setError(`操作结果暂未确认；${formErrorText(problem)}`);
      }else{setPending(null);setUnconfirmed(false);setError(formErrorText(problem));
        if(problem instanceof FormApiError&&problem.status===403)setPermissionRevoked(true);
        if(problem instanceof FormApiError&&problem.code==='APPLICATION_STRUCTURE_CONFLICT')setConflict(true);}}
    finally{if(alive.current&&scope.current===current)setBusy(false);}
  };
  const submit=async()=>{if(!structure||!dialog||!canEdit||busy||unconfirmed||conflict||deletionBlocked)return;const clean=name.trim();
    if(!clean&&dialog!=='moveDirectory'){setError('请输入名称');return;}
    const operationId=uuid(),expectedStructureVersion=structure.structureVersion;
    let work:Pending;
    if(dialog==='directory'){
      const input=immutablePacket<StructureWrite>({operationId,name:clean,parentId,
        position:position(structure.directories.filter(item=>item.parentId===parentId)),expectedStructureVersion});
      work={operationId,run:()=>formApi.createDirectory(appId,actorId,input),httpStatus:201,
        matches:result=>validDirectoryResult(result,appId,input)};
    }else if(dialog==='renameDirectory'||dialog==='moveDirectory'){
      if(!folder)return;
      if(descendants(structure.directories,folder.id,parentId)){setError('目录不能移动到自己或自己的子目录');return;}
      const input=immutablePacket<StructureWrite>({operationId,name:dialog==='renameDirectory'?clean:folder.name,parentId,
        position:parentId===folder.parentId?folder.position:position(structure.directories.filter(item=>item.parentId===parentId)),expectedStructureVersion});
      work={operationId,run:()=>formApi.updateDirectory(appId,actorId,folder.id,input),httpStatus:200,
        matches:result=>validDirectoryResult(result,appId,input,folder.id)};
    }else if(dialog==='form'){
      if(source.kind==='existing_table'&&!structure.tables.some(item=>item.id===source.tableId)){setError('请选择此应用中的逻辑表');return;}
      const input=immutablePacket<FormWrite>({operationId,name:clean,source,directoryId:parentId,
        position:position(structure.forms.filter(item=>item.directoryId===parentId)),expectedStructureVersion});
      work={operationId,run:()=>formApi.createForm(appId,actorId,input),httpStatus:201,
        matches:result=>validFormResult(result,appId,input)};
    }else{
      if(!form)return;
      const input=immutablePacket<FormUpdate>({operationId,name:clean,directoryId:parentId,
        position:parentId===form.directoryId?form.position:position(structure.forms.filter(item=>item.directoryId===parentId)),expectedStructureVersion});
      work={operationId,run:()=>formApi.updateForm(appId,actorId,form.id,input),httpStatus:200,
        matches:result=>validFormResult(result,appId,input,form.id)};
    }
    await apply(work);
  };
  const check=async()=>{if(!pending)return;const current=scope.current;setBusy(true);setError('');
    try{const value=await formApi.operation(pending.operationId,actorId);if(!alive.current||scope.current!==current)return;
      if(value.httpStatus===pending.httpStatus&&pending.matches(value.result)){
      setPending(null);setUnconfirmed(false);setDialog(null);setName('');setNotice('原操作已确认');
      try{await refresh();}catch(problem){if(alive.current&&scope.current===current)setError(`原操作已确认，目录刷新失败：${formErrorText(problem)}`);}return;}
      setError('原操作回执与当前应用或原请求不匹配，请保留当前输入');
    }catch(problem){if(!alive.current||scope.current!==current)return;reportAuth(problem);
      if(problem instanceof FormApiError&&problem.status===403)setPermissionRevoked(true);
      setError(problem instanceof FormApiError&&problem.status===404?
      '暂未查到原操作；这不能证明操作已回滚，可按原请求重试':formErrorText(problem));}
    finally{if(alive.current&&scope.current===current)setBusy(false);}
  };
  const remove=(kind:StructureDeletionSelection['kind'],id:string,resourceVersion:number)=>{
    if(!canEdit||!structure||pending||dialog||deletionBlocked)return;
    const begin=()=>setDeletion({kind,id,resourceVersion,structureVersion:structure.structureVersion});
    if(requestSectionLeave)requestSectionLeave(begin);else begin();
  };
  const deleted=(kind:StructureDeletionSelection['kind'])=>{
    setDeletion(null);setSelected(null);setNotice('已删除');
    if(kind==='application'){structureMemory.delete(scopeKey);onApplicationDeleted?.();return;}
    void refresh().catch(problem=>{if(alive.current)setError('删除已确认，目录刷新失败：'+formErrorText(problem));});
  };
  const tree=(parent:UUID|null,seen=new Set<UUID>()):React.ReactNode=>{
    if(!structure)return null;
    return <ul className="forms-tree-list" role={parent===null?'tree':'group'} aria-label={parent===null?'应用目录':undefined}>
      {dirs.filter(item=>item.parentId===parent&&!seen.has(item.id)).map(item=><li role="treeitem" aria-label={item.name} aria-expanded="true" className="forms-tree-item" key={item.id}>
        <div className={`forms-tree-row${selected?.id===item.id?' active':''}`}>
          <button type="button" onClick={()=>setSelected({kind:'directory',id:item.id})}><span className="forms-tree-prefix">目录</span><span className="forms-tree-name" title={item.name}>{item.name}</span></button>
          {canEdit&&<button type="button" aria-label={`移动目录 ${item.name}`} onClick={()=>{setSelected({kind:'directory',id:item.id});open('moveDirectory',item);}}>移动</button>}
          {canEdit&&<button type="button" disabled={deletionBlocked} aria-label={`删除目录 ${item.name}`} onClick={()=>remove('directory',item.id,0)}>删除</button>}
        </div>{tree(item.id,new Set([...seen,item.id]))}</li>)}
      {structure.forms.filter(item=>item.directoryId===parent).sort((a,b)=>a.position-b.position).map(item=><li role="treeitem" aria-label={item.name} className="forms-tree-item" key={item.id}>
        <div className={`forms-tree-row${selected?.id===item.id?' active':''}`}>
          <button type="button" onClick={()=>setSelected({kind:'form',id:item.id})}><span className="forms-tree-prefix">表单</span><span className="forms-tree-name" title={item.name}>{item.name}</span></button>
          <button type="button" aria-label={`打开表单 ${item.name}`} onClick={()=>onOpenForm?.(item.id)}>打开</button>
          {canEdit&&onConfigureForm&&<button type="button" aria-label={`配置表单 ${item.name}`} onClick={()=>onConfigureForm(item.id)}>配置</button>}
          {canEdit&&<button type="button" disabled={deletionBlocked} aria-label={`删除表单 ${item.name}`} onClick={()=>remove('form',item.id,item.viewVersion)}>删除</button>}
        </div></li>)}
      {structure.tables.filter(item=>item.directoryId===parent&&!structure.forms.some(view=>view.tableId===item.id)).map(item=>
        <li role="treeitem" aria-label={item.name} key={item.id}><div className="forms-tree-row"><span className="forms-tree-prefix">逻辑表</span><span className="forms-tree-name" title={item.name}>{item.name}</span>{canEdit&&<button type="button" disabled={deletionBlocked} aria-label={`删除数据表 ${item.name}`} onClick={()=>remove('table',item.id,item.schemaVersion)}>删除</button>}</div></li>)}
    </ul>;
  };
  if(!verified)return <section className="forms-module forms-loading" role="status">
    {verificationError?<><p role="alert">{verificationError}</p>
      <button type="button" onClick={()=>{setVerificationError('');setReload(value=>value+1);}}>重试</button></>:
      '正在验证应用目录访问权限…'}</section>;
  if(!structure)return <section className="forms-module forms-loading" role="status">{error?<><p role="alert">{error}</p><button type="button" onClick={()=>setReload(value=>value+1)}>重试</button></>:'正在加载应用目录…'}</section>;
  return <section className="forms-module" aria-label="目录与视图管理">
    <div className="forms-structure-head"><div><strong>应用目录与视图</strong><p className="forms-muted">管理目录、逻辑表和表单视图</p></div>
      <div className="forms-structure-actions">{canEdit&&Number.isSafeInteger(applicationPolicyRevision)&&applicationPolicyRevision! > 0&&<button type="button" disabled={deletionBlocked} onClick={()=>remove('application',appId,applicationPolicyRevision!)}>删除应用</button>}<button type="button" disabled={!canEdit||deletionBlocked} onClick={()=>open('directory',folder)}>新建目录</button>
      <button type="button" className="forms-primary" disabled={!canEdit||deletionBlocked} onClick={()=>open('form',form?{...form,parentId:form.directoryId}:
        folder?{...folder,parentId:folder.id}:undefined)}>新建表单</button></div></div>
    {error&&!dialog&&<p className="forms-alert" role="alert">{error}</p>}{notice&&<p className="forms-success" role="status">{notice}</p>}
    <div className="forms-structure-layout"><nav className="forms-structure-tree">{tree(null)}
      {!structure.directories.length&&!structure.forms.length&&!structure.tables.length&&
        <p className="forms-muted" role="status">暂无目录或表单。可用上方按钮创建第一个项目。</p>}</nav>
      <section className="forms-structure-detail" aria-label="目录与视图详情">
      {folder?<><h2>目录 · {folder.name}</h2><p>位置 {folder.position+1}</p>{canEdit&&<>
        <button type="button" onClick={()=>open('renameDirectory',folder)}>重命名目录</button>
        <button type="button" onClick={()=>open('moveDirectory',folder)}>移动目录</button>
        <button type="button" onClick={()=>open('directory',folder)}>创建子目录</button></>}</>:
      form?<><h2>表单 · {form.name}</h2><p>逻辑表：{structure.tables.find(item=>item.id===form.tableId)?.name??form.tableId}</p>
        <p>视图版本：{form.viewVersion}</p><button type="button" className="forms-primary" onClick={()=>onOpenForm?.(form.id)}>打开表单 {form.name}</button>
        {canEdit&&onConfigureForm&&<button type="button" onClick={()=>onConfigureForm(form.id)}>配置表单 {form.name}</button>}
        {canEdit&&<button type="button" onClick={()=>open('editForm',{...form,parentId:form.directoryId})}>编辑表单名称与位置</button>}</>:
      <><h2>选择目录或视图</h2><p className="forms-muted">从左侧选择项目，查看详情并管理位置。</p></>}</section></div>
    {!deletion&&deletionRecovery.map(({operationId,...selection})=><button key={operationId} type="button" onClick={()=>setDeletion(selection)}>核查结构删除</button>)}
    {deletion&&<StructureDeletionDialog actorId={actorId} appId={appId} selection={deletion} onClose={()=>setDeletion(null)} onConfirmed={()=>deleted(deletion.kind)} onUnauthorized={onUnauthorized??(()=>{})} onIdentityMismatch={onIdentityMismatch??(()=>{})} onForbidden={()=>{setDeletion(null);setPermissionRevoked(true);setVerified(false);setVerificationError('没有应用访问或管理权限');}} onDirtyChange={setDeletionDirty} registerLeaveGuard={registerLeaveGuard} requestSectionLeave={requestSectionLeave}/>}
    {dialog&&<FormsDialog title={dialog==='directory'?'新建目录':dialog==='renameDirectory'?'重命名目录':dialog==='moveDirectory'?'移动目录':dialog==='form'?'新建表单':'编辑表单'}
      onClose={()=>{if(!busy&&!unconfirmed)setDialog(null);}} busy={busy||unconfirmed}>
      {dialog!=='moveDirectory'&&<label>{dialog==='directory'||dialog==='renameDirectory'?'目录名称':'表单名称'}
        <input aria-label={dialog==='directory'||dialog==='renameDirectory'?'目录名称':'表单名称'} value={name} disabled={busy||unconfirmed} onChange={event=>setName(event.target.value)}/></label>}
      {dialog!=='renameDirectory'&&<label>所属目录<select aria-label="所属目录" value={parentId??''} disabled={busy||unconfirmed} onChange={event=>setParentId(event.target.value||null)}>
        <option value="">根目录</option>{dirs.filter(item=>dialog!=='moveDirectory'||!folder||!descendants(dirs,folder.id,item.id))
          .map(item=><option key={item.id} value={item.id}>{item.name}</option>)}</select></label>}
      {dialog==='form'&&<fieldset><legend>表单来源</legend>
        <label className="forms-checkbox"><input type="radio" checked={source.kind==='new_table'} disabled={busy||unconfirmed} onChange={()=>setSource({kind:'new_table'})}/>新建逻辑表及首个表单视图</label>
        <label className="forms-checkbox"><input type="radio" checked={source.kind==='existing_table'} disabled={busy||unconfirmed||!structure.tables.length}
          onChange={()=>setSource({kind:'existing_table',tableId:structure.tables[0].id})}/>使用现有逻辑表</label>
        {source.kind==='existing_table'&&<select aria-label="现有逻辑表" value={source.tableId} disabled={busy||unconfirmed}
          onChange={event=>setSource({kind:'existing_table',tableId:event.target.value})}>
          {structure.tables.map(item=><option key={item.id} value={item.id}>{item.name}</option>)}</select>}</fieldset>}
      {error&&<p className="forms-alert" role="alert">{error}</p>}
      {conflict&&<div className="forms-dialog-actions"><button type="button" onClick={()=>{
        structureMemory.delete(scopeKey);
        setVerified(false);setStructure(null);setDialog(null);setName('');setSelected(null);
        setPending(null);setUnconfirmed(false);setConflict(false);setError('');setNotice('');
        setReload(value=>value+1);
      }}>放弃输入并加载最新版</button></div>}
      {unconfirmed&&pending?<div className="forms-dialog-actions">
        <button type="button" disabled={busy} onClick={()=>void check()}>查询原操作结果</button>
        <button type="button" disabled={busy} onClick={()=>void apply(pending,true)}>按原请求重试</button></div>:
      <div className="forms-dialog-actions"><button type="button" data-forms-close disabled={busy}>取消</button>
        <button type="button" className="forms-primary" disabled={busy||!canEdit||conflict} onClick={()=>void submit()}>{dialog==='directory'?'创建目录':dialog==='form'?'创建表单':'保存变更'}</button></div>}
      </FormsDialog>}
  </section>;
}
