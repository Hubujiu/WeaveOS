export type FilterCandidate={id:string;label:string;deleted:boolean};
export type FilterCandidatePage={items:FilterCandidate[];nextPageToken:string|null};
// First-test declaration only.
export function filterCandidatePage(value:unknown):FilterCandidatePage|null{return null;}
