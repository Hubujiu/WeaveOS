import { test, expect, type Page } from '@playwright/test';

// Independent oracle: PRD V030-012.2/.3, AP-FR-10, B5a.4-7 and
// original Home358:18205/catalog327:2132. Mock only the HTTP boundary.
// These component fixtures are not real API acceptance.
const user = { id: '00000000-0000-4000-8000-000000000001', account: 'slice-owner' };
const application = {
  id: '00000000-0000-4000-8000-000000000002',
  name: '业务应用甲', ownerUserId: user.id, policyRevision: 1,
};
async function fixture(page: Page, create = true) {
  await page.route('**/api/v1/**', async route => {
    const url = new URL(route.request().url());
    const path = url.pathname.slice('/api/v1/'.length);
    const data = path === 'sessions/current' ? user
      : path === 'me/access' ? {
          user, bootstrapAdmin: false, personnelManage: false, identities: [],
          permissions: create ? [{ code: 'applications.create', name: '应用管理', category: 'system', appId: null }] : [],
          applications: [], // Deliberately empty old personnel catalogue.
        }
      : path === 'applications' ? { items: [application] }
      : path === 'applications/' + application.id ? application
      : path === 'applications/' + application.id + '/access' ? {
          appId: application.id, canEnter: true, policyRevision: 1,
          menus: [{ resourceKind: 'application', resourceId: application.id }],
        }
      : path === 'applications/' + application.id + '/structure' ? {
          appId: application.id, structureVersion: 0, directories: [], tables: [], forms: [], capabilities: { canManageDefinition: true },
        }
      : {};
    await route.fulfill({ status: 200, json: { code: 'OK', message: 'success', data, meta: null } });
  });
}

test('V030-012 Home opens the real application catalogue', async ({ page }) => {
  await fixture(page);
  await page.goto('/app');
  await expect(page.getByText('WaveOS', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
  await expect(page).toHaveURL(/\/app\/applications$/);
  await expect(page.getByRole('heading', { name: '应用中心', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: application.name, exact: true })).toBeVisible();
});

test('V030-012 catalogue reads B5 without parameters and filters its authorized result', async ({ page }) => {
  await fixture(page);
  const urls: URL[] = [];
  page.on('request', request => {
    const url = new URL(request.url());
    if (url.pathname === '/api/v1/applications') urls.push(url);
  });
  await page.goto('/app/applications');
  await expect(page.getByText('WaveOS', { exact: true })).toBeVisible();
  await expect(page.getByRole('heading', { name: '应用中心', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: application.name, exact: true })).toBeVisible();
  expect(urls.length).toBeGreaterThan(0);
  expect(urls.every(url => url.search === '')).toBe(true);
  await page.getByRole('searchbox', { name: '搜索应用名称', exact: true }).fill('没有匹配项');
  await expect(page.getByRole('button', { name: application.name, exact: true })).toHaveCount(0);
  await expect(page.getByText('没有匹配的应用', { exact: true })).toBeVisible();
});

test('V030-012 catalog trailing slash survives direct entry and refresh', async ({ page }) => {
  await fixture(page);
  await page.goto('/app/applications/');
  await expect(page.getByRole('heading', { name: '应用中心', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: application.name, exact: true })).toBeVisible();
  await page.reload();
  await expect(page.getByRole('heading', { name: '应用中心', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: application.name, exact: true })).toBeVisible();
});

test('V030-012 live create capability opens a name-only real create flow', async ({ page }) => {
  await fixture(page);
  await page.goto('/app/applications');
  await expect(page.getByText('WaveOS', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '新建应用', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: '新建应用', exact: true });
  await expect(dialog).toBeVisible();
  await expect(dialog.getByRole('textbox', { name: '应用名称', exact: true })).toBeVisible();
  await expect(dialog.getByRole('button', { name: '创建应用', exact: true })).toBeVisible();
});

test('V030-012 opening an application rechecks access and presents its actual empty workspace', async ({ page }) => {
  await fixture(page, false);
  const accesses: string[] = [];
  page.on('request', request => {
    if (new URL(request.url()).pathname === '/api/v1/applications/' + application.id + '/access') accesses.push(request.url());
  });
  await page.goto('/app/applications/' + application.id);
  await expect(page.getByText('WaveOS', { exact: true })).toBeVisible();
  await expect(page.getByRole('heading', { name: application.name, exact: true })).toBeVisible();
  await expect(page.getByRole('status').filter({ hasText: '暂无目录或表单' })).toBeVisible();
  expect(accesses.length).toBeGreaterThan(0);
});

async function creation(page: Page) {
 await page.goto('/app/applications');
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 await page.getByRole('textbox', { name: '应用名称', exact: true }).fill('新业务应用');
 return page.getByRole('dialog', { name: '新建应用', exact: true });
}

test('V030-012 slow create preflight locks its name, ignores repeat clicks, and retains the matching unknown packet', async ({ page }) => {
 await fixture(page);
 const dialog = await creation(page);
 const input = dialog.getByRole('textbox', { name: '应用名称', exact: true });
 let release!: () => void;
 const gate = new Promise<void>(resolve => { release = resolve; });
 let entered!: () => void;
 const preflightStarted = new Promise<void>(resolve => { entered = resolve; });
 let preflights = 0;
 const writes: { name: string; operationId: string }[] = [];
 await page.route('**/api/v1/sessions/current', async route => { preflights++; entered(); await gate; await route.fulfill({ json: { code: 'OK', data: user } }); });
 await page.route('**/api/v1/applications', route => {
  if (route.request().method() === 'GET') return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
  writes.push(route.request().postDataJSON());
  return route.fulfill({ status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } });
 });
 const submit = dialog.getByRole('button', { name: '创建应用', exact: true });
 await submit.evaluate(button => { (button as HTMLButtonElement).click(); (button as HTMLButtonElement).click(); });
 await preflightStarted;
 try {
  await expect(input).toBeDisabled();
  const renamed = await input.fill('改名后的应用', { timeout: 250 }).then(() => true, () => false);
  expect(renamed).toBe(false);
  await expect(input).toHaveValue('新业务应用');
  expect(preflights).toBe(1);
  expect(writes).toHaveLength(0);
 } finally { release(); }
 await expect(dialog.getByRole('alert')).toContainText('尚未确认');
 expect(writes).toHaveLength(1);
 expect(writes[0].name).toBe('新业务应用');
 await expect(input).toHaveValue(writes[0].name);
 await dialog.getByRole('button', { name: '使用同一操作重试', exact: true }).click();
 await expect.poll(() => writes.length).toBe(2);
 expect(writes[1]).toEqual(writes[0]);
 await expect(input).toHaveValue(writes[0].name);
});

test('V030-012 preflight 401 keeps the unsent name without a write or unknown operation', async ({ page }) => {
 await fixture(page);
 await page.route('**/api/v1/sessions', route => route.fulfill({ json: { code: 'OK', data: user } }));
 const dialog = await creation(page);
 let release!: () => void;
 const gate = new Promise<void>(resolve => { release = resolve; });
 let entered!: () => void;
 const started = new Promise<void>(resolve => { entered = resolve; });
 let first = true; let writes = 0;
 await page.route('**/api/v1/sessions/current', async route => {
  if (first) { first = false; entered(); await gate; return route.fulfill({ status: 401, json: { code: 'AUTH_UNAUTHENTICATED' } }); }
  return route.fulfill({ json: { code: 'OK', data: user } });
 });
 await page.route('**/api/v1/applications', route => {
  if (route.request().method() === 'POST') writes++;
  return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
 });
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await started;
 await expect(dialog.getByRole('textbox', { name: '应用名称', exact: true })).toBeDisabled();
 release();
 await expect(page).toHaveURL(/\/login$/);
 expect(writes).toBe(0);
 await page.getByRole('textbox', { name: '账号', exact: true }).fill(user.account);
 await page.getByLabel('密码', { exact: true }).fill('test-password');
 await page.getByRole('button', { name: '登录', exact: true }).click();
 await expect(page).toHaveURL(/\/app$/);
 await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 const restored = page.getByRole('dialog', { name: '新建应用', exact: true });
 await expect(restored.getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('新业务应用');
 await expect(restored.getByRole('button', { name: '核查操作', exact: true })).toHaveCount(0);
 expect(writes).toBe(0);
});

test('V030-012 preflight actor mismatch masks the Shell before any create POST', async ({ page }) => {
 await fixture(page);
 const dialog = await creation(page);
 let release!: () => void;
 const gate = new Promise<void>(resolve => { release = resolve; });
 let entered!: () => void;
 const started = new Promise<void>(resolve => { entered = resolve; });
 let writes = 0;
 await page.route('**/api/v1/sessions/current', async route => {
  entered(); await gate;
  return route.fulfill({ json: { code: 'OK', data: { id: '00000000-0000-4000-8000-000000000003', account: 'other-owner' } } });
 });
 await page.route('**/api/v1/applications', route => {
  if (route.request().method() === 'POST') writes++;
  return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
 });
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await started;
 await expect(dialog.getByRole('textbox', { name: '应用名称', exact: true })).toBeDisabled();
 release();
 await expect(page.getByRole('alert').filter({ hasText: '登录身份已变化' })).toBeVisible();
 await expect(page.getByTestId('application-shell')).toHaveCount(0);
 expect(writes).toBe(0);
});

test('V030-012 discarding a gated unsent create through Back prevents its later POST and success', async ({ page }) => {
 await fixture(page);
 await page.goto('/app');
 await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 const dialog = page.getByRole('dialog', { name: '新建应用', exact: true });
 await dialog.getByRole('textbox', { name: '应用名称', exact: true }).fill('放弃的应用');
 let release!: () => void;
 const gate = new Promise<void>(resolve => { release = resolve; });
 let entered!: () => void;
 const started = new Promise<void>(resolve => { entered = resolve; });
 let completed!: () => void;
 const preflightCompleted = new Promise<void>(resolve => { completed = resolve; });
 let writes = 0;
 await page.route('**/api/v1/sessions/current', async route => { entered(); await gate; await route.fulfill({ json: { code: 'OK', data: user } }).catch(() => {}); completed(); });
 await page.route('**/api/v1/applications', route => {
  if (route.request().method() === 'POST') writes++;
  return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
 });
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await started;
 await page.goBack();
 const guard = page.getByRole('dialog', { name: '有未保存的修改', exact: true });
 await expect(guard).toContainText('丢失');
 await expect(guard).not.toContainText('结果仍未确认');
 await guard.getByRole('button', { name: '放弃修改', exact: true }).click();
 await expect(page).toHaveURL(/\/app$/);
 release();
 await preflightCompleted;
 expect(writes).toBe(0);
 await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 await expect(page.getByRole('dialog', { name: '新建应用', exact: true }).getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('');
 await expect(page.getByRole('status').filter({ hasText: '应用已创建' })).toHaveCount(0);
});

test('V030-012 create waits for server acknowledgement and sends only the frozen DTO', async ({ page }) => {
 await fixture(page);
 let release!: () => void;
 const gate = new Promise<void>(resolve => { release = resolve; });
 const writes: { name: string; operationId: string }[] = [];
 await page.route('**/api/v1/applications', async route => {
  if (route.request().method() === 'GET') { await route.fulfill({ json: { code: 'OK', data: { items: [application] } } }); return; }
  writes.push(route.request().postDataJSON());
  await gate;
  await route.fulfill({ status: 201, json: { code: 'OK', data: { ...application, name: '新业务应用' } } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect.poll(() => writes.length).toBe(1);
 expect(Object.keys(writes[0]).sort()).toEqual(['name', 'operationId']);
 expect(writes[0].name).toBe('新业务应用');
 expect(writes[0].operationId).toMatch(/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/);
 await expect(dialog.getByRole('button', { name: '创建中…', exact: true })).toBeDisabled();
 await expect(page.getByText('应用已创建', { exact: true })).toHaveCount(0);
 release();
 await expect(dialog).toHaveCount(0);
 await expect(page.getByRole('status').filter({ hasText: '应用已创建' })).toBeVisible();
});

test('V030-012 unconfirmed create recovers its original operation and never treats 404 as rollback', async ({ page }) => {
 await fixture(page);
 const writes: object[] = [];
 let queries = 0;
 await page.route('**/api/v1/applications', async route => {
  if (route.request().method() === 'GET') { await route.fulfill({ json: { code: 'OK', data: { items: [] } } }); return; }
  writes.push(route.request().postDataJSON());
  await route.fulfill({ status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED', data: null } });
 });
 await page.route('**/api/v1/application-operations/*', async route => {
  queries++;
  expect(route.request().url().split('/').pop()).toBe((writes[0] as { operationId: string }).operationId);
  await route.fulfill(queries === 1 ? { status: 404, json: { code: 'APPLICATION_NOT_FOUND', data: null } } : { json: {
   code: 'OK', data: { operationId: (writes[0] as { operationId: string }).operationId, status: 'confirmed', httpStatus: 201, location: '/api/v1/applications/' + application.id, result: application },
  } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('操作结果尚未确认');
 await expect(dialog.getByRole('textbox', { name: '应用名称', exact: true })).toBeDisabled();
 await dialog.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('仍未确认');
 await expect(dialog.getByRole('alert')).not.toContainText('已回滚');
 await dialog.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(dialog).toHaveCount(0);
 await expect(page.getByRole('status').filter({ hasText: '应用已创建' })).toBeVisible();
 expect(writes).toHaveLength(1);
});

test('V030-012 retry after lost response preserves the operation key and exact payload', async ({ page }) => {
 await fixture(page);
 const writes: object[] = [];
 await page.route('**/api/v1/applications', async route => {
  if (route.request().method() === 'GET') { await route.fulfill({ json: { code: 'OK', data: { items: [] } } }); return; }
  writes.push(route.request().postDataJSON());
  if (writes.length === 1) await route.abort('failed');
  else await route.fulfill({ status: 201, json: { code: 'OK', data: application } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('操作结果尚未确认');
 await dialog.getByRole('button', { name: '使用同一操作重试', exact: true }).click();
 await expect(dialog).toHaveCount(0);
 expect(writes).toHaveLength(2);
 expect(writes[1]).toEqual(writes[0]);
});

// Exhaustive receipt classification lives in application-create-receipt.test.mjs.
// Keep a real hook/UI path for each boundary, including exact-operation retry.
for (const reply of [
 { name: '201 JSON null', status: 201, json: null },
 { name: '201 wrong owner', status: 201, json: { code: 'OK', data: { ...application, ownerUserId: '00000000-0000-4000-8000-000000000003' } } },
 { name: '200 valid application body', status: 200, json: { code: 'OK', data: application } },
]) {
 test('V030-012 non-confirming create reply retains the original operation: ' + reply.name, async ({ page }) => {
  await fixture(page);
  const writes: object[] = [];
  await page.route('**/api/v1/applications', async route => {
   if (route.request().method() === 'GET') return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
   writes.push(route.request().postDataJSON());
   return route.fulfill({ status: reply.status, json: reply.json });
  });
  const dialog = await creation(page);
  await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
  await expect(dialog.getByRole('alert')).toContainText('尚未确认');
  await expect(dialog.getByRole('button', { name: '核查操作', exact: true })).toBeVisible();
  await dialog.getByRole('button', { name: '使用同一操作重试', exact: true }).click();
  await expect.poll(() => writes.length).toBe(2);
  expect(writes[1]).toEqual(writes[0]);
 });
}

test('V030-012 A unknown create cannot retry under B after another tab switches the shared session', async ({ page }, info) => {
 const otherUser = { id: '00000000-0000-4000-8000-000000000003', account: 'other-owner' };
 const writes: { actor: string; operationId: string }[] = [];
 const actorOf = async () => (await page.context().cookies()).some(cookie => cookie.name === 'actor' && cookie.value === 'B') ? otherUser : user;
 await page.route('**/api/v1/**', async route => {
  const actor = await actorOf();
  const path = new URL(route.request().url()).pathname.slice('/api/v1/'.length);
  if (path === 'sessions/current') return route.fulfill({ json: { code: 'OK', data: actor } });
  if (path === 'me/access') return route.fulfill({ json: { code: 'OK', data: { user: actor, bootstrapAdmin: false, personnelManage: false, identities: [], permissions: [{ code: 'applications.create', name: '应用管理', category: 'system', appId: null }], applications: [] } } });
  if (path === 'applications' && route.request().method() === 'GET') return route.fulfill({ json: { code: 'OK', data: { items: actor.id === user.id ? [application] : [] } } });
  if (path === 'applications' && route.request().method() === 'POST') {
   const body = route.request().postDataJSON() as { operationId: string };
   writes.push({ actor: actor.id, operationId: body.operationId });
   return route.fulfill(actor.id === user.id ? { status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } } : { status: 201, json: { code: 'OK', data: { ...application, name: '错误归属应用', ownerUserId: otherUser.id } } });
  }
  if (path.startsWith('application-operations/')) {
   expect(actor.id).toBe(user.id);
   expect(path.split('/').pop()).toBe(writes[0].operationId);
   return route.fulfill({ json: { code: 'OK', data: { operationId: writes[0].operationId, status: 'confirmed', httpStatus: 201, result: application } } });
  }
  return route.fulfill({ status: 404, json: { code: 'APPLICATION_NOT_FOUND' } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('尚未确认');
 const otherTab = await page.context().newPage();
 await otherTab.goto('/login');
 await otherTab.evaluate(() => { document.cookie = 'actor=B; path=/'; });
 await expect.poll(async () => (await page.context().cookies()).find(cookie => cookie.name === 'actor')?.value).toBe('B');
 await dialog.getByRole('button', { name: '使用同一操作重试', exact: true }).click();
 await expect(page.getByRole('alert').filter({ hasText: '登录身份已变化' })).toBeVisible();
 if (process.env.V030012_CAPTURE_SCREENSHOTS && info.project.name === 'chromium') await page.screenshot({ path: info.outputPath('account-mismatch.png') });
 expect(writes).toHaveLength(1);
 await expect(page.getByRole('button', { name: application.name, exact: true })).toHaveCount(0);
 await otherTab.evaluate(() => { document.cookie = 'actor=A; path=/'; });
 await page.getByRole('button', { name: '重新核对身份', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 const restored = page.getByRole('dialog', { name: '新建应用', exact: true });
 await expect(restored.getByRole('alert')).toContainText('尚未确认');
 if (process.env.V030012_CAPTURE_SCREENSHOTS && info.project.name === 'chromium') await page.screenshot({ path: info.outputPath('same-account-recovery.png') });
 await restored.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(restored).toHaveCount(0);
 expect(writes).toHaveLength(1);
 await otherTab.close();
});

test('V030-012 stale A shell blocks a new create when another tab is now B', async ({ page }) => {
 const otherUser = { id: '00000000-0000-4000-8000-000000000003', account: 'other-owner' };
 let writes = 0;
 await page.route('**/api/v1/**', async route => {
  const actor = (await page.context().cookies()).some(cookie => cookie.name === 'actor' && cookie.value === 'B') ? otherUser : user;
  const path = new URL(route.request().url()).pathname.slice('/api/v1/'.length);
  if (path === 'sessions/current') return route.fulfill({ json: { code: 'OK', data: actor } });
  if (path === 'me/access') return route.fulfill({ json: { code: 'OK', data: { user: actor, bootstrapAdmin: false, personnelManage: false, identities: [], permissions: [{ code: 'applications.create', name: '应用管理', category: 'system', appId: null }], applications: [] } } });
  if (path === 'applications' && route.request().method() === 'GET') return route.fulfill({ json: { code: 'OK', data: { items: [application] } } });
  if (path === 'applications' && route.request().method() === 'POST') { writes++; return route.fulfill({ status: 201, json: { code: 'OK', data: application } }); }
  return route.fulfill({ status: 404, json: { code: 'APPLICATION_NOT_FOUND' } });
 });
 await page.goto('/app/applications');
 await expect(page.getByRole('heading', { name: '应用中心', exact: true })).toBeVisible();
 const otherTab = await page.context().newPage();
 await otherTab.goto('/login');
 await otherTab.evaluate(() => { document.cookie = 'actor=B; path=/'; });
 await expect.poll(async () => (await page.context().cookies()).find(cookie => cookie.name === 'actor')?.value).toBe('B');
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 const dialog = page.getByRole('dialog', { name: '新建应用', exact: true });
 await dialog.getByRole('textbox', { name: '应用名称', exact: true }).fill('不能跨账号新建');
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(page.getByRole('alert').filter({ hasText: '登录身份已变化' })).toBeVisible();
 expect(writes).toBe(0);
 await otherTab.close();
});

test('V030-012 switching from a masked A view keeps recovery in the SPA auth flow', async ({ page }) => {
 const otherUser = { id: '00000000-0000-4000-8000-000000000003', account: 'other-owner' };
 await page.route('**/api/v1/**', async route => {
  const actor = (await page.context().cookies()).some(cookie => cookie.name === 'actor' && cookie.value === 'B') ? otherUser : user;
  const path = new URL(route.request().url()).pathname.slice('/api/v1/'.length);
  if (path === 'sessions/current') return route.fulfill({ json: { code: 'OK', data: actor } });
  if (path === 'me/access') return route.fulfill({ json: { code: 'OK', data: { user: actor, bootstrapAdmin: false, personnelManage: false, identities: [], permissions: [{ code: 'applications.create', name: '应用管理', category: 'system', appId: null }], applications: [] } } });
  if (path === 'applications' && route.request().method() === 'GET') return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
  if (path === 'applications' && route.request().method() === 'POST') return route.fulfill({ status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } });
  return route.fulfill({ status: 404, json: { code: 'APPLICATION_NOT_FOUND' } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('尚未确认');
 const otherTab = await page.context().newPage();
 await otherTab.goto('/login');
 await otherTab.evaluate(() => { document.cookie = 'actor=B; path=/'; });
 await dialog.getByRole('button', { name: '使用同一操作重试', exact: true }).click();
 await expect(page.getByRole('alert').filter({ hasText: '登录身份已变化' })).toBeVisible();
 await page.getByRole('button', { name: '载入当前账号', exact: true }).click();
 await expect(page).toHaveURL(/\/login$/);
 await otherTab.close();
});

test('V030-012 a mismatched me/access actor never renders the old application Shell', async ({ page }) => {
 const otherUser = { id: '00000000-0000-4000-8000-000000000003', account: 'other-owner' };
 let applicationReads = 0;
 await page.route('**/api/v1/**', route => {
  const path = new URL(route.request().url()).pathname.slice('/api/v1/'.length);
  if (path === 'sessions/current') return route.fulfill({ json: { code: 'OK', data: user } });
  if (path === 'me/access') return route.fulfill({ json: { code: 'OK', data: { user: otherUser, bootstrapAdmin: true, personnelManage: true, identities: [], permissions: [], applications: [] } } });
  if (path === 'applications') applicationReads++;
  return route.fulfill({ json: { code: 'OK', data: { items: [application] } } });
 });
 await page.goto('/app/applications');
 await expect(page.getByRole('alert').filter({ hasText: '登录身份已变化' })).toBeVisible();
 await expect(page.getByTestId('application-shell')).toHaveCount(0);
 expect(applicationReads).toBe(0);
});

test('V030-012 operation 401 keeps A draft and original key across SPA reauthentication', async ({ page }) => {
 await fixture(page);
 await page.route('**/api/v1/sessions', route => route.fulfill({ json: { code: 'OK', data: user } }));
 const writes: { operationId: string; name: string }[] = [];
 await page.route('**/api/v1/applications', async route => {
  if (route.request().method() === 'GET') return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
  writes.push(route.request().postDataJSON());
  return route.fulfill({ status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } });
 });
 let queried = 0;
 await page.route('**/api/v1/application-operations/*', async route => {
  queried++;
  expect(route.request().url().split('/').pop()).toBe(writes[0].operationId);
  return route.fulfill(queried === 1 ? { status: 401, json: { code: 'AUTH_UNAUTHENTICATED' } } : { json: { code: 'OK', data: { operationId: writes[0].operationId, status: 'confirmed', httpStatus: 201, result: { ...application, name: writes[0].name } } } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('尚未确认');
 await dialog.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(page).toHaveURL(/\/login$/);
 await page.getByRole('textbox', { name: '账号', exact: true }).fill(user.account);
 await page.getByLabel('密码', { exact: true }).fill('test-password');
 await page.getByRole('button', { name: '登录', exact: true }).click();
 await expect(page).toHaveURL(/\/app$/);
 await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 const restored = page.getByRole('dialog', { name: '新建应用', exact: true });
 await expect(restored.getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('新业务应用');
 await expect(restored.getByRole('alert')).toContainText('尚未确认');
 await restored.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(restored).toHaveCount(0);
 expect(writes).toHaveLength(1);
 expect(queried).toBe(2);
});

test('V030-012 B login cannot see or replay A draft and unknown operation', async ({ page }) => {
 const otherUser = { id: '00000000-0000-4000-8000-000000000003', account: 'other-owner' };
 let actor = user;
 const writes: { actor: string; operationId: string }[] = [];
 await page.route('**/api/v1/**', async route => {
  const path = new URL(route.request().url()).pathname.slice('/api/v1/'.length);
  if (path === 'sessions/current' || path === 'sessions') return route.fulfill({ json: { code: 'OK', data: actor } });
  if (path === 'me/access') return route.fulfill({ json: { code: 'OK', data: { user: actor, bootstrapAdmin: false, personnelManage: false, identities: [], permissions: [{ code: 'applications.create', name: '应用管理', category: 'system', appId: null }], applications: [] } } });
  if (path === 'applications' && route.request().method() === 'GET') return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
  if (path === 'applications' && route.request().method() === 'POST') {
   const body = route.request().postDataJSON() as { operationId: string };
   writes.push({ actor: actor.id, operationId: body.operationId });
   return route.fulfill({ status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } });
  }
  if (path.startsWith('application-operations/')) return route.fulfill({ status: 401, json: { code: 'AUTH_UNAUTHENTICATED' } });
  return route.fulfill({ status: 404, json: { code: 'APPLICATION_NOT_FOUND' } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('尚未确认');
 await dialog.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(page).toHaveURL(/\/login$/);
 actor = otherUser;
 await page.getByRole('textbox', { name: '账号', exact: true }).fill(otherUser.account);
 await page.getByLabel('密码', { exact: true }).fill('test-password');
 await page.getByRole('button', { name: '登录', exact: true }).click();
 await expect(page).toHaveURL(/\/app$/);
 await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 const bDialog = page.getByRole('dialog', { name: '新建应用', exact: true });
 await expect(bDialog.getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('');
 await expect(bDialog.getByRole('button', { name: '核查操作', exact: true })).toHaveCount(0);
 expect(writes).toHaveLength(1);
 expect(writes[0].actor).toBe(user.id);
});

test('V030-012 late catalog 401 keeps an unsent name for the same actor after login', async ({ page }) => {
 await fixture(page);
 let reauthenticated = false;
 await page.route('**/api/v1/sessions', route => { reauthenticated = true; return route.fulfill({ json: { code: 'OK', data: user } }); });
 let release!: () => void;
 const pending = new Promise<void>(resolve => { release = resolve; });
 await page.route('**/api/v1/applications', async route => {
  if (!reauthenticated) { await pending; return route.fulfill({ status: 401, json: { code: 'AUTH_UNAUTHENTICATED' } }); }
  return route.fulfill({ json: { code: 'OK', data: { items: [] } } });
 });
 await page.goto('/app/applications');
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 await page.getByRole('textbox', { name: '应用名称', exact: true }).fill('保留的未提交名称');
 release();
 await expect(page).toHaveURL(/\/login$/);
 await page.getByRole('textbox', { name: '账号', exact: true }).fill(user.account);
 await page.getByLabel('密码', { exact: true }).fill('test-password');
 await page.getByRole('button', { name: '登录', exact: true }).click();
 await expect(page).toHaveURL(/\/app$/);
 await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 await expect(page.getByRole('dialog', { name: '新建应用', exact: true }).getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('保留的未提交名称');
});

test('V030-012 a pending POST interrupted by forced login resumes as unknown under the same actor', async ({ page }) => {
 await fixture(page);
 let reauthenticated = false;
 await page.route('**/api/v1/sessions', route => { reauthenticated = true; return route.fulfill({ json: { code: 'OK', data: user } }); });
 let releaseCatalog!: () => void;
 const catalogGate = new Promise<void>(resolve => { releaseCatalog = resolve; });
 let releaseWrite!: () => void;
 const writeGate = new Promise<void>(resolve => { releaseWrite = resolve; });
 const writes: { operationId: string; name: string }[] = [];
 let postStarted!: () => void;
 const posted = new Promise<void>(resolve => { postStarted = resolve; });
 await page.route('**/api/v1/applications', async route => {
  if (route.request().method() === 'GET') { if (!reauthenticated) { await catalogGate; return route.fulfill({ status: 401, json: { code: 'AUTH_UNAUTHENTICATED' } }); } return route.fulfill({ json: { code: 'OK', data: { items: [] } } }); }
  writes.push(route.request().postDataJSON()); postStarted();
  await writeGate;
  await route.abort('failed').catch(() => {});
 });
 await page.route('**/api/v1/application-operations/*', route => {
  expect(route.request().url().split('/').pop()).toBe(writes[0].operationId);
  return route.fulfill({ json: { code: 'OK', data: { operationId: writes[0].operationId, status: 'confirmed', httpStatus: 201, result: { ...application, name: writes[0].name } } } });
 });
 await page.goto('/app/applications');
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 await page.getByRole('textbox', { name: '应用名称', exact: true }).fill('飞行中的应用');
 await page.getByRole('button', { name: '创建应用', exact: true }).click();
 await posted;
 releaseCatalog();
 await expect(page).toHaveURL(/\/login$/);
 try {
  await page.getByRole('textbox', { name: '账号', exact: true }).fill(user.account);
  await page.getByLabel('密码', { exact: true }).fill('test-password');
  await page.getByRole('button', { name: '登录', exact: true }).click();
  await expect(page).toHaveURL(/\/app$/);
  await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
  await page.getByRole('button', { name: '新建应用', exact: true }).click();
  const restored = page.getByRole('dialog', { name: '新建应用', exact: true });
  await expect(restored.getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('飞行中的应用');
  await expect(restored.getByRole('alert')).toContainText('尚未确认');
  await restored.getByRole('button', { name: '核查操作', exact: true }).click();
  await expect(restored).toHaveCount(0);
  expect(writes).toHaveLength(1);
 } finally { releaseWrite(); }
});

test('V030-012 every application-domain read, write and operation query binds the viewed actor', async ({ page }) => {
 await fixture(page);
 const calls: { path: string; actor: string | undefined }[] = [];
 page.on('request', request => {
  const path = new URL(request.url()).pathname;
  if (path.startsWith('/api/v1/applications') || path.startsWith('/api/v1/application-operations/')) calls.push({ path, actor: request.headers()['x-expected-actor-id'] });
 });
 await page.route('**/api/v1/applications', route => route.fulfill(route.request().method() === 'GET'
  ? { json: { code: 'OK', data: { items: [application] } } }
  : { status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } }));
 await page.route('**/api/v1/application-operations/*', route => route.fulfill({ status: 404, json: { code: 'APPLICATION_NOT_FOUND' } }));
 await page.goto('/app/applications');
 await page.getByRole('main').getByRole('button', { name: application.name, exact: true }).click();
 await expect(page.getByRole('heading', { name: application.name, exact: true })).toBeVisible();
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('尚未确认');
 await dialog.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('仍未确认');
 expect(calls.some(call => call.path === '/api/v1/applications')).toBe(true);
 expect(calls.some(call => call.path.endsWith('/access'))).toBe(true);
 expect(calls.some(call => call.path.startsWith('/api/v1/application-operations/'))).toBe(true);
 expect(calls.every(call => call.actor === user.id)).toBe(true);
});

test('V030-012 server denial is visible and never produces a success message', async ({ page }) => {
 await fixture(page);
 await page.route('**/api/v1/applications', async route => {
  await route.fulfill(route.request().method() === 'GET' ? { json: { code: 'OK', data: { items: [] } } } : { status: 403, json: { code: 'APPLICATION_FORBIDDEN', data: null } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('没有应用访问或管理权限');
 await expect(page.getByText('应用已创建', { exact: true })).toHaveCount(0);
 await expect(dialog.getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('新业务应用');
});

test('V030-012 dirty create cancel and Escape retain the name until explicit discard', async ({ page }) => {
 await fixture(page);
 const dialog = await creation(page);
 await page.keyboard.press('Escape');
 const guard = page.getByRole('dialog', { name: '有未保存的修改', exact: true });
 await expect(guard).toBeVisible();
 await guard.getByRole('button', { name: '继续编辑', exact: true }).click();
 await expect(dialog.getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('新业务应用');
 await dialog.getByRole('button', { name: '取消', exact: true }).click();
 await guard.getByRole('button', { name: '放弃修改', exact: true }).click();
 await expect(dialog).toHaveCount(0);
 await expect(page.getByRole('button', { name: '新建应用', exact: true })).toBeFocused();
});

test('V030-012 Home and application navigation retain one Shell and reauthorize repeated opens', async ({ page }) => {
 await fixture(page);
 let accesses = 0;
 page.on('request', request => { if (request.url().endsWith('/' + application.id + '/access')) accesses++; });
 await page.goto('/app/applications');
 const shell = await page.getByTestId('application-shell').elementHandle();
 for (let i = 0; i < 3; i++) {
  let before = accesses;
  await page.getByRole('main').getByRole('button', { name: application.name, exact: true }).click();
  await expect(page.getByRole('heading', { name: application.name, exact: true })).toBeVisible();
  expect(accesses).toBeGreaterThan(before);
  await page.getByRole('navigation', { name: '全局应用标签', exact: true }).getByRole('button', { name: '首页', exact: true }).click();
  before = accesses;
  await page.getByRole('navigation', { name: '全局应用标签', exact: true }).getByRole('button', { name: application.name, exact: true }).click();
  await expect(page.getByRole('heading', { name: application.name, exact: true })).toBeVisible();
  expect(accesses).toBeGreaterThan(before);
  await page.getByRole('navigation', { name: '全局应用标签', exact: true }).getByRole('button', { name: '全部应用', exact: true }).click();
  expect(await shell!.evaluate(node => node.isConnected)).toBe(true);
 }
 expect(accesses).toBeGreaterThanOrEqual(6);
});

test('V030-012 leaving a dirty create restores its route on cancel and closes it on discard', async ({ page }) => {
 await fixture(page);
 await page.goto('/app');
 await page.getByRole('button', { name: '打开应用中心', exact: true }).click();
 await page.getByRole('button', { name: '新建应用', exact: true }).click();
 await page.getByRole('textbox', { name: '应用名称', exact: true }).fill('未保存的名称');
 await page.goBack();
 const guard = page.getByRole('dialog', { name: '有未保存的修改', exact: true });
 await expect(guard).toBeVisible();
 await guard.getByRole('button', { name: '继续编辑', exact: true }).click();
 await expect(page).toHaveURL(/\/app\/applications$/);
 await expect(page.getByRole('textbox', { name: '应用名称', exact: true })).toHaveValue('未保存的名称');
 await page.goBack();
 await guard.getByRole('button', { name: '放弃修改', exact: true }).click();
 await expect(page).toHaveURL(/\/app$/);
 await expect(page.getByRole('dialog', { name: '新建应用', exact: true })).toHaveCount(0);
});

test('V030-012 an operation query denial is visible while the original outcome remains unconfirmed', async ({ page }) => {
 await fixture(page);
 await page.route('**/api/v1/applications', route => route.fulfill(route.request().method() === 'GET' ? { json: { code: 'OK', data: { items: [] } } } : { status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } }));
 await page.route('**/api/v1/application-operations/*', route => route.fulfill({ status: 403, json: { code: 'APPLICATION_FORBIDDEN' } }));
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await dialog.getByRole('button', { name: '核查操作', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('没有应用访问或管理权限');
 await expect(dialog.getByRole('alert')).toContainText('仍未确认');
 await expect(dialog.getByRole('button', { name: '使用同一操作重试', exact: true })).toBeVisible();
});

test('V030-012 denial on same-key retry cannot erase an earlier unknown outcome', async ({ page }) => {
 await fixture(page);
 const writes: object[] = [];
 await page.route('**/api/v1/applications', async route => {
  if (route.request().method() === 'GET') { await route.fulfill({ json: { code: 'OK', data: { items: [] } } }); return; }
  writes.push(route.request().postDataJSON());
  await route.fulfill(writes.length === 1 ? { status: 503, json: { code: 'APPLICATION_OPERATION_UNCONFIRMED' } } : { status: 403, json: { code: 'APPLICATION_FORBIDDEN' } });
 });
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await dialog.getByRole('button', { name: '使用同一操作重试', exact: true }).click();
 await expect(dialog.getByRole('alert')).toContainText('没有应用访问或管理权限');
 await expect(dialog.getByRole('alert')).toContainText('仍未确认');
 await expect(dialog.getByRole('textbox', { name: '应用名称', exact: true })).toBeDisabled();
 await dialog.getByRole('button', { name: '使用同一操作重试', exact: true }).click();
 await expect.poll(() => writes.length).toBe(3);
 expect(writes[1]).toEqual(writes[0]); expect(writes[2]).toEqual(writes[0]);
});

test('V030-012 confirmed create notice stays in the catalogue after opening the workspace', async ({ page }) => {
 await fixture(page);
 const created = { ...application, name: '新业务应用' };
 await page.route('**/api/v1/applications', async route => {
  await route.fulfill(route.request().method() === 'POST'
   ? { status: 201, json: { code: 'OK', data: created } }
   : { json: { code: 'OK', data: { items: [created] } } });
 });
 await page.route('**/api/v1/applications/' + application.id, route => route.fulfill({ json: { code: 'OK', data: created } }));
 const dialog = await creation(page);
 await dialog.getByRole('button', { name: '创建应用', exact: true }).click();
 await expect(page.getByRole('status').filter({ hasText: '应用已创建' })).toBeVisible();
 await page.getByRole('main').getByRole('button', { name: created.name, exact: true }).click();
 await expect(page.getByRole('heading', { name: created.name, exact: true })).toBeVisible();
 await expect(page.getByRole('status').filter({ hasText: '应用已创建' })).toHaveCount(0);
});

test('Root Mono application Home uses the approved shared full-bleed desktop shell', async ({ page }) => {
 await fixture(page);await page.setViewportSize({width:1920,height:1080});await page.goto('/app');
 await expect(page.getByTestId('workspace-shell')).toHaveCount(1);
 await expect(page.getByText('WaveOS',{exact:true})).toBeVisible();
 expect(await page.getByTestId('workspace-rail').boundingBox()).toMatchObject({x:0,y:0,width:78,height:1080});
 expect(await page.getByTestId('workspace-surface').boundingBox()).toMatchObject({x:78,y:0,width:1842,height:1080});
 expect(await page.getByRole('navigation',{name:'应用导航'}).boundingBox()).toMatchObject({x:78,y:0,width:190});
 expect(await page.locator('.mono-top').boundingBox()).toMatchObject({x:268,y:0,height:64});
 expect(await page.getByTestId('workspace-content-well').boundingBox()).toMatchObject({x:268,y:64});
 await expect(page.getByRole('heading',{name:'主页',exact:true})).toBeVisible();
});
